var yt=Object.defineProperty;var bt=(m,e,t)=>e in m?yt(m,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):m[e]=t;var d=(m,e,t)=>bt(m,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const n of a.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function s(i){if(i.ep)return;i.ep=!0;const a=t(i);fetch(i.href,a)}})();function ve(m){return 440*Math.pow(2,(m-69)/12)}const _t=typeof import.meta<"u"&&typeof import.meta.glob=="function"?Object.assign({}):{},vt=25,xt=.1,de=[{name:"Sunlit Quarry",bpm:114,swingRatio:.12,timbre:"kalimba",cutoffChill:1900,cutoffAim:3e3,cutoffRun:4600,chords:[[60,64,67,72],[59,62,67,71],[57,60,64,67],[53,57,60,64]],bass:[36,null,null,36,48,null,43,null,36,null,40,null,43,null,40,null,43,null,null,43,50,null,47,null,43,null,38,null,43,null,47,null,45,null,null,45,52,null,48,null,45,null,40,null,45,null,48,null,41,null,null,41,48,null,45,null,43,null,null,43,47,null,43,null],lead:[72,null,76,null,79,null,76,null,74,null,72,null,67,null,null,null,71,null,74,null,79,null,74,null,76,null,74,null,71,null,null,null,72,null,76,null,81,null,79,null,76,null,72,null,69,null,null,null,77,null,76,null,74,null,72,null,74,null,76,null,74,null,null,null],ostinato:[48,55,60,55,48,55,64,55],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1]},{name:"Crystal Cavern",bpm:118,swingRatio:.06,timbre:"crystal",cutoffChill:2100,cutoffAim:3300,cutoffRun:5e3,chords:[[59,64,67,71],[60,64,67,71],[59,62,67,71],[57,62,66,69]],bass:[40,null,null,40,47,null,40,null,40,null,43,null,47,null,40,null,36,null,null,36,43,null,36,null,36,null,40,null,43,null,36,null,43,null,null,43,50,null,43,null,43,null,47,null,50,null,43,null,38,null,null,38,45,null,38,null,38,null,42,null,45,null,47,null],lead:[76,null,79,null,83,null,79,null,78,null,76,null,71,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,71,null,null,null,74,null,79,null,83,null,79,null,78,null,74,null,71,null,null,null,74,null,78,null,81,null,78,null,76,null,74,null,71,null,null,null],ostinato:[52,59,64,59,52,59,67,59],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0]},{name:"Magma Core",bpm:122,swingRatio:.08,timbre:"analog",cutoffChill:1700,cutoffAim:2700,cutoffRun:4200,chords:[[57,62,65,69],[58,62,65,70],[60,64,67,72],[57,61,64,69]],bass:[38,38,null,38,45,null,38,null,38,38,null,38,41,null,45,null,34,34,null,34,41,null,34,null,34,34,null,34,38,null,41,null,36,36,null,36,43,null,36,null,36,36,null,36,40,null,43,null,33,33,null,33,40,null,33,null,33,null,40,null,45,null,40,null],lead:[74,null,74,76,77,null,74,null,72,null,69,null,74,null,null,null,70,null,74,null,77,null,74,null,72,null,70,null,69,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,67,null,null,null,69,null,73,null,76,null,73,null,76,null,74,null,73,null,null,null],ostinato:[50,57,62,57,50,57,65,57],kickMask:[1,0,0,1,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,1],hatMask:[1,0,1,1,1,0,1,0,1,0,1,1,1,0,1,0]},{name:"Frost Depths",bpm:108,swingRatio:.05,timbre:"felt",cutoffChill:1850,cutoffAim:2900,cutoffRun:4500,chords:[[57,60,64,69],[58,62,65,69],[55,58,62,65],[57,60,64,67]],bass:[38,null,null,45,50,null,null,null,38,null,null,45,48,null,null,null,34,null,null,41,46,null,null,null,34,null,null,41,45,null,null,null,43,null,null,50,46,null,null,null,43,null,null,46,50,null,null,null,36,null,null,43,48,null,null,null,36,null,null,40,43,null,null,null],lead:[74,null,76,null,77,null,81,null,79,null,77,null,76,null,null,null,74,null,70,null,74,null,77,null,76,null,74,null,72,null,null,null,70,null,74,null,79,null,77,null,74,null,70,null,67,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,69,null,null,null],ostinato:[50,57,62,57,50,57,64,57],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[0,0,1,0,0,0,1,0,0,0,1,0,1,0,1,0]},{name:"Warp Abyss",bpm:124,swingRatio:0,timbre:"synthwave",cutoffChill:1800,cutoffAim:3e3,cutoffRun:4800,chords:[[57,60,64,69],[53,57,60,65],[60,64,67,72],[59,62,67,71]],bass:[45,45,57,45,45,57,45,45,45,45,57,45,48,45,43,45,41,41,53,41,41,53,41,41,41,41,53,41,45,41,43,41,36,36,48,36,36,48,36,36,36,36,48,36,40,36,43,36,43,43,55,43,43,55,43,43,43,43,50,43,47,43,40,43],lead:[76,null,72,null,69,null,72,null,76,null,79,null,76,null,null,null,77,null,76,null,72,null,69,null,72,null,76,null,74,null,null,null,79,null,76,null,72,null,74,null,76,null,79,null,84,null,null,null,83,null,79,null,74,null,76,null,79,null,76,null,74,null,null,null],ostinato:[57,64,69,64,57,64,72,64],kickMask:[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1]},{name:"Quantum Core",bpm:128,swingRatio:.04,timbre:"arcade",cutoffChill:1950,cutoffAim:3200,cutoffRun:5100,chords:[[55,58,62,67],[55,58,63,67],[58,62,65,70],[57,60,65,69]],bass:[43,null,43,55,43,null,50,null,43,null,43,55,46,null,50,null,39,null,39,51,39,null,46,null,39,null,39,51,43,null,46,null,46,null,46,58,46,null,53,null,46,null,46,58,50,null,53,null,41,null,41,53,41,null,48,null,41,null,45,null,48,null,45,null],lead:[79,null,74,null,70,null,74,null,79,null,82,null,79,null,null,null,79,null,75,null,70,null,75,null,79,null,82,null,84,null,null,null,82,null,79,null,77,null,74,null,77,null,79,null,82,null,null,null,81,null,79,null,77,null,74,null,77,null,76,null,74,null,null,null],ostinato:[55,62,67,62,55,62,70,62],kickMask:[1,0,0,1,0,0,1,0,1,0,0,1,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,1],hatMask:[1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1]}];function kt(m){return m==="RUNNING"?"running":m==="AIMING"?"aiming":"chill"}class wt{constructor(){d(this,"ctx",null);d(this,"outputBus",null);d(this,"noiseBuffer",null);d(this,"rhythmDryBus",null);d(this,"harmonyBus",null);d(this,"melodyBus",null);d(this,"melodyFilter",null);d(this,"delayNode",null);d(this,"delayFeedback",null);d(this,"delayWet",null);d(this,"schedulerId",null);d(this,"running",!1);d(this,"pausedForAd",!1);d(this,"pausedByHidden",!1);d(this,"nextStepTime",0);d(this,"stepIndex",0);d(this,"activeBiomeIndex",0);d(this,"pendingBiomeIndex",0);d(this,"activeIntensity","chill");d(this,"pendingIntensity","chill");d(this,"bossActive",!1);d(this,"customBuffer",null);d(this,"customSource",null);d(this,"customLoadStarted",!1);d(this,"customTrackUrl",null);const e=Object.values(_t);e.length>0&&(this.customTrackUrl=e[0])}attach(e,t,s){this.ctx===e&&this.outputBus===t||(this.ctx=e,this.outputBus=t,this.noiseBuffer=s,this.buildInternalRouting(),this.customTrackUrl&&!this.customLoadStarted&&!this.customBuffer&&(this.customLoadStarted=!0,this.loadCustomTrack(this.customTrackUrl)))}buildInternalRouting(){if(!this.ctx||!this.outputBus)return;const e=this.ctx.currentTime,t=this.ctx.createGain();t.gain.setValueAtTime(1,e),t.connect(this.outputBus);const s=this.ctx.createGain();s.gain.setValueAtTime(.85,e);const i=this.ctx.createBiquadFilter();i.type="lowpass",i.frequency.setValueAtTime(1250,e),i.Q.setValueAtTime(.5,e),s.connect(i).connect(this.outputBus);const a=this.ctx.createGain();a.gain.setValueAtTime(1,e);const n=this.ctx.createBiquadFilter();if(n.type="lowpass",n.frequency.setValueAtTime(de[this.activeBiomeIndex].cutoffChill,e),n.Q.setValueAtTime(.6,e),a.connect(n),n.connect(this.outputBus),typeof this.ctx.createDelay=="function"){const c=this.ctx.createDelay(1),o=60/de[this.activeBiomeIndex].bpm*.75;c.delayTime.setValueAtTime(o,e);const l=this.ctx.createGain();l.gain.setValueAtTime(.18,e);const r=this.ctx.createBiquadFilter();r.type="lowpass",r.frequency.setValueAtTime(1350,e);const h=this.ctx.createGain();h.gain.setValueAtTime(.14,e),n.connect(c),c.connect(r),r.connect(l),l.connect(c),r.connect(h),h.connect(this.outputBus),this.delayNode=c,this.delayFeedback=l,this.delayWet=h}this.rhythmDryBus=t,this.harmonyBus=s,this.melodyBus=a,this.melodyFilter=n}async loadCustomTrack(e){if(!this.ctx||typeof fetch!="function")return!1;try{const t=await fetch(e);if(!t.ok)return!1;const s=await t.arrayBuffer(),i=await this.ctx.decodeAudioData(s);return this.setCustomTrackBuffer(i),!0}catch{return!1}}setCustomTrackBuffer(e){this.customBuffer=e,this.stopCustomSource(),this.running&&!this.pausedForAd&&!this.pausedByHidden&&this.customBuffer&&this.startCustomSource()}setBiome(e){const t=Math.max(0,Math.min(de.length-1,Math.floor(e)));t!==this.pendingBiomeIndex&&(this.pendingBiomeIndex=t,this.running||(this.activeBiomeIndex=t))}setGameState(e,t=!1){this.bossActive=t,this.setIntensity(kt(e))}setIntensity(e){e===this.pendingIntensity&&e===this.activeIntensity||(this.pendingIntensity=e,this.running||(this.activeIntensity=e,this.syncMasterFilterCutoff()))}setBossActive(e){this.bossActive=e}getActiveBiomeIndex(){return this.activeBiomeIndex}getActiveIntensity(){return this.activeIntensity}isRunning(){return this.running&&this.schedulerId!==null}start(){if(!(!this.ctx||!this.outputBus)&&!(this.pausedForAd||this.pausedByHidden)){if(this.activeBiomeIndex=this.pendingBiomeIndex,this.activeIntensity=this.pendingIntensity,this.syncMasterFilterCutoff(),this.customBuffer){this.running=!0,this.startCustomSource();return}this.schedulerId===null&&(this.running=!0,this.nextStepTime=Math.max(this.ctx.currentTime+.04,this.nextStepTime),this.scheduler(),this.schedulerId=setInterval(()=>this.scheduler(),vt))}}stop(){this.running=!1,this.schedulerId!==null&&(clearInterval(this.schedulerId),this.schedulerId=null),this.stopCustomSource(),this.nextStepTime=0,this.stepIndex=0}pauseForAd(){this.pausedForAd=!0,this.clearSchedulerOnly(),this.stopCustomSource()}resumeFromAd(e){this.pausedForAd=!1,e&&!this.pausedByHidden&&(this.nextStepTime=0,this.start())}setHiddenPaused(e,t){this.pausedByHidden=e,e?(this.clearSchedulerOnly(),this.stopCustomSource()):t&&!this.pausedForAd&&(this.nextStepTime=0,this.start())}clearSchedulerOnly(){this.running=!1,this.schedulerId!==null&&(clearInterval(this.schedulerId),this.schedulerId=null)}startCustomSource(){if(!this.ctx||!this.outputBus||!this.customBuffer||this.customSource)return;const e=this.ctx.createBufferSource();e.buffer=this.customBuffer,e.loop=!0,e.connect(this.outputBus),e.start(this.ctx.currentTime),this.customSource=e}stopCustomSource(){if(this.customSource){try{this.customSource.stop(),this.customSource.disconnect()}catch{}this.customSource=null}}syncMasterFilterCutoff(){if(!this.ctx||!this.melodyFilter)return;const e=de[this.activeBiomeIndex],t=this.activeIntensity==="running"?e.cutoffRun:this.activeIntensity==="aiming"?e.cutoffAim:e.cutoffChill;if(this.melodyFilter.frequency.setTargetAtTime(t,this.ctx.currentTime,.2),this.delayWet&&this.delayFeedback&&this.delayWet.gain.setTargetAtTime(this.activeIntensity==="chill"?.16:.12,this.ctx.currentTime,.2),this.delayNode){const s=60/e.bpm*.75;this.delayNode.delayTime.setTargetAtTime(s,this.ctx.currentTime,.25)}}scheduler(){if(!this.ctx||!this.running||this.pausedForAd||this.pausedByHidden)return;const e=this.ctx.currentTime;this.nextStepTime<e-.15&&(this.nextStepTime=e+.03);let t=0;for(;this.nextStepTime<e+xt&&t<8;){const s=de[this.activeBiomeIndex],i=60/s.bpm/4,a=this.stepIndex%2===1?i*s.swingRatio:0;this.scheduleStep(this.stepIndex,this.nextStepTime+a),this.nextStepTime+=i,this.stepIndex=(this.stepIndex+1)%64,t++}}scheduleStep(e,t){if(!this.ctx||!this.rhythmDryBus||!this.harmonyBus||!this.melodyBus)return;e%16===0&&this.pendingIntensity!==this.activeIntensity&&(this.activeIntensity=this.pendingIntensity,this.syncMasterFilterCutoff()),e%8===0&&this.pendingBiomeIndex!==this.activeBiomeIndex&&(this.activeBiomeIndex=this.pendingBiomeIndex,this.syncMasterFilterCutoff());const s=de[this.activeBiomeIndex],i=60/s.bpm/4,a=this.activeIntensity,n=e%16;if(n===0||n===6){const l=Math.floor(e/16)%s.chords.length,r=n===0?i*5.5:i*7.5,h=(n===0?1:.65)*(a==="chill"?.14:a==="aiming"?.12:.1);this.triggerRhodesChord(s.chords[l],t,r,h)}const c=s.bass[e];if(c!==null){const l=a==="chill"?.26:a==="aiming"?.3:.34;this.triggerBass(ve(c),t,i*1.65,l)}const o=s.lead[e];if(o!==null){const l=a==="chill"?.18:a==="aiming"?.22:.26,r=i*1.85;this.triggerLead(ve(o),s.timbre,t,r,l)}if(a==="aiming"?((n===0||n===8)&&this.triggerKick(t,.2),s.hatMask[n]&&this.triggerHat(t,n%2===0?.032:.018)):a==="running"&&(s.kickMask[n]&&this.triggerKick(t,.36),s.snareMask[n]&&this.triggerSnare(t,.13),s.hatMask[n]&&this.triggerHat(t,n%2===0?.042:.022)),this.bossActive&&a!=="chill"){const l=s.ostinato[e%s.ostinato.length];this.triggerOstinatoPulse(ve(l),t,i*.65,.09)}}triggerBass(e,t,s,i){if(!this.ctx||!this.rhythmDryBus)return;const a=this.ctx.createOscillator(),n=this.ctx.createOscillator(),c=this.ctx.createBiquadFilter(),o=this.ctx.createGain(),l=this.ctx.createGain();a.type="triangle",a.frequency.setValueAtTime(e,t),n.type="sine",n.frequency.setValueAtTime(e,t),l.gain.setValueAtTime(.5,t),c.type="lowpass",c.frequency.setValueAtTime(Math.min(720,e*4.5),t),c.frequency.exponentialRampToValueAtTime(Math.max(110,e*2.1),t+s),c.Q.setValueAtTime(.8,t),o.gain.setValueAtTime(1e-4,t),o.gain.linearRampToValueAtTime(i,t+.008),o.gain.exponentialRampToValueAtTime(8e-4,t+s),a.connect(c),n.connect(l).connect(c),c.connect(o).connect(this.rhythmDryBus),a.start(t),n.start(t),a.stop(t+s+.02),n.stop(t+s+.02)}triggerRhodesChord(e,t,s,i){if(!this.ctx||!this.harmonyBus)return;const a=this.ctx,n=a.createGain();n.gain.setValueAtTime(1e-4,t),n.gain.linearRampToValueAtTime(i,t+.018),n.gain.exponentialRampToValueAtTime(8e-4,t+s),n.connect(this.harmonyBus);const c=1/Math.max(1,e.length);for(let o=0;o<e.length;o++){const l=ve(e[o]),r=a.createOscillator(),h=a.createGain();r.type="sine",r.frequency.setValueAtTime(l*(o%2===0?1.001:.999),t),h.gain.setValueAtTime(c*.85,t),r.connect(h).connect(n),r.start(t),r.stop(t+s+.02);const y=a.createOscillator(),p=a.createGain();y.type="triangle",y.frequency.setValueAtTime(l*2,t),p.gain.setValueAtTime(c*.16,t),p.gain.exponentialRampToValueAtTime(8e-4,t+Math.min(.09,s*.4)),y.connect(p).connect(n),y.start(t),y.stop(t+Math.min(.1,s*.45))}}triggerLead(e,t,s,i,a){if(!this.ctx||!this.melodyBus)return;const n=this.ctx,c=this.melodyBus;if(t==="kalimba"||t==="felt"){const p=n.createOscillator(),u=n.createOscillator(),_=n.createGain(),b=n.createGain();p.type="sine",p.frequency.setValueAtTime(e,s),u.type="triangle",u.frequency.setValueAtTime(t==="kalimba"?e*2:e*.5,s),_.gain.setValueAtTime(t==="kalimba"?.16:.22,s),_.gain.exponentialRampToValueAtTime(.001,s+Math.min(.11,i*.6)),b.gain.setValueAtTime(1e-4,s),b.gain.linearRampToValueAtTime(a,s+.01),b.gain.exponentialRampToValueAtTime(8e-4,s+i),p.connect(b),u.connect(_).connect(b),b.connect(c),p.start(s),u.start(s),p.stop(s+i+.02),u.stop(s+i+.02);return}if(t==="crystal"){const p=n.createOscillator(),u=n.createOscillator(),_=n.createGain(),b=n.createGain();p.type="sine",p.frequency.setValueAtTime(e,s),u.type="sine",u.frequency.setValueAtTime(e*2,s),_.gain.setValueAtTime(.18,s),_.gain.exponentialRampToValueAtTime(.001,s+i*.65),b.gain.setValueAtTime(1e-4,s),b.gain.linearRampToValueAtTime(a*.9,s+.009),b.gain.exponentialRampToValueAtTime(8e-4,s+i*1.15),p.connect(b),u.connect(_).connect(b),b.connect(c),p.start(s),u.start(s),p.stop(s+i*1.2),u.stop(s+i*1.2);return}const o=n.createOscillator(),l=n.createOscillator(),r=n.createGain(),h=n.createBiquadFilter(),y=n.createGain();o.type="triangle",l.type="sawtooth",o.frequency.setValueAtTime(e,s),l.frequency.setValueAtTime(e*1.003,s),r.gain.setValueAtTime(t==="arcade"?.22:.28,s),h.type="lowpass",h.frequency.setValueAtTime(Math.min(2600,e*3.2),s),h.frequency.exponentialRampToValueAtTime(Math.max(420,e*1.35),s+i),h.Q.setValueAtTime(.75,s),y.gain.setValueAtTime(1e-4,s),y.gain.linearRampToValueAtTime(a*.92,s+.011),y.gain.exponentialRampToValueAtTime(8e-4,s+i),o.connect(h),l.connect(r).connect(h),h.connect(y).connect(c),o.start(s),l.start(s),o.stop(s+i+.02),l.stop(s+i+.02)}triggerKick(e,t){if(!this.ctx||!this.rhythmDryBus)return;const s=this.ctx.createOscillator(),i=this.ctx.createGain();s.type="sine",s.frequency.setValueAtTime(122,e),s.frequency.exponentialRampToValueAtTime(45,e+.06),i.gain.setValueAtTime(t,e),i.gain.exponentialRampToValueAtTime(.001,e+.13),s.connect(i).connect(this.rhythmDryBus),s.start(e),s.stop(e+.14)}triggerSnare(e,t){if(!this.ctx||!this.rhythmDryBus)return;if(this.noiseBuffer){const a=this.ctx.createBufferSource();a.buffer=this.noiseBuffer;const n=this.ctx.createBiquadFilter();n.type="bandpass",n.frequency.setValueAtTime(1650,e),n.Q.setValueAtTime(1.2,e);const c=this.ctx.createGain();c.gain.setValueAtTime(t*.75,e),c.gain.exponentialRampToValueAtTime(.001,e+.075),a.connect(n).connect(c).connect(this.rhythmDryBus),a.start(e),a.stop(e+.085)}const s=this.ctx.createOscillator(),i=this.ctx.createGain();s.type="triangle",s.frequency.setValueAtTime(195,e),s.frequency.exponentialRampToValueAtTime(115,e+.055),i.gain.setValueAtTime(t*.75,e),i.gain.exponentialRampToValueAtTime(.001,e+.065),s.connect(i).connect(this.rhythmDryBus),s.start(e),s.stop(e+.075)}triggerHat(e,t){if(!this.ctx||!this.rhythmDryBus||!this.noiseBuffer)return;const s=this.ctx.createBufferSource();s.buffer=this.noiseBuffer;const i=this.ctx.createBiquadFilter();i.type="bandpass",i.frequency.setValueAtTime(7600,e),i.Q.setValueAtTime(2,e);const a=this.ctx.createGain();a.gain.setValueAtTime(t,e),a.gain.exponentialRampToValueAtTime(.001,e+.024),s.connect(i).connect(a).connect(this.rhythmDryBus),s.start(e),s.stop(e+.03)}triggerOstinatoPulse(e,t,s,i){if(!this.ctx||!this.rhythmDryBus)return;const a=this.ctx.createOscillator(),n=this.ctx.createBiquadFilter(),c=this.ctx.createGain();a.type="triangle",a.frequency.setValueAtTime(e,t),n.type="lowpass",n.frequency.setValueAtTime(1200,t),c.gain.setValueAtTime(1e-4,t),c.gain.linearRampToValueAtTime(i,t+.005),c.gain.exponentialRampToValueAtTime(8e-4,t+s),a.connect(n).connect(c).connect(this.rhythmDryBus),a.start(t),a.stop(t+s+.015)}}const xe=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.51,1567.98,1760],Ue=.75,St=.28;class Tt{constructor(e=!1,t=!1,s=!1,i){d(this,"ctx",null);d(this,"sfxGain",null);d(this,"musicDuckGain",null);d(this,"musicGain",null);d(this,"musicCompressor",null);d(this,"noiseBuffer",null);d(this,"music",new wt);d(this,"musicVolume","high");d(this,"lastNonOffVolume","high");d(this,"musicStartedOnce",!1);d(this,"userMuted",!1);d(this,"sfxMuted",!1);d(this,"musicMuted",!1);d(this,"systemMuted",!1);d(this,"adPaused",!1);d(this,"gestureUnlocked",!1);d(this,"resumeArmed",!1);d(this,"boundResumeHandler",null);this.userMuted=e,this.sfxMuted=t,this.musicMuted=s,this.musicVolume=i??(s?"off":"high"),this.musicVolume!=="off"?this.lastNonOffVolume=this.musicVolume:this.musicMuted=!0,typeof document<"u"&&document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"?(this.music.setHiddenPaused(!0,!1),this.setSystemMuted(!0)):(this.setSystemMuted(!1),this.music.setHiddenPaused(!1,this.canPlayMusic()),this.armIosResume())}),typeof window<"u"&&(window.addEventListener("focus",()=>{!this.userMuted&&!this.systemMuted&&!this.adPaused&&this.armIosResume()}),this.armIosResume())}getTargetMusicGain(){if(this.userMuted||this.musicMuted||this.systemMuted||this.adPaused||this.musicVolume==="off")return 0;const e=this.musicVolume==="low"?.5:1;return St*e}canPlayMusic(){return this.gestureUnlocked&&!this.userMuted&&!this.musicMuted&&!this.systemMuted&&!this.adPaused&&this.musicVolume!=="off"}unlock(){this.gestureUnlocked=!0;const e=this.getOrCreateContextFromGesture();e&&(e.state==="suspended"&&!this.userMuted&&!this.systemMuted&&!this.adPaused&&e.resume().catch(()=>{}),this.syncMusicPlayback(!0))}armIosResume(){if(typeof window>"u"||this.resumeArmed)return;this.resumeArmed=!0;const e=()=>{this.resumeArmed=!1,this.gestureUnlocked=!0;const t=this.getOrCreateContextFromGesture();t&&t.state==="suspended"&&!this.userMuted&&!this.systemMuted&&!this.adPaused&&t.resume().catch(()=>{}),this.syncMusicPlayback(!0),this.boundResumeHandler&&(window.removeEventListener("pointerdown",this.boundResumeHandler),window.removeEventListener("touchend",this.boundResumeHandler),window.removeEventListener("keydown",this.boundResumeHandler),this.boundResumeHandler=null)};this.boundResumeHandler=e,window.addEventListener("pointerdown",e),window.addEventListener("touchend",e),window.addEventListener("keydown",e)}getOrCreateContextFromGesture(){if(typeof window>"u")return null;if(!this.ctx){const e=window.AudioContext||window.webkitAudioContext;if(!e)return null;const t=new e;this.ctx=t;const s=t.createGain();s.gain.setValueAtTime(!this.userMuted&&!this.sfxMuted&&!this.systemMuted?Ue:0,t.currentTime),s.connect(t.destination),this.sfxGain=s;const i=t.createGain();i.gain.setValueAtTime(1,t.currentTime);const a=t.createGain();if(a.gain.setValueAtTime(0,t.currentTime),i.connect(a),typeof t.createDynamicsCompressor=="function"){const n=t.createDynamicsCompressor();n.threshold.setValueAtTime(-14,t.currentTime),n.knee.setValueAtTime(18,t.currentTime),n.ratio.setValueAtTime(3,t.currentTime),n.attack.setValueAtTime(.008,t.currentTime),n.release.setValueAtTime(.15,t.currentTime),a.connect(n),n.connect(t.destination),this.musicCompressor=n}else a.connect(t.destination);this.musicDuckGain=i,this.musicGain=a,this.noiseBuffer=this.createNoiseBuffer(t),this.music.attach(t,i,this.noiseBuffer),this.syncGainLevels(!1)}return this.ctx}createNoiseBuffer(e){const t=e.sampleRate,s=t,i=e.createBuffer(1,s,t),a=i.getChannelData(0);let n=0;for(let c=0;c<s;c++){const o=Math.random()*2-1;n=(n+.08*o)/1.08,a[c]=n*2.6+o*.4}return i}ensureSfxContext(){return this.userMuted||this.sfxMuted||this.systemMuted||this.adPaused||!this.gestureUnlocked||!this.ctx||!this.sfxGain?null:(this.ctx.state==="suspended"&&this.ctx.resume().catch(()=>{}),{ctx:this.ctx,out:this.sfxGain})}syncGainLevels(e=!1){if(!this.ctx)return;const t=this.ctx.currentTime,s=!this.userMuted&&!this.systemMuted&&!this.adPaused;if(this.sfxGain){const i=s&&!this.sfxMuted?Ue:0;this.sfxGain.gain.setTargetAtTime(i,t,.02)}if(this.musicGain){const i=this.getTargetMusicGain();if(i<=0)this.musicGain.gain.setTargetAtTime(0,t,.015);else if(e){const a=this.musicGain.gain.value;this.musicGain.gain.cancelScheduledValues(t),this.musicGain.gain.setValueAtTime(Math.min(a,i),t),this.musicGain.gain.linearRampToValueAtTime(i,t+.6)}else this.musicGain.gain.setTargetAtTime(i,t,.08)}}syncMusicPlayback(e=!1){if(!this.ctx||!this.musicDuckGain){this.syncGainLevels(!1);return}if(this.music.attach(this.ctx,this.musicDuckGain,this.noiseBuffer),this.canPlayMusic()){const t=this.music.isRunning();t||this.music.start();const s=e||!this.musicStartedOnce||!t;this.musicStartedOnce=!0,this.syncGainLevels(s)}else this.syncGainLevels(!1),(this.userMuted||this.musicMuted||this.musicVolume==="off")&&this.music.stop()}duck(e=550){if(!this.ctx||!this.musicDuckGain||!this.canPlayMusic())return;const t=this.ctx.currentTime,s=Math.max(.05,e/1e3),i=this.musicDuckGain.gain;i.cancelScheduledValues(t),i.setValueAtTime(i.value,t),i.linearRampToValueAtTime(.45,t+.035),i.setValueAtTime(.45,t+s),i.linearRampToValueAtTime(1,t+s+.4)}updateMusicState(e,t,s=!1){this.music.setBiome(e),this.music.setGameState(t,s),this.canPlayMusic()&&!this.music.isRunning()&&this.syncMusicPlayback(!0)}updateAmbience(e,t,s){const i=s?"RUNNING":"TITLE";this.updateMusicState(t,i,!1)}pauseForAd(){if(this.adPaused=!0,this.music.pauseForAd(),this.ctx&&this.musicGain){const e=this.ctx.currentTime;this.musicGain.gain.cancelScheduledValues(e),this.musicGain.gain.setValueAtTime(this.musicGain.gain.value,e),this.musicGain.gain.linearRampToValueAtTime(0,e+.05)}this.setSystemMuted(!0)}resumeFromAd(){this.adPaused=!1,this.setSystemMuted(!1),this.music.resumeFromAd(this.canPlayMusic()),this.canPlayMusic()&&this.syncGainLevels(!0)}isMuted(){return this.userMuted}isSfxMuted(){return this.sfxMuted}isMusicMuted(){return this.musicMuted||this.musicVolume==="off"}getMusicVolume(){return this.musicVolume}getMusicIntensity(){return this.music.getActiveIntensity()}getMusicBiomeIndex(){return this.music.getActiveBiomeIndex()}isMusicPlaying(){return this.canPlayMusic()&&this.music.isRunning()}hasAudioRouting(){return!!(this.sfxGain&&this.musicGain&&this.musicDuckGain&&this.musicCompressor)}getMusicEngine(){return this.music}setSfxMuted(e){this.sfxMuted=e,this.syncGainLevels(!1)}setMusicVolume(e){this.musicVolume=e,e==="off"?this.musicMuted=!0:(this.lastNonOffVolume=e,this.musicMuted=!1),this.syncMusicPlayback(e!=="off")}setMusicMuted(e){this.musicMuted=e,e?this.musicVolume="off":this.musicVolume==="off"&&(this.musicVolume=this.lastNonOffVolume),this.syncMusicPlayback(!e)}setUserMuted(e){this.userMuted=e,this.syncSuspendState(),this.syncMusicPlayback(!e)}toggleMute(){return this.setUserMuted(!this.userMuted),this.userMuted}setSystemMuted(e){this.systemMuted=e,this.syncSuspendState(),this.syncGainLevels(!1),e||this.armIosResume()}syncSuspendState(){this.ctx&&(this.userMuted||this.systemMuted||this.adPaused?(this.music.setHiddenPaused(!0,!1),this.ctx.state==="running"&&this.ctx.suspend().catch(()=>{})):(this.ctx.state==="suspended"&&this.gestureUnlocked&&this.ctx.resume().catch(()=>{}),this.music.setHiddenPaused(!1,this.canPlayMusic())))}playLaunch(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();if(a.type="triangle",a.frequency.setValueAtTime(180,i),a.frequency.exponentialRampToValueAtTime(620,i+.13),n.gain.setValueAtTime(.18,i),n.gain.exponentialRampToValueAtTime(.001,i+.15),a.connect(n).connect(s),a.start(i),a.stop(i+.16),this.noiseBuffer){const c=t.createBufferSource();c.buffer=this.noiseBuffer;const o=t.createBiquadFilter();o.type="bandpass",o.frequency.setValueAtTime(1200,i);const l=t.createGain();l.gain.setValueAtTime(.08,i),l.gain.exponentialRampToValueAtTime(.001,i+.08),c.connect(o).connect(l).connect(s),c.start(i),c.stop(i+.09)}}playWallHit(e=900){const t=this.ensureSfxContext();if(!t)return;const{ctx:s,out:i}=t,a=s.currentTime,n=Math.max(.5,Math.min(1.5,e/900)),c=s.createOscillator(),o=s.createGain();c.type="triangle",c.frequency.setValueAtTime(1450*n,a),c.frequency.exponentialRampToValueAtTime(780*n,a+.045),o.gain.setValueAtTime(.055*n,a),o.gain.exponentialRampToValueAtTime(.001,a+.05),c.connect(o).connect(i),c.start(a),c.stop(a+.055)}playHit(e,t,s=!1,i=900){const a=this.ensureSfxContext();if(!a)return;const{ctx:n,out:c}=a,o=n.currentTime,l=Math.min(xe.length-1,Math.max(0,e%xe.length)),r=e>=xe.length?1.5:1,h=xe[l]*r,y=Math.max(.75,Math.min(1.3,i/900)),p=n.createOscillator(),u=n.createGain();if(p.type=t?"sawtooth":s?"square":"sine",p.frequency.setValueAtTime(t?h*1.25:h,o),p.frequency.exponentialRampToValueAtTime(h*.88,o+.085),u.gain.setValueAtTime((t?.14:.11)*y,o),u.gain.exponentialRampToValueAtTime(.001,o+.095),p.connect(u).connect(c),p.start(o),p.stop(o+.1),t){const _=n.createOscillator(),b=n.createGain();_.type="triangle",_.frequency.setValueAtTime(h*1.5,o),b.gain.setValueAtTime(.09,o),b.gain.exponentialRampToValueAtTime(.001,o+.11),_.connect(b).connect(c),_.start(o),_.stop(o+.12)}else if(s&&this.noiseBuffer){const _=n.createBufferSource();_.buffer=this.noiseBuffer;const b=n.createBiquadFilter();b.type="bandpass",b.frequency.setValueAtTime(620,o),b.Q.setValueAtTime(2.4,o);const v=n.createGain();v.gain.setValueAtTime(.14,o),v.gain.exponentialRampToValueAtTime(.001,o+.075),_.connect(b).connect(v).connect(c),_.start(o),_.stop(o+.08)}}playCrunch(e=!1){const t=this.ensureSfxContext();if(!t||!this.noiseBuffer)return;const{ctx:s,out:i}=t,a=s.currentTime,n=s.createBufferSource();n.buffer=this.noiseBuffer;const c=s.createBiquadFilter();c.type="bandpass",c.frequency.setValueAtTime(e?850:520,a),c.Q.setValueAtTime(e?2.8:1.4,a);const o=s.createGain();o.gain.setValueAtTime(e?.18:.11,a),o.gain.exponentialRampToValueAtTime(.001,a+.11),n.connect(c).connect(o).connect(i),n.start(a),n.stop(a+.12)}playBumper(e=0){const t=this.ensureSfxContext();if(!t)return;const{ctx:s,out:i}=t,a=s.currentTime,n=1+Math.min(8,e)*.03,c=s.createOscillator(),o=s.createGain();c.type="sine",c.frequency.setValueAtTime(740*n,a),c.frequency.exponentialRampToValueAtTime(1320*n,a+.11),o.gain.setValueAtTime(.16,a),o.gain.exponentialRampToValueAtTime(.001,a+.14),c.connect(o).connect(i),c.start(a),c.stop(a+.15);const l=s.createOscillator(),r=s.createGain();l.type="triangle",l.frequency.setValueAtTime(1480*n,a),r.gain.setValueAtTime(.08,a),r.gain.exponentialRampToValueAtTime(.001,a+.08),l.connect(r).connect(i),l.start(a),l.stop(a+.09)}playExplosion(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();if(a.type="sine",a.frequency.setValueAtTime(115,i),a.frequency.exponentialRampToValueAtTime(26,i+.34),n.gain.setValueAtTime(.32,i),n.gain.exponentialRampToValueAtTime(.001,i+.36),a.connect(n).connect(s),a.start(i),a.stop(i+.37),this.noiseBuffer){const c=t.createBufferSource();c.buffer=this.noiseBuffer;const o=t.createBiquadFilter();o.type="lowpass",o.frequency.setValueAtTime(1100,i),o.frequency.exponentialRampToValueAtTime(110,i+.35);const l=t.createGain();l.gain.setValueAtTime(.28,i),l.gain.exponentialRampToValueAtTime(.001,i+.38),c.connect(o).connect(l).connect(s),c.start(i),c.stop(i+.39)}}playCoin(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();a.type="sine",a.frequency.setValueAtTime(1174.66,i),a.frequency.setValueAtTime(1567.98,i+.045),n.gain.setValueAtTime(.085,i),n.gain.exponentialRampToValueAtTime(.001,i+.13),a.connect(n).connect(s),a.start(i),a.stop(i+.14)}playUpgrade(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;[523.25,659.25,783.99,1046.5].forEach((n,c)=>{const o=i+c*.045,l=t.createOscillator(),r=t.createGain();l.type="triangle",l.frequency.setValueAtTime(n,o),r.gain.setValueAtTime(.12,o),r.gain.exponentialRampToValueAtTime(.001,o+.16),l.connect(r).connect(s),l.start(o),l.stop(o+.17)})}playFanfare(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;this.duck(550),[523.25,659.25,783.99,1046.5,1318.51].forEach((n,c)=>{const o=i+c*.06,l=t.createOscillator(),r=t.createGain();l.type=c>=3?"sine":"triangle",l.frequency.setValueAtTime(n,o),r.gain.setValueAtTime(.11,o),r.gain.exponentialRampToValueAtTime(.001,o+.36),l.connect(r).connect(s),l.start(o),l.stop(o+.38)})}playVictoryFanfare(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;this.duck(1100);const a=[392,523.25,659.25,783.99];a.forEach((n,c)=>{const o=i+c*.11,l=c===a.length-1?.65:.24,r=t.createOscillator(),h=t.createBiquadFilter(),y=t.createGain();r.type="sawtooth",r.frequency.setValueAtTime(n,o),h.type="lowpass",h.frequency.setValueAtTime(1100,o),h.frequency.exponentialRampToValueAtTime(2200,o+.08),y.gain.setValueAtTime(.11,o),y.gain.exponentialRampToValueAtTime(.001,o+l),r.connect(h).connect(y).connect(s),r.start(o),r.stop(o+l+.02);const p=t.createOscillator(),u=t.createGain();p.type="sine",p.frequency.setValueAtTime(n*2,o+.02),u.gain.setValueAtTime(.09,o+.02),u.gain.exponentialRampToValueAtTime(.001,o+l+.18),p.connect(u).connect(s),p.start(o+.02),p.stop(o+l+.2)})}playClick(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();a.type="sine",a.frequency.setValueAtTime(760,i),n.gain.setValueAtTime(.06,i),n.gain.exponentialRampToValueAtTime(.001,i+.04),a.connect(n).connect(s),a.start(i),a.stop(i+.045)}}const j={MIDGAME_GRACE_PERIOD_S:180,MIDGAME_COOLDOWN_S:150,PRE_AD_CUE_S:.4,RV_DOUBLE_RUN_RATIO:1.2,RV_DOUBLE_RUN_COOLDOWN_RUNS:2,RV_EXTRA_LAUNCH_HP_THRESHOLD:.2,RV_FREE_UPGRADE_MIN_GAP:.1,RV_FREE_UPGRADE_MAX_GAP:.35,RV_FREE_UPGRADE_COOLDOWN_RUNS:4,RV_OVERDRIVE_COOLDOWN_RUNS:6},g={FIXED_DT:1/120,MAX_FRAME_DT:.05,SHAFT_WIDTH:540,GRID_COLS:9,TILE_SIZE:60,CHUNK_ROWS:12,METERS_PER_ROW:2.5,LAUNCHER_Y:72,MUZZLE_PIVOT_OFFSET_Y:-22,MUZZLE_LENGTH:58,LAUNCH_SPEED:920,GRAVITY:480,MIN_AIM_DEG:12,MAX_AIM_DEG:168,RESTITUTION_BLOCK:.96,RESTITUTION_BUMPER:1.25,MAX_ORB_SPEED:1450,MIN_ORB_SPEED:420,WALL_BOUNCE_COST:.5,BLOCK_BOUNCE_COST:1,CLEAVE_RATIO:2,BUMPER_MAX_HITS:5,BUMPER_BOUNCE_BONUS:2,MAX_ACTIVE_ORBS:12,TRAJECTORY_DOTS:14,CANCEL_DEADZONE_PX:16,HORIZONTAL_TRAP_WALL_HITS:4,HORIZONTAL_TRAP_DEFLECT_DEG:8,OVERHEAT_STALL_SECONDS:25,CAMERA_LOOKAHEAD_Y:160,MULTI_ORB_INTERVAL_S:.12,PORTAL_COOLDOWN_S:.4,PORTAL_BONUS_BOUNCES:2,PORTAL_SPEED_BOOST:1.3,BOSS_ARMOR_SPLASH_RATIO:.2},et={strata:{hpMult:1,coinMult:1},granite:{hpMult:3.2,coinMult:2},ore:{hpMult:1.5,coinMult:3},tnt:{hpMult:.5,coinMult:1.4},bumper:{hpMult:Number.POSITIVE_INFINITY,coinMult:.5},splitter:{hpMult:.5,coinMult:1},laser:{hpMult:1.1,coinMult:1.5},vault:{hpMult:5.5,coinMult:10},boss_core:{hpMult:15,coinMult:20},boss_armor:{hpMult:Number.POSITIVE_INFINITY,coinMult:.2},frost:{hpMult:1.4,coinMult:1.4},portal_entry:{hpMult:Number.POSITIVE_INFINITY,coinMult:0},portal_exit:{hpMult:Number.POSITIVE_INFINITY,coinMult:0}},Mt=2.5,At=3.5,Et=2.5,Ne=50,Ct=1300,tt=.5,U={FINAL_BIOME_INDEX:5,FINAL_GATE_DEPTH_M:1550,HP_BASE:2,COIN_BASE:1.65,CAP_BONUS_PER_TIER:10,DAMAGE_BONUS_PER_TIER:.15},Re=[{tier:1,titleKey:"asc_tier_1_title",quoteKey:"asc_tier_1_quote"},{tier:2,titleKey:"asc_tier_2_title",quoteKey:"asc_tier_2_quote"},{tier:3,titleKey:"asc_tier_3_title",quoteKey:"asc_tier_3_quote"},{tier:4,titleKey:"asc_tier_4_title",quoteKey:"asc_tier_4_quote"}],st=[{id:"chain_detonator",nameKey:"feat_chain_title",descKey:"feat_chain_desc",rewardCoins:1500},{id:"combo_master",nameKey:"feat_combo_title",descKey:"feat_combo_desc",rewardCoins:2500},{id:"heavy_investor",nameKey:"feat_investor_title",descKey:"feat_investor_desc",rewardCoins:5e3},{id:"zero_skip_purist",nameKey:"feat_zeroskip_title",descKey:"feat_zeroskip_desc",rewardCoins:1e4}];function it(m){return Math.pow(U.HP_BASE,Math.max(0,m))}function at(m){return Math.pow(U.COIN_BASE,Math.max(0,m))}function nt(m){return Math.max(0,m)*U.CAP_BONUS_PER_TIER}function rt(m){return 1+Math.max(0,m)*U.DAMAGE_BONUS_PER_TIER}function ot(m){const e=Math.max(0,Math.min(Re.length-1,m-1));return Re[e]}function se(m){const e=Math.max(1,Math.floor(m)),t=[[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];let s=e,i="";for(const[a,n]of t)for(;s>=a;)i+=n,s-=a;return i}const I=[{id:"quarry",index:0,nameKey:"biome_quarry",startDepthM:0,endDepthM:150,coinMultiplier:1,palette:{bgTop:"#161b2e",bgBottom:"#231c24",wall:"#3a2d28",strataFill:"#c96f44",strataStroke:"#f4a261",accent:"#38bdf8",glow:"#fbbf24"}},{id:"crystal",index:1,nameKey:"biome_crystal",startDepthM:150,endDepthM:350,coinMultiplier:4,palette:{bgTop:"#13112c",bgBottom:"#1e1642",wall:"#2b2459",strataFill:"#4338ca",strataStroke:"#22d3ee",accent:"#e879f9",glow:"#22d3ee"}},{id:"magma",index:2,nameKey:"biome_magma",startDepthM:350,endDepthM:600,coinMultiplier:16,palette:{bgTop:"#181214",bgBottom:"#2b130e",wall:"#331c17",strataFill:"#451a14",strataStroke:"#fb923c",accent:"#f97316",glow:"#fbbf24"}},{id:"subzero",index:3,nameKey:"biome_subzero",startDepthM:600,endDepthM:900,coinMultiplier:75,palette:{bgTop:"#0b192c",bgBottom:"#102a43",wall:"#1e3a5f",strataFill:"#1d4ed8",strataStroke:"#bae6fd",accent:"#7dd3fc",glow:"#e0f2fe"}},{id:"cyber",index:4,nameKey:"biome_cyber",startDepthM:900,endDepthM:1300,coinMultiplier:240,palette:{bgTop:"#120a21",bgBottom:"#1b0f30",wall:"#2a1647",strataFill:"#3b0764",strataStroke:"#a3e635",accent:"#f43f5e",glow:"#a3e635"}},{id:"quantum",index:5,nameKey:"biome_quantum",startDepthM:1300,endDepthM:Number.POSITIVE_INFINITY,coinMultiplier:1100,palette:{bgTop:"#05070e",bgBottom:"#111827",wall:"#1f2937",strataFill:"#1e293b",strataStroke:"#fde047",accent:"#f8fafc",glow:"#fde047"}}],te=[{id:"damage",nameKey:"upg_damage",descKey:"upg_damage_desc",baseCost:25,growthRate:1.6,maxLevel:40,icon:"pickaxe"},{id:"bounces",nameKey:"upg_bounces",descKey:"upg_bounces_desc",baseCost:35,growthRate:1.62,maxLevel:30,icon:"lightning"},{id:"multiorb",nameKey:"upg_multiorb",descKey:"upg_multiorb_desc",baseCost:420,growthRate:1.92,maxLevel:6,icon:"orb"},{id:"orbsize",nameKey:"upg_orbsize",descKey:"upg_orbsize_desc",baseCost:55,growthRate:1.64,maxLevel:20,icon:"blast"},{id:"luck",nameKey:"upg_luck",descKey:"upg_luck_desc",baseCost:65,growthRate:1.6,maxLevel:20,icon:"clover"},{id:"orevalue",nameKey:"upg_orevalue",descKey:"upg_orevalue_desc",baseCost:45,growthRate:1.7,maxLevel:35,icon:"coin"}],ue=[{id:"steel_sawblade",nameKey:"skin_steel_sawblade",category:"default",unlockDescKey:"skin_unlock_default",primaryColor:"#e2e8f0",secondaryColor:"#d97706",trailColor:"#ffb732",bladeTeeth:10},{id:"copper_gear",nameKey:"skin_copper_gear",category:"coin_or_ad",unlockDescKey:"skin_unlock_copper",primaryColor:"#d97706",secondaryColor:"#78350f",trailColor:"#f59e0b",bladeTeeth:12,coinCost:450},{id:"emerald_buzzsaw",nameKey:"skin_emerald_buzzsaw",category:"milestone",unlockDescKey:"skin_unlock_biome_1",primaryColor:"#34d399",secondaryColor:"#065f46",trailColor:"#10b981",bladeTeeth:14,unlockBiomeIndex:1,coinCost:1200},{id:"magma_cutter",nameKey:"skin_magma_cutter",category:"milestone",unlockDescKey:"skin_unlock_biome_2",primaryColor:"#fb7185",secondaryColor:"#991b1b",trailColor:"#f97316",bladeTeeth:12,unlockBiomeIndex:2,coinCost:4500},{id:"frost_star",nameKey:"skin_frost_star",category:"milestone",unlockDescKey:"skin_unlock_biome_3",primaryColor:"#7dd3fc",secondaryColor:"#0369a1",trailColor:"#38bdf8",bladeTeeth:12,unlockBiomeIndex:3,coinCost:15e3},{id:"gold_chakram",nameKey:"skin_gold_chakram",category:"coin_or_ad",unlockDescKey:"skin_unlock_day7",primaryColor:"#fde047",secondaryColor:"#dc2626",trailColor:"#fbbf24",bladeTeeth:8,coinCost:45e3},{id:"tesla_rotor",nameKey:"skin_tesla_rotor",category:"mastery",unlockDescKey:"skin_unlock_combo",primaryColor:"#2dd4bf",secondaryColor:"#1e293b",trailColor:"#22d3ee",bladeTeeth:8,masteryStat:"maxBounceCombo",masteryTarget:40,coinCost:12e4},{id:"toxic_drill",nameKey:"skin_toxic_drill",category:"coin_or_ad",unlockDescKey:"skin_unlock_toxic",primaryColor:"#a3e635",secondaryColor:"#3f6212",trailColor:"#bef264",bladeTeeth:14,coinCost:35e4,rvCost:3},{id:"void_reaper",nameKey:"skin_void_reaper",category:"milestone",unlockDescKey:"skin_unlock_biome_4",primaryColor:"#818cf8",secondaryColor:"#0f172a",trailColor:"#e0f2fe",bladeTeeth:6,unlockBiomeIndex:5,coinCost:1e6}],V={OFFLINE_UNLOCK_RUNS:3,OFFLINE_RATE_FRACTION:.15,OFFLINE_MAX_HOURS:4,OFFLINE_MIN_MINUTES:15,LOGIN_REWARDS:[{day:1,type:"coins",amount:300,labelKey:"reward_300_coins"},{day:2,type:"free_damage",amount:1,labelKey:"reward_free_damage"},{day:3,type:"shards",amount:5,labelKey:"reward_5_shards"},{day:4,type:"coins",amount:1500,labelKey:"reward_1500_coins"},{day:5,type:"overdrive_pass",amount:3,labelKey:"reward_overdrive_pass"},{day:6,type:"shards",amount:10,labelKey:"reward_10_shards"},{day:7,type:"skin",skinId:"gold_chakram",labelKey:"reward_golden_skin"}],DAILY_QUEST_POOL:[{id:"q_tnt",metric:"tntDetonated",target:20,labelKey:"quest_tnt",rewardCoins:250},{id:"q_bumpers",metric:"bumpersHit",target:35,labelKey:"quest_bumpers",rewardCoins:250},{id:"q_blocks",metric:"blocksDestroyed",target:120,labelKey:"quest_blocks",rewardCoins:300},{id:"q_runs",metric:"runsCompleted",target:8,labelKey:"quest_runs",rewardCoins:200},{id:"q_vaults",metric:"vaultsBroken",target:3,labelKey:"quest_vaults",rewardCoins:400}],DAILY_MEGA_CHEST_COINS:1e3,DAILY_MEGA_CHEST_SHARDS:5};function Be(m,e,t){const s=e+g.MUZZLE_PIVOT_OFFSET_Y;return{x:m+Math.cos(t)*g.MUZZLE_LENGTH,y:s+Math.sin(t)*g.MUZZLE_LENGTH}}function lt(m){for(let e=I.length-1;e>=0;e--)if(m>=I[e].startDepthM)return I[e];return I[0]}function Rt(m){const e=lt(m);if(e.id!=="quantum")return e.coinMultiplier;const t=Math.max(0,Math.floor((m-1300)/250));return e.coinMultiplier*Math.pow(1.15,t)}function Fe(m,e,t=0){const s=et[e].hpMult;if(!Number.isFinite(s))return Number.POSITIVE_INFINITY;const i=it(t);return Math.max(1,Math.floor(13*Math.pow(1+.0155*Math.max(0,m),1.38)*s*i))}function Ve(m,e,t,s=0,i=0){const a=et[e].coinMult;if(a<=0)return 0;const n=Rt(m),c=ct(t),o=1+s*tt,l=at(i);return Math.max(1,Math.floor(2*(1+.005*Math.max(0,m))*n*a*c*o*l))}function Bt(m,e){return Math.floor(m.baseCost*Math.pow(m.growthRate,Math.max(0,e-1)))}function It(m,e=0,t=0){const s=Math.max(1,m)-1;return(10+8*s+1.5*s*s)*(1+e*tt)*rt(t)}function Dt(m){return 8+2*(Math.max(1,m)-1)}function Lt(m){return Math.max(1,Math.min(6,Math.floor(m)))}function Ot(m){return 14+.75*(Math.max(1,m)-1)}function Pt(m){const e=1+.03*Math.max(0,m-1);return Mt*g.TILE_SIZE*e}function Ut(m){const e=.015*Math.max(0,m-1);return{tntChance:.08+e,bumperChance:.06+e}}function ct(m){return 1+.16*(Math.max(1,m)-1)}const Nt=.25;class Ft{constructor(e){d(this,"rafId",null);d(this,"lastTimeMs",0);d(this,"accumulator",0);d(this,"running",!1);d(this,"pausedByVisibility",!1);d(this,"speedMultiplier",1);d(this,"callbacks");d(this,"visibilityListener",null);this.callbacks=e,typeof document<"u"&&(this.visibilityListener=()=>{document.visibilityState==="hidden"?(this.pausedByVisibility=!0,this.accumulator=0,this.callbacks.onVisibilityBlur?.()):(this.pausedByVisibility=!1,this.resetAccumulator())},document.addEventListener("visibilitychange",this.visibilityListener))}setSpeedMultiplier(e){this.speedMultiplier=Math.max(1,Math.min(4,e))}getSpeedMultiplier(){return this.speedMultiplier}start(){if(this.running)return;this.running=!0,this.lastTimeMs=performance.now();const e=t=>{if(!this.running)return;if(this.pausedByVisibility){this.lastTimeMs=t,this.accumulator=0,this.rafId=requestAnimationFrame(e);return}const s=Math.max(0,(t-this.lastTimeMs)/1e3);this.lastTimeMs=t,s>Nt&&(this.accumulator=0);const i=Math.min(g.MAX_FRAME_DT,s);this.accumulator+=i*this.speedMultiplier;const a=g.FIXED_DT,n=Math.max(16,Math.ceil(g.MAX_FRAME_DT*this.speedMultiplier/a)+2);let c=0;for(;this.accumulator>=a&&c<n;)this.callbacks.onFixedUpdate(a),this.accumulator-=a,c++;c>=n&&this.accumulator>a&&(this.accumulator=0);const o=this.accumulator/a;this.callbacks.onRender(o,i),this.rafId=requestAnimationFrame(e)};this.rafId=requestAnimationFrame(e)}stop(){this.running=!1,this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.visibilityListener&&typeof document<"u"&&(document.removeEventListener("visibilitychange",this.visibilityListener),this.visibilityListener=null)}resetAccumulator(){this.accumulator=0,this.lastTimeMs=performance.now()}}function P(m,e,t){return m<e?e:m>t?t:m}function K(m){return m*Math.PI/180}class $e{constructor(e){d(this,"state");this.state=e>>>0,this.state===0&&(this.state=2654435769)}next(){let e=this.state+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}range(e,t){return e+this.next()*(t-e)}int(e,t){return Math.floor(this.range(e,t+1))}pick(e){return e[Math.floor(this.next()*e.length)]}}class Vt{constructor(e,t){d(this,"canvas");d(this,"callbacks");d(this,"activePointerId",null);d(this,"dragStartCss",{x:0,y:0});d(this,"currentAngleRad",Math.PI/2);d(this,"isDragging",!1);d(this,"isCanceled",!1);d(this,"locked",!1);d(this,"onContextMenu",e=>{e.preventDefault()});d(this,"onWheel",e=>{e.target===this.canvas&&e.preventDefault()});d(this,"onWindowBlur",()=>{this.isDragging&&(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,null))});d(this,"onPointerDown",e=>{if(!(this.locked||!this.callbacks.canAim())&&!(e.button!==0&&e.pointerType==="mouse")&&!(this.isDragging||this.activePointerId!==null)){this.activePointerId=e.pointerId,this.dragStartCss={x:e.clientX,y:e.clientY},this.isDragging=!0,this.isCanceled=!0;try{this.canvas.setPointerCapture?.(e.pointerId)}catch{}this.callbacks.onAimStart(),this.updateAimFromPointer(e.clientX,e.clientY)}});d(this,"onPointerMove",e=>{if(!this.locked){if(this.isDragging){if(e.pointerId!==this.activePointerId)return;this.updateAimFromPointer(e.clientX,e.clientY);return}e.pointerType==="mouse"&&this.callbacks.getAimMode()==="direct"&&this.callbacks.canAim()&&e.target===this.canvas&&this.updateHoverDirectAim(e.clientX,e.clientY)}});d(this,"onPointerUp",e=>{if(!this.isDragging||e.pointerId!==this.activePointerId)return;if(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.locked||this.isCanceled){this.callbacks.onAimUpdate(null,!0,null);return}const t=this.currentAngleRad;this.callbacks.onAimUpdate(null,!1,null),this.callbacks.onLaunch(t)});d(this,"onPointerCancel",e=>{!this.isDragging||e.pointerId!==this.activePointerId||(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,null))});d(this,"onKeyDown",e=>{if(this.locked)return;if((e.code==="Space"||e.code==="ArrowLeft"||e.code==="ArrowRight"||e.code==="ArrowUp"||e.code==="ArrowDown")&&e.preventDefault(),e.code==="KeyM"){this.callbacks.onToggleMute();return}if(e.code==="KeyP"){this.callbacks.onTogglePause();return}if(e.code==="KeyR"){this.callbacks.onQuickRelaunch();return}if(e.code>="Digit1"&&e.code<="Digit6"){const a=Number(e.code.slice(5))-1;this.callbacks.onBuyUpgradeSlot(a);return}if(!this.callbacks.canAim())return;const t=K(g.MIN_AIM_DEG),s=K(g.MAX_AIM_DEG),i=K(4);e.code==="ArrowLeft"||e.code==="KeyA"||e.code==="KeyQ"?(this.currentAngleRad=P(this.currentAngleRad+i,t,s),this.callbacks.onAimStart(),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)):e.code==="ArrowRight"||e.code==="KeyD"?(this.currentAngleRad=P(this.currentAngleRad-i,t,s),this.callbacks.onAimStart(),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)):(e.code==="Space"||e.code==="Enter")&&(this.callbacks.onAimUpdate(null,!1,null),this.callbacks.onLaunch(this.currentAngleRad))});this.canvas=e,this.callbacks=t,this.bind()}setLocked(e){this.locked=e,e&&this.isDragging&&(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.callbacks.onAimUpdate(null,!0,null))}getCurrentAngleRad(){return this.currentAngleRad}getIsDragging(){return this.isDragging}bind(){this.canvas.addEventListener("pointerdown",this.onPointerDown),window.addEventListener("pointermove",this.onPointerMove),window.addEventListener("pointerup",this.onPointerUp),window.addEventListener("pointercancel",this.onPointerCancel),window.addEventListener("blur",this.onWindowBlur),this.canvas.addEventListener("contextmenu",this.onContextMenu),window.addEventListener("wheel",this.onWheel,{passive:!1}),window.addEventListener("keydown",this.onKeyDown)}releasePointerCaptureSafe(e){if(e!==null)try{this.canvas.hasPointerCapture?.(e)&&this.canvas.releasePointerCapture(e)}catch{}}computeWorldDeadzoneRadius(){const e=this.callbacks.clientToWorld(0,0),t=this.callbacks.clientToWorld(Math.max(g.CANCEL_DEADZONE_PX,18),0);return Math.max(18,Math.abs(t.x-e.x))}updateHoverDirectAim(e,t){const s=this.callbacks.clientToWorld(e,t),i=this.callbacks.getLauncherPos();if(s.y<=i.y-6)return;const a=s.x-i.x,n=Math.max(20,s.y-i.y),c=Math.atan2(n,a),o=K(g.MIN_AIM_DEG),l=K(g.MAX_AIM_DEG);this.currentAngleRad=P(c,o,l),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)}updateAimFromPointer(e,t){const s=this.callbacks.getAimMode(),i=e-this.dragStartCss.x,a=t-this.dragStartCss.y,n=Math.hypot(i,a),c=this.callbacks.clientToWorld(this.dragStartCss.x,this.dragStartCss.y),o=this.callbacks.clientToWorld(e,t),l=this.computeWorldDeadzoneRadius();if(s==="slingshot"){const v=Math.max(g.CANCEL_DEADZONE_PX,18);if(n<v||a>22){this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,{mode:s,dragging:!0,canceled:!0,originWorld:c,currentWorld:o,deadzoneWorldRadius:l});return}const k=-i,S=Math.max(24,28-a);this.isCanceled=!1;const w=Math.atan2(S,k),A=K(g.MIN_AIM_DEG),$=K(g.MAX_AIM_DEG);this.currentAngleRad=P(w,A,$),this.callbacks.onAimUpdate(this.currentAngleRad,!1,{mode:s,dragging:!0,canceled:!1,originWorld:c,currentWorld:o,deadzoneWorldRadius:l});return}const r=this.callbacks.getLauncherPos(),h=Math.hypot(o.x-r.x,o.y-r.y);if(o.y<r.y-12||n<6&&h<18){this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,{mode:s,dragging:!0,canceled:!0,originWorld:r,currentWorld:o,deadzoneWorldRadius:22});return}this.isCanceled=!1;const y=o.x-r.x,p=Math.max(20,o.y-r.y),u=Math.atan2(p,y),_=K(g.MIN_AIM_DEG),b=K(g.MAX_AIM_DEG);this.currentAngleRad=P(u,_,b),this.callbacks.onAimUpdate(this.currentAngleRad,!1,{mode:s,dragging:!0,canceled:!1,originWorld:r,currentWorld:o,deadzoneWorldRadius:22})}destroy(){this.canvas.removeEventListener("pointerdown",this.onPointerDown),window.removeEventListener("pointermove",this.onPointerMove),window.removeEventListener("pointerup",this.onPointerUp),window.removeEventListener("pointercancel",this.onPointerCancel),window.removeEventListener("blur",this.onWindowBlur),this.canvas.removeEventListener("contextmenu",this.onContextMenu),window.removeEventListener("wheel",this.onWheel),window.removeEventListener("keydown",this.onKeyDown)}}class $t{constructor(){d(this,"current","BOOT");d(this,"pausedFrom",null);d(this,"listeners",[])}get state(){return this.current}onChange(e){return this.listeners.push(e),()=>{this.listeners=this.listeners.filter(t=>t!==e)}}transition(e){if(e===this.current)return;const t=this.current;this.current=e;for(const s of this.listeners)s(e,t)}pauseForAd(){this.current!=="AD_PAUSED"&&(this.pausedFrom=this.current,this.transition("AD_PAUSED"))}resumeFromAd(){if(this.current!=="AD_PAUSED")return;const e=this.pausedFrom??"AIMING";this.pausedFrom=null,this.transition(e)}}const Gt=24;class qt{constructor(e){d(this,"canvas");d(this,"layout");d(this,"onResizeCb",null);d(this,"handleResize",()=>{this.layout=this.computeLayout(),this.applyCanvasSize(),this.onResizeCb?.(this.layout)});this.canvas=e,this.layout=this.computeLayout(),this.applyCanvasSize(),window.addEventListener("resize",this.handleResize)}onResize(e){this.onResizeCb=e}getLayout(){return this.layout}computeLayout(){const e=Math.max(320,window.innerWidth),t=Math.max(400,window.innerHeight),s=Math.min(3,Math.max(1,window.devicePixelRatio||1)),i=t>e*1.05,a=g.SHAFT_WIDTH+Gt*2,n=i?e/a:Math.min(e*.48,560)/g.SHAFT_WIDTH,c=g.SHAFT_WIDTH*n,o=(e-c)*.5;return{cssWidth:e,cssHeight:t,dpr:s,scale:n,shaftX:o,shaftWidthPx:c,isPortrait:i}}applyCanvasSize(){const{cssWidth:e,cssHeight:t,dpr:s}=this.layout;this.canvas.width=Math.round(e*s),this.canvas.height=Math.round(t*s),this.canvas.style.width=`${e}px`,this.canvas.style.height=`${t}px`}clientToWorld(e,t,s){const i=this.canvas.getBoundingClientRect(),a=e-i.left,n=t-i.top,{shaftX:c,scale:o}=this.layout;return{x:(a-c)/o,y:n/o+s}}destroy(){window.removeEventListener("resize",this.handleResize)}}const Y={biome_quarry:"Sunlit Quarry",biome_crystal:"Crystal Caverns",biome_magma:"Magma Foundry",biome_subzero:"Subzero Abyss",biome_cyber:"Cyber Neon Vault",biome_quantum:"Quantum Core",upg_damage:"Drill Damage",upg_damage_desc:"Smash harder & cleave weak blocks",upg_bounces:"Max Bounces",upg_bounces_desc:"More stamina per orb launch",upg_multiorb:"Multi-Orb Volley",upg_multiorb_desc:"Fire extra sawblades per shot",upg_orbsize:"Orb Size & Blast",upg_orbsize_desc:"Bigger blades & wider TNT blasts",upg_luck:"TNT & Bumper Luck",upg_luck_desc:"More explosives & bumpers in shaft",upg_orevalue:"Ore Value",upg_orevalue_desc:"Boosts all coin drops",depth:"DEPTH",coins:"COINS",bounces:"BOUNCES",shards:"SHARDS",recall:"Recall",fast_forward:"2x Speed",drag_to_shoot:"DRAG TO AIM & RELEASE",upgrades:"Upgrades",skins:"Skins",quests:"Quests",daily_login:"Daily Streak",settings:"Settings",elevator:"Elevator",prestige:"Core Overclock",prestige_desc:"Reset upgrades for +50% permanent Damage & Coins per level",prestige_btn:"OVERCLOCK NOW",launch_again:"Launch Again",continue_btn:"Continue",double_run_cta:"2x Coins (Ad)",extra_launch_cta:"+1 Bonus Launch (Ad)",free_upgrade_cta:"Free Level (Ad)",overdrive_cta:"Super-Orb Trial (Ad)",welcome_back:"Welcome Back!",offline_earned:"Auto-Drill mined while you were away:",collect:"Collect",collect_2x:"Collect 2x (Ad)",claim:"Claim",claimed:"Claimed",equip:"Equip",select_btn:"SELECT",equipped:"EQUIPPED",new_best_badge:"NEW BEST!",unlock_ad:"Watch Ad (+1/3)",unlock_shards:"Unlock (10 Shards)",daily_mega_chest:"Daily Mega Chest",run_complete:"Run Complete",earned_coins:"Coins Earned",max_depth:"Max Depth",ad_unavailable:"Ad unavailable right now",ad_incomplete:"Watch full video to claim reward",short_break:"Short Break...",aim_slingshot:"Slingshot Pull",aim_direct:"Direct Aim",boss_gate:"BEDROCK GATE",biome_unlocked_title:"BIOME UNLOCKED!",biome_unlocked_desc:"Elevator Checkpoint Active",descend_now:"Descend Now",coin_mult_badge:"Coin Multiplier",skin_unlocked_badge:"Skin Unlocked",overheat_recall:"OVERHEAT RECALL",maxed:"MAX",paused:"Paused",resume:"Resume",restart_run:"Restart Run",home_btn:"Home",play_btn:"PLAY",best_depth:"Best Depth",language_label:"Language",sfx_label:"Sound FX",music_label:"Music",aim_mode_label:"Aim Mode",reset_progress:"Reset Progress",reset_confirm_desc:"Reset all coins, upgrades, depth, quests, and skins back to Run 1? This cannot be undone.",cancel_btn:"Cancel",confirm_reset_btn:"Confirm Reset",super_orb_label:"Super-Orb",free_ad_sub:"FREE (AD)",streak_short:"Streak",skin_steel_sawblade:"Steel Sawblade",skin_copper_gear:"Copper Gear Grinder",skin_emerald_buzzsaw:"Emerald Buzzsaw",skin_magma_cutter:"Molten Magma Cutter",skin_frost_star:"Glacial Frost Star",skin_gold_chakram:"Royal Gold Chakram",skin_tesla_rotor:"Tesla Plasma Rotor",skin_toxic_drill:"Toxic Bio-Drill",skin_void_reaper:"Obsidian Void Reaper",skin_unlock_default:"Starter Blade",skin_unlock_copper:"Buy with Coins",skin_unlock_biome_1:"Break Quarry Boss Gate",skin_unlock_biome_2:"Break Crystal Boss Gate",skin_unlock_biome_3:"Break Magma Boss Gate",skin_unlock_biome_4:"Reach Quantum Core",skin_unlock_combo:"Reach 40-Bounce Combo",skin_unlock_toxic:"Coins or 3 Rewarded Ads",skin_unlock_day7:"Day 7 Streak or Coins",quest_tnt:"Detonate 20 TNT Crates",quest_bumpers:"Hit 35 Pinball Bumpers",quest_blocks:"Destroy 120 Ore Blocks",quest_runs:"Complete 8 Runs",quest_vaults:"Break 3 Vault Chests",reward_300_coins:"300 Coins",reward_free_damage:"+1 Damage Level",reward_5_shards:"5 Skin Shards",reward_1500_coins:"1,500 Coins",reward_overdrive_pass:"3x Super-Orb Passes",reward_10_shards:"10 Skin Shards",reward_golden_skin:"Royal Gold Chakram",achievements:"Achievements",hall_of_ascension:"Hall of Ascension",ascension_milestones:"Ascension Milestones",mastery_feats:"Mastery Feats",full_shaft_run:"FULL-SHAFT RUN",tier_label:"Tier",no_ascension_yet:"Tier 0 (Unascended)",one_shot_victory:"ONE-SHOT VICTORY!",blocks_smashed:"Blocks Smashed",max_combo_label:"Max Combo",next_tier_label:"Next Tier",next_tier_preview:"2x Enemy HP • 1.65x Coins • +10 Max Lvls • +15% DMG",descend_to_tier:"DESCEND TO TIER {tier} (2x HARDER)",double_victory_coins:"2x VICTORY COINS (AD)",elevator_clear_title:"BIOME 6 CLEARED!",elevator_clear_desc:"Now clear all biomes in ONE shot from 0m to unlock Tier {tier} (2x Harder)!",start_0m_run:"Start 0m Run",asc_req_hint:"Clear 0m to 1550m in one launch for Tier {tier}",asc_tier_1_title:"Quarry Legend",asc_tier_1_quote:"One launch. Six biomes. Zero mercy. The bedrock remembers your blade.",asc_tier_2_title:"Tectonic Breaker",asc_tier_2_quote:"Double the stone, twice the glory. You tore straight through the planet's crust.",asc_tier_3_title:"Core Annihilator",asc_tier_3_quote:"Not even magma and steel could slow your ricochet. Pure precision.",asc_tier_4_title:"Abyssal God",asc_tier_4_quote:"You have conquered the impossible depth in a single breath. The mine bows to you.",feat_chain_title:"Chain Detonator",feat_chain_desc:"Trigger 5+ TNT explosions in a single launch",feat_combo_title:"Combo Master",feat_combo_desc:"Reach a 50+ hit combo in one shot",feat_investor_title:"Heavy Investor",feat_investor_desc:"Upgrade any stat to Level 20+",feat_zeroskip_title:"Zero-Skip Purist",feat_zeroskip_desc:"Reach Biome 4 in one shot from 0m",vol_off:"OFF",vol_low:"LOW",vol_high:"HIGH"},Ht={...Y,vol_off:"ВЫКЛ",vol_low:"ТИХО",vol_high:"ГРОМКО",biome_quarry:"Солнечный Карьер",biome_crystal:"Кристальные Пещеры",biome_magma:"Магмовая Кузня",biome_subzero:"Ледяная Бездна",biome_cyber:"Кибер-Неон",biome_quantum:"Квантовое Ядро",upg_damage:"Урон Бура",upg_damage_desc:"Мощнее удар и пробитие блоков",upg_bounces:"Макс. Отскоков",upg_bounces_desc:"Больше энергии на запуск",upg_multiorb:"Мульти-Залп",upg_multiorb_desc:"Дополнительные пилы за выстрел",upg_orbsize:"Размер и Взрыв",upg_orbsize_desc:"Крупнее пилы и радиус TNT",upg_luck:"Удача TNT",upg_luck_desc:"Больше TNT и бамперов",upg_orevalue:"Ценность Руды",upg_orevalue_desc:"Больше монет из блоков",depth:"ГЛУБИНА",coins:"МОНЕТЫ",bounces:"ОТСКОКИ",shards:"ОСКОЛКИ",recall:"Возврат",fast_forward:"2x Скорость",drag_to_shoot:"ТЯНИТЕ И ОТПУСТИТЕ",upgrades:"Улучшения",skins:"Скины",quests:"Квесты",daily_login:"Награды",settings:"Настройки",elevator:"Лифт",prestige:"Разгон Ядра",prestige_btn:"РАЗГОН ЯДРА",launch_again:"Запуск Снова",continue_btn:"Продолжить",double_run_cta:"2x Монеты (Реклама)",extra_launch_cta:"+1 Запуск (Реклама)",free_upgrade_cta:"Бесплатно (Реклама)",overdrive_cta:"Супер-Шар (Реклама)",welcome_back:"С возвращением!",offline_earned:"Авто-Бур добыл в ваше отсутствие:",collect:"Забрать",collect_2x:"Забрать 2x",claim:"Получить",claimed:"Получено",equip:"Выбрать",select_btn:"ВЫБРАТЬ",equipped:"ВЫБРАНО",new_best_badge:"НОВЫЙ РЕКОРД!",run_complete:"Забег Завершён",earned_coins:"Заработано",max_depth:"Макс. Глубина",paused:"Пауза",resume:"Продолжить",restart_run:"Перезапуск",home_btn:"Домой",play_btn:"ИГРАТЬ",best_depth:"Рекорд",language_label:"Язык",sfx_label:"Звуки",music_label:"Музыка",aim_mode_label:"Прицел",reset_progress:"Сбросить прогресс",reset_confirm_desc:"Сбросить все монеты, улучшения, глубину, квесты и скины? Это действие необратимо.",cancel_btn:"Отмена",confirm_reset_btn:"Сбросить",super_orb_label:"Супер-Шар",free_ad_sub:"БЕСПЛАТНО (АД)",streak_short:"Серия",skin_steel_sawblade:"Стальная Пила",skin_copper_gear:"Медная Шестерня",skin_emerald_buzzsaw:"Изумрудная Пила",skin_magma_cutter:"Магма-Резак",skin_frost_star:"Ледяная Звезда",skin_gold_chakram:"Золотая Чакра",skin_tesla_rotor:"Тесла-Ротор",skin_toxic_drill:"Токсик-Бур",skin_void_reaper:"Жнец Бездны",achievements:"Достижения",hall_of_ascension:"Зал Вознесения",ascension_milestones:"Вехи Вознесения",mastery_feats:"Подвиги Мастерства",full_shaft_run:"ПОЛНЫЙ СПУСК 0м",tier_label:"Ранг",no_ascension_yet:"Ранг 0 (Обычный)",one_shot_victory:"ПОБЕДА С ОДНОГО ЗАПУСКА!",blocks_smashed:"Разбито блоков",max_combo_label:"Макс. комбо",next_tier_label:"След. ранг",next_tier_preview:"2x HP • 1.65x Монеты • +10 Макс. Ур. • +15% Урон",descend_to_tier:"СПУСК НА РАНГ {tier} (В 2x СЛОЖНЕЕ)",double_victory_coins:"2x МОНЕТЫ ПОБЕДЫ (АД)",elevator_clear_title:"БИОМ 6 ПРОЙДЕН!",elevator_clear_desc:"Пройдите все биомы за ОДИН запуск с 0м, чтобы открыть Ранг {tier} (в 2x сложнее)!",start_0m_run:"Забег с 0м",asc_tier_1_title:"Легенда Карьера",asc_tier_2_title:"Тектонический Крушитель",asc_tier_3_title:"Истребитель Ядра",asc_tier_4_title:"Бог Бездны",feat_chain_title:"Цепной Подрывник",feat_combo_title:"Мастер Комбо",feat_investor_title:"Крупный Инвестор",feat_zeroskip_title:"Пурист Без Лифта"},zt={...Y,vol_off:"NO",vol_low:"BAJO",vol_high:"ALTO",biome_quarry:"Cantera Soleada",biome_crystal:"Cavernas de Cristal",biome_magma:"Forja de Magma",biome_subzero:"Abismo Glacial",biome_cyber:"Bóveda Ciber Neón",biome_quantum:"Núcleo Cuántico",upg_damage:"Daño de Taladro",upg_bounces:"Rebotes Máx.",upg_multiorb:"Salva Múltiple",upg_orbsize:"Tamaño y Explosión",upg_luck:"Suerte TNT",upg_orevalue:"Valor de Mineral",drag_to_shoot:"ARRASTRA Y SUELTA",select_btn:"ELEGIR",new_best_badge:"¡NUEVO RÉCORD!",upgrades:"Mejoras",skins:"Aspectos",quests:"Misiones",daily_login:"Racha",settings:"Ajustes",elevator:"Ascensor",launch_again:"Lanzar de Nuevo",continue_btn:"Continuar",paused:"Pausa",resume:"Reanudar",restart_run:"Reiniciar",home_btn:"Inicio",play_btn:"JUGAR",best_depth:"Mejor Prof.",language_label:"Idioma",sfx_label:"Efectos",music_label:"Música",aim_mode_label:"Apuntado",reset_progress:"Reiniciar Progreso",reset_confirm_desc:"¿Reiniciar monedas, mejoras, profundidad, misiones y aspectos al inicio?",cancel_btn:"Cancelar",confirm_reset_btn:"Confirmar",super_orb_label:"Súper-Orbe",free_ad_sub:"GRATIS (ANUNCIO)",streak_short:"Racha",achievements:"Logros",hall_of_ascension:"Salón de Ascensión",ascension_milestones:"Hitos de Ascensión",mastery_feats:"Hazañas de Maestría",full_shaft_run:"DESCENSO 0m",tier_label:"Nivel",one_shot_victory:"¡VICTORIA DE UN TIRO!",blocks_smashed:"Bloques Rotos",max_combo_label:"Combo Máx.",descend_to_tier:"DESCENDER AL NIVEL {tier} (2x MÁS DIFÍCIL)",double_victory_coins:"2x MONEDAS (ANUNCIO)",elevator_clear_title:"¡BIOMA 6 SUPERADO!",elevator_clear_desc:"¡Supera todos los biomas de UN tiro desde 0m para desbloquear el Nivel {tier}!",start_0m_run:"Iniciar desde 0m"},Wt={...Y,vol_off:"DESL",vol_low:"BAIXO",vol_high:"ALTO",biome_quarry:"Pedreira Solar",biome_crystal:"Cavernas de Cristal",biome_magma:"Forja de Magma",biome_subzero:"Abismo Glacial",biome_cyber:"Cofre Cyber Neon",biome_quantum:"Núcleo Quântico",upg_damage:"Dano da Broca",upg_bounces:"Ricochetes Máx.",upg_multiorb:"Disparo Múltiplo",upg_orbsize:"Tamanho e Explosão",upg_luck:"Sorte TNT",upg_orevalue:"Valor do Minério",drag_to_shoot:"ARRASTE E SOLTE",select_btn:"SELECIONAR",new_best_badge:"NOVO RECORDE!",upgrades:"Melhorias",skins:"Visuais",quests:"Missões",daily_login:"Diário",settings:"Opções",elevator:"Elevador",launch_again:"Lançar Novamente",continue_btn:"Continuar",paused:"Pausado",resume:"Continuar",restart_run:"Reiniciar",home_btn:"Início",play_btn:"JOGAR",best_depth:"Recorde",language_label:"Idioma",sfx_label:"Efeitos",music_label:"Música",aim_mode_label:"Mira",reset_progress:"Resetar Progresso",reset_confirm_desc:"Resetar todas as moedas, melhorias, profundidade e visuais para o início?",cancel_btn:"Cancelar",confirm_reset_btn:"Confirmar",super_orb_label:"Super-Orbe",free_ad_sub:"GRÁTIS (ANÚNCIO)",streak_short:"Diário",achievements:"Conquistas",hall_of_ascension:"Salão da Ascensão",full_shaft_run:"DESCIDA 0m",tier_label:"Nível",one_shot_victory:"VITÓRIA EM UM TIRO!",blocks_smashed:"Blocos Quebrados",max_combo_label:"Combo Máx.",descend_to_tier:"DESCER AO NÍVEL {tier} (2x MAIS DIFÍCIL)",double_victory_coins:"2x MOEDAS (ANÚNCIO)",elevator_clear_title:"BIOMA 6 CONCLUÍDO!",elevator_clear_desc:"Limpe todos os biomas em UM tiro a partir de 0m para desbloquear o Nível {tier}!",start_0m_run:"Iniciar de 0m"},Kt={...Y,vol_off:"NON",vol_low:"BAS",vol_high:"HAUT",biome_quarry:"Carrière Ensoleillée",biome_crystal:"Cavernes de Cristal",biome_magma:"Forge de Magma",biome_subzero:"Abysse Glaciaire",biome_cyber:"Coffre Cyber Néon",biome_quantum:"Cœur Quantique",upg_damage:"Dégâts Foreuse",upg_bounces:"Rebonds Max",upg_multiorb:"Salve Multiple",upg_orbsize:"Taille & Explosion",upg_luck:"Chance TNT",upg_orevalue:"Valeur Minerai",drag_to_shoot:"GLISSER ET RELÂCHER",select_btn:"CHOISIR",new_best_badge:"NOUVEAU RECORD !",upgrades:"Améliorations",skins:"Apparences",quests:"Quêtes",daily_login:"Série",settings:"Paramètres",elevator:"Ascenseur",launch_again:"Relancer",continue_btn:"Continuer",paused:"Pause",resume:"Reprendre",restart_run:"Recommencer",home_btn:"Accueil",play_btn:"JOUER",best_depth:"Record",language_label:"Langue",sfx_label:"Effets",music_label:"Musique",aim_mode_label:"Visée",reset_progress:"Réinitialiser",reset_confirm_desc:"Réinitialiser pièces, améliorations, profondeur, quêtes et apparences ?",cancel_btn:"Annuler",confirm_reset_btn:"Confirmer",super_orb_label:"Super-Orbe",free_ad_sub:"GRATUIT (PUB)",streak_short:"Série",achievements:"Succès",hall_of_ascension:"Hall de l'Ascension",full_shaft_run:"DESCENTE 0m",tier_label:"Palier",one_shot_victory:"VICTOIRE EN UN COUP !",blocks_smashed:"Blocs Détruits",max_combo_label:"Combo Max",descend_to_tier:"DESCENDRE AU PALIER {tier} (2x PLUS DUR)",double_victory_coins:"2x PIÈCES (PUB)",elevator_clear_title:"BIOME 6 TERMINÉ !",elevator_clear_desc:"Terminez tous les biomes en UN coup depuis 0m pour débloquer le Palier {tier} !",start_0m_run:"Lancer à 0m"},jt={...Y,vol_off:"AUS",vol_low:"LEISE",vol_high:"LAUT",biome_quarry:"Sonnensteinbruch",biome_crystal:"Kristallhöhlen",biome_magma:"Magmaschmiede",biome_subzero:"Eis-Abgrund",biome_cyber:"Cyber-Neon-Tresor",biome_quantum:"Quantenkern",upg_damage:"Bohrschaden",upg_bounces:"Max. Abpraller",upg_multiorb:"Mehrfach-Salve",upg_orbsize:"Größe & Sprengung",upg_luck:"TNT-Glück",upg_orevalue:"Erzwert",drag_to_shoot:"ZIEHEN & LOSLASSEN",select_btn:"WÄHLEN",new_best_badge:"NEUER REKORD!",upgrades:"Upgrades",skins:"Skins",quests:"Quests",daily_login:"Serie",settings:"Optionen",elevator:"Aufzug",launch_again:"Erneut Feuern",continue_btn:"Weiter",paused:"Pausiert",resume:"Fortsetzen",restart_run:"Neu starten",home_btn:"Startseite",play_btn:"SPIELEN",best_depth:"Rekord",language_label:"Sprache",sfx_label:"Sound-FX",music_label:"Musik",aim_mode_label:"Zielmodus",reset_progress:"Fortschritt zurücksetzen",reset_confirm_desc:"Alle Münzen, Upgrades, Tiefe, Quests und Skins zurücksetzen?",cancel_btn:"Abbrechen",confirm_reset_btn:"Zurücksetzen",super_orb_label:"Super-Orb",free_ad_sub:"GRATIS (WERBUNG)",streak_short:"Serie",achievements:"Erfolge",hall_of_ascension:"Halle des Aufstiegs",full_shaft_run:"VOLLSCHACHT 0m",tier_label:"Stufe",one_shot_victory:"ONE-SHOT-SIEG!",blocks_smashed:"Blöcke Zerstört",max_combo_label:"Max. Kombo",descend_to_tier:"ABSTIEG ZU STUFE {tier} (2x SCHWERER)",double_victory_coins:"2x SIEGMÜNZEN (WERBUNG)",elevator_clear_title:"BIOM 6 GESCHAFFT!",elevator_clear_desc:"Schaffe alle Biome in EINEM Schuss ab 0m für Stufe {tier} (2x schwerer)!",start_0m_run:"0m-Lauf Starten"},Yt={...Y,vol_off:"KAPALI",vol_low:"KISIK",vol_high:"YÜKSEK",biome_quarry:"Güneşli Ocak",biome_crystal:"Kristal Mağaralar",biome_magma:"Magma Ocağı",biome_subzero:"Buzul Uçurum",biome_cyber:"Siber Neon Kasa",biome_quantum:"Kuantum Çekirdek",upg_damage:"Matkap Hasarı",upg_bounces:"Maks. Sekme",upg_multiorb:"Çoklu Atış",upg_orbsize:"Boyut ve Patlama",upg_luck:"TNT Şansı",upg_orevalue:"Maden Değeri",drag_to_shoot:"ÇEK VE BIRAK",select_btn:"SEÇ",new_best_badge:"YENİ REKOR!",upgrades:"Geliştirmeler",skins:"Görünümler",quests:"Görevler",daily_login:"Günlük",settings:"Ayarlar",elevator:"Asansör",launch_again:"Tekrar Fırlat",continue_btn:"Devam Et",paused:"Duraklatıldı",resume:"Devam Et",restart_run:"Yeniden Başlat",home_btn:"Ana Sayfa",play_btn:"OYNA",best_depth:"En Derin",language_label:"Dil",sfx_label:"Ses Efektleri",music_label:"Müzik",aim_mode_label:"Nişan Modu",reset_progress:"İlerlemeyi Sıfırla",reset_confirm_desc:"Tüm altınlar, geliştirmeler, derinlik ve görünümler sıfırlansın mı?",cancel_btn:"İptal",confirm_reset_btn:"Sıfırla",super_orb_label:"Süper Küre",free_ad_sub:"ÜCRETSİZ (REKLAM)",streak_short:"Seri",achievements:"Başarılar",hall_of_ascension:"Yükseliş Salonu",full_shaft_run:"TAM İNİŞ 0m",tier_label:"Kademe",one_shot_victory:"TEK ATIŞ ZAFERİ!",blocks_smashed:"Kırılan Bloklar",max_combo_label:"Maks. Kombo",descend_to_tier:"KADEME {tier} İNİŞİ (2x ZOR)",double_victory_coins:"2x ZAFER ALTINI (REKLAM)",elevator_clear_title:"BİYOM 6 TEMİZLENDİ!",elevator_clear_desc:"Kademe {tier} kilidini açmak için 0m noktasından TEK atışla tüm biyomları geç!",start_0m_run:"0m İnişi Başlat"},Qt={...Y,vol_off:"OFF",vol_low:"小",vol_high:"大",biome_quarry:"陽光採石場",biome_crystal:"クリスタル洞窟",biome_magma:"マグマ溶鉱炉",biome_subzero:"氷結の深淵",biome_cyber:"サイバーネオン金庫",biome_quantum:"クォンタムコア",upg_damage:"ドリル攻撃力",upg_bounces:"最大バウンド",upg_multiorb:"マルチショット",upg_orbsize:"サイズ＆爆発",upg_luck:"TNT＆バンパー運",upg_orevalue:"鉱石価値",drag_to_shoot:"ドラッグして発射",select_btn:"選択",new_best_badge:"新記録！",upgrades:"強化",skins:"スキン",quests:"クエスト",daily_login:"ログイン",settings:"設定",elevator:"エレベーター",launch_again:"もう一度発射",continue_btn:"続ける",paused:"一時停止",resume:"再開",restart_run:"リスタート",home_btn:"ホーム",play_btn:"プレイ",best_depth:"最高深度",language_label:"言語",sfx_label:"効果音",music_label:"BGM",aim_mode_label:"照準モード",reset_progress:"データ初期化",reset_confirm_desc:"コイン、強化、深度、クエスト、スキンをすべて初期化しますか？",cancel_btn:"キャンセル",confirm_reset_btn:"初期化する",super_orb_label:"スーパーオーブ",free_ad_sub:"無料 (広告)",streak_short:"連続",achievements:"実績",hall_of_ascension:"昇天の殿堂",full_shaft_run:"0m一発踏破",tier_label:"ティア",one_shot_victory:"一発完全勝利！",blocks_smashed:"破壊ブロック",max_combo_label:"最大コンボ",descend_to_tier:"ティア {tier} へ降下 (難易度2倍)",double_victory_coins:"2倍勝利コイン (広告)",elevator_clear_title:"バイオーム6制覇！",elevator_clear_desc:"0mから一発で全バイオームを突破してティア {tier} を解放しよう！",start_0m_run:"0mから挑戦"},Xt={...Y,vol_off:"끔",vol_low:"약함",vol_high:"큼",biome_quarry:"햇빛 채석장",biome_crystal:"수정 동굴",biome_magma:"마그마 용광로",biome_subzero:"빙하 심연",biome_cyber:"사이버 네온 금고",biome_quantum:"퀀텀 코어",upg_damage:"드릴 공격력",upg_bounces:"최대 바운스",upg_multiorb:"멀티 발사",upg_orbsize:"크기 및 폭발",upg_luck:"TNT 및 범퍼 운",upg_orevalue:"광물 가치",drag_to_shoot:"드래그하여 발사",select_btn:"선택",new_best_badge:"신기록!",upgrades:"업그레이드",skins:"스킨",quests:"퀘스트",daily_login:"출석",settings:"설정",elevator:"엘리베이터",launch_again:"다시 발사",continue_btn:"계속하기",paused:"일시정지",resume:"계속하기",restart_run:"다시 시작",home_btn:"홈",play_btn:"플레이",best_depth:"최고 깊이",language_label:"언어",sfx_label:"효과음",music_label:"배경음",aim_mode_label:"조준 모드",reset_progress:"진행 초기화",reset_confirm_desc:"모든 코인, 업그레이드, 깊이, 퀘스트 및 스킨을 초기화할까요?",cancel_btn:"취소",confirm_reset_btn:"초기화",super_orb_label:"슈퍼 오브",free_ad_sub:"무료 (광고)",streak_short:"연속",achievements:"업적",hall_of_ascension:"승천의 전당",full_shaft_run:"0m 원샷 도전",tier_label:"티어",one_shot_victory:"원샷 완전 승리!",blocks_smashed:"파괴한 블록",max_combo_label:"최대 콤보",descend_to_tier:"티어 {tier} 강하 (2배 어려움)",double_victory_coins:"2배 승리 코인 (광고)",elevator_clear_title:"바이옴 6 클리어!",elevator_clear_desc:"0m부터 원샷으로 모든 바이옴을 돌파해 티어 {tier}를 해금하세요!",start_0m_run:"0m 도전 시작"},Ge={en:Y,ru:Ht,es:zt,pt:Wt,fr:Kt,de:jt,tr:Yt,ja:Qt,ko:Xt};class Zt{constructor(){d(this,"locale","en")}setLocale(e){if(!e){this.locale="en";return}const t=e.toLowerCase().slice(0,2);this.locale=t in Ge?t:"en"}getLocale(){return this.locale}t(e){return Ge[this.locale]?.[e]??Y[e]}}const f=new Zt,qe=.15,He=14,Jt=4.5;class z{static onWallBounce(e){e.consecutiveWallHits++,e.y<=e.maxProgressY+12?e.nonProgressBounces++:e.maxProgressY=e.y;const t=z.computeHeightStdDev(e),s=e.heightSampleCount>=6&&t<He&&(e.consecutiveWallHits>=2||e.nonProgressBounces>=4);(e.consecutiveWallHits>=g.HORIZONTAL_TRAP_WALL_HITS||s)&&(e.consecutiveWallHits=0,e.nonProgressBounces=0,z.deflectDownward(e,s?14:g.HORIZONTAL_TRAP_DEFLECT_DEG))}static onIndestructibleHit(e){e.y<=e.maxProgressY+12?e.nonProgressBounces++:e.maxProgressY=e.y;const t=z.computeHeightStdDev(e);(e.nonProgressBounces>=5||e.heightSampleCount>=6&&t<He&&e.nonProgressBounces>=3)&&(e.nonProgressBounces=0,z.deflectDownward(e,14))}static onBlockHit(e){e.consecutiveWallHits=0,e.nonProgressBounces=0,e.timeSinceProgress=0,e.overheatDraining=!1,e.stallBoostApplied=!1,e.y>e.maxProgressY&&(e.maxProgressY=e.y)}static updateStallWatchdog(e,t){if(e.y>e.maxProgressY+24&&(e.maxProgressY=e.y,e.nonProgressBounces=0),e.heightSampleTimer+=t,e.heightSampleTimer>=qe){e.heightSampleTimer-=qe;const s=e.heightSamples.length;e.heightSamples[e.heightSampleCursor]=e.y,e.heightSampleCursor=(e.heightSampleCursor+1)%s,e.heightSampleCount<s&&e.heightSampleCount++}if(e.timeSinceProgress+=t,e.timeSinceProgress>=Jt){if(e.overheatDraining=!0,!e.stallBoostApplied){e.stallBoostApplied=!0;const i=Math.hypot(e.vx,e.vy);if(i>1e-4){const n=Math.min(g.MAX_ORB_SPEED,i*2)/i;e.vx*=n,e.vy*=n}}const s=e.timeSinceProgress>=g.OVERHEAT_STALL_SECONDS?14:4.5;if(e.bouncesLeft=Math.max(0,e.bouncesLeft-t*s),e.bouncesLeft<=0)return e.alive=!1,!0}return!1}static computeHeightStdDev(e){const t=e.heightSampleCount;if(t<2)return Number.POSITIVE_INFINITY;let s=0;for(let n=0;n<t;n++)s+=e.heightSamples[n];const i=s/t;let a=0;for(let n=0;n<t;n++){const c=e.heightSamples[n]-i;a+=c*c}return Math.sqrt(a/t)}static deflectDownward(e,t){const s=K(t),i=Math.hypot(e.vx,e.vy),a=e.vx>=0?1:-1,n=Math.atan2(Math.abs(e.vy),Math.abs(e.vx)),c=Math.min(Math.PI/2-.08,n+s);e.vx=a*Math.cos(c)*i,e.vy=Math.sin(c)*i,e.y+=2}}class es{constructor(){d(this,"buckets",new Map);d(this,"activeKeys",[]);d(this,"queryResult",[]);d(this,"visitedStamp",new Map);d(this,"querySeq",0)}rebuild(e){for(let t=0;t<this.activeKeys.length;t++){const s=this.buckets.get(this.activeKeys[t]);s&&(s.length=0)}this.activeKeys.length=0;for(let t=0;t<e.length;t++){const s=e[t];if(s.alive)for(let i=0;i<s.colSpan;i++){const a=this.key(s.col+i,s.row);let n=this.buckets.get(a);n||(n=[],this.buckets.set(a,n)),n.length===0&&this.activeKeys.push(a),n.push(s)}}}queryCircle(e,t,s){const i=g.TILE_SIZE,a=Math.max(0,Math.floor((e-s)/i)),n=Math.min(g.GRID_COLS-1,Math.floor((e+s)/i)),c=Math.max(0,Math.floor((t-s)/i)),o=Math.floor((t+s)/i);this.queryResult.length=0,this.querySeq++,this.querySeq>=2147483647&&(this.visitedStamp.clear(),this.querySeq=1);const l=this.querySeq;for(let r=c;r<=o;r++)for(let h=a;h<=n;h++){const y=this.buckets.get(this.key(h,r));if(!(!y||y.length===0))for(let p=0;p<y.length;p++){const u=y[p];u.alive&&this.visitedStamp.get(u.id)!==l&&(this.visitedStamp.set(u.id,l),this.queryResult.push(u))}}return this.queryResult}isCellOccupied(e,t,s){if(e<0||e>=g.GRID_COLS||t<0)return!0;const i=this.buckets.get(this.key(e,t));if(i){for(let a=0;a<i.length;a++)if(i[a].alive)return!0}for(let a=0;a<s.length;a++){const n=s[a];if(n.alive&&n.row===t&&e>=n.col&&e<n.col+n.colSpan)return!0}return!1}key(e,t){return t*32+e}}const ze=14,ts=16;class ss{constructor(e={}){d(this,"grid",new es);d(this,"nextOrbId",1);d(this,"events");d(this,"cloneBuffer",[]);this.events=e}setEvents(e){this.events=e}createOrb(e,t,s,i,a,n,c=!1,o=!1){const l=g.LAUNCH_SPEED*(o?1.08:1),r=[];for(let y=0;y<ze;y++)r.push({x:e,y:t});const h=new Array(ts).fill(t);return{id:this.nextOrbId++,x:e,y:t,prevX:e,prevY:t,vx:Math.cos(s)*l,vy:Math.sin(s)*l,radius:i,bouncesLeft:a,maxBounces:a,damage:n,rotation:0,comboCount:0,consecutiveWallHits:0,nonProgressBounces:0,maxProgressY:t,timeSinceProgress:0,heightSamples:h,heightSampleCursor:0,heightSampleCount:1,heightSampleTimer:0,overheatDraining:!1,stallBoostApplied:!1,portalCooldown:0,isClone:c,isOverdrive:o,trail:[r[0]],trailPool:r,alive:!0}}step(e,t,s,i,a,n,c=0){this.grid.rebuild(s);for(let l=0;l<s.length;l++){const r=s[l];r.hitFlashTimer>0&&(r.hitFlashTimer=Math.max(0,r.hitFlashTimer-e))}this.cloneBuffer.length=0;let o=0;for(let l=0;l<t.length;l++)t[l].alive&&o++;for(let l=0;l<t.length;l++){const r=t[l];if(!r.alive)continue;r.prevX=r.x,r.prevY=r.y,r.portalCooldown>0&&(r.portalCooldown=Math.max(0,r.portalCooldown-e)),r.vy+=g.GRAVITY*e,this.normalizeOrbSpeed(r);const h=r.vx*e,y=r.vy*e,p=Math.hypot(h,y),u=Math.max(2,r.radius*.35),_=Math.max(1,Math.ceil(p/u)),b=e/_;for(let v=0;v<_&&r.alive;v++){const k=r.x,S=r.y;if(r.x+=r.vx*b,r.y+=r.vy*b,this.resolveWallCollisions(r),!r.alive)break;this.resolveEntityCollisions(r,k,S,o,this.cloneBuffer,s,i,a,n,c),r.alive&&this.enforceWallBounds(r)}r.rotation+=Math.hypot(r.vx,r.vy)/Math.max(8,r.radius)*e*1.4,this.pushTrailPoint(r),r.alive&&z.updateStallWatchdog(r,e)&&this.events.onOrbExpired?.(r)}for(let l=0;l<this.cloneBuffer.length&&!(o>=g.MAX_ACTIVE_ORBS);l++)t.push(this.cloneBuffer[l]),o++}pushTrailPoint(e){if(e.trail.length<ze){const t=e.trailPool[e.trail.length];t.x=e.x,t.y=e.y,e.trail.push(t)}else{const t=e.trail.shift();t.x=e.x,t.y=e.y,e.trail.push(t)}}normalizeOrbSpeed(e){const t=this.clampVelocity(e.vx,e.vy);e.vx=t.vx,e.vy=t.vy}clampVelocity(e,t){const s=Math.hypot(e,t);if(s<1e-5)return{vx:0,vy:g.MIN_ORB_SPEED};if(s<g.MIN_ORB_SPEED){const i=g.MIN_ORB_SPEED/s;return{vx:e*i,vy:t*i}}if(s>g.MAX_ORB_SPEED){const i=g.MAX_ORB_SPEED/s;return{vx:e*i,vy:t*i}}return{vx:e,vy:t}}enforceWallBounds(e){e.x-e.radius<0?(e.x=e.radius,e.vx<0&&(e.vx=Math.abs(e.vx))):e.x+e.radius>g.SHAFT_WIDTH&&(e.x=g.SHAFT_WIDTH-e.radius,e.vx>0&&(e.vx=-Math.abs(e.vx))),e.y-e.radius<0&&(e.y=e.radius,e.vy<0&&(e.vy=Math.abs(e.vy)))}resolveWallCollisions(e){let t=!1;e.x-e.radius<0?(e.x=e.radius,e.vx=Math.abs(e.vx)*g.RESTITUTION_BLOCK,t=!0):e.x+e.radius>g.SHAFT_WIDTH&&(e.x=g.SHAFT_WIDTH-e.radius,e.vx=-Math.abs(e.vx)*g.RESTITUTION_BLOCK,t=!0),e.y-e.radius<0&&(e.y=e.radius,e.vy=Math.abs(e.vy)*g.RESTITUTION_BLOCK,t=!0),t&&(this.normalizeOrbSpeed(e),z.onWallBounce(e),e.bouncesLeft-=g.WALL_BOUNCE_COST,this.events.onWallHit?.(e,e.x,e.y),e.bouncesLeft<=0&&(e.bouncesLeft=0,e.alive=!1,this.events.onOrbExpired?.(e)))}resolveEntityCollisions(e,t,s,i,a,n,c,o,l,r){const h=e.radius+Math.hypot(e.x-t,e.y-s)+6,y=this.grid.queryCircle(e.x,e.y,h);for(let p=0;p<y.length;p++){const u=y[p];if(!u.alive||!e.alive||u.kind==="portal_exit")continue;if(u.kind==="bumper"||u.kind==="portal_entry"){const C=u.x+u.width*.5,R=u.y+u.height*.5,M=e.radius+u.radius,D=this.segmentCircleHit(t,s,e.x,e.y,C,R,M),L=e.x-C,N=e.y-R,G=L*L+N*N;if(G<M*M||D){if(u.kind==="portal_entry"){this.handlePortalEntry(e,u,n);continue}const X=Math.max(.001,Math.sqrt(G)),ie=G>1e-6?L/X:0,ae=G>1e-6?N/X:-1;e.x=C+ie*(M+.5),e.y=R+ae*(M+.5);const pe=e.vx*ie+e.vy*ae;pe<0&&(e.vx-=2*pe*ie,e.vy-=2*pe*ae),e.vx*=g.RESTITUTION_BUMPER,e.vy*=g.RESTITUTION_BUMPER,this.normalizeOrbSpeed(e),e.bouncesLeft=Math.min(e.maxBounces+6,e.bouncesLeft+g.BUMPER_BOUNCE_BONUS),e.comboCount++,z.onBlockHit(e);const Te=Ve(u.depthMeters,"bumper",c,l,r);u.hitFlashTimer=.08,typeof u.hitsRemaining=="number"&&(u.hitsRemaining--,u.hitsRemaining<=0&&(u.alive=!1)),this.events.onBumperHit?.(e,u,Te);continue}continue}let _=P(e.x,u.x,u.x+u.width),b=P(e.y,u.y,u.y+u.height),v=e.x-_,k=e.y-b,S=v*v+k*k;if(S>=e.radius*e.radius){const C=(t+e.x)*.5,R=(s+e.y)*.5,M=P(C,u.x,u.x+u.width),D=P(R,u.y,u.y+u.height),L=C-M,N=R-D,G=L*L+N*N;if(G>=e.radius*e.radius)continue;e.x=C,e.y=R,_=M,b=D,v=L,k=N,S=G}let w=0,A=0;if(S>1e-6){const C=Math.sqrt(S);w=v/C,A=k/C}else{const C=e.x-u.x,R=u.x+u.width-e.x,M=e.y-u.y,D=u.y+u.height-e.y,L=Math.min(C,R,M,D);L===C?w=-1:L===R?w=1:L===M?A=-1:A=1}const $=Number.isFinite(u.hp)&&e.damage>=g.CLEAVE_RATIO*u.hp;if(!$){const C=e.radius-Math.sqrt(Math.max(0,S));e.x+=w*(C+.6),e.y+=A*(C+.6);const R=e.vx*w+e.vy*A;R<0&&(e.vx=(e.vx-2*R*w)*g.RESTITUTION_BLOCK,e.vy=(e.vy-2*R*A)*g.RESTITUTION_BLOCK,this.normalizeOrbSpeed(e)),e.bouncesLeft-=g.BLOCK_BOUNCE_COST}e.comboCount++,u.kind==="boss_armor"?z.onIndestructibleHit(e):z.onBlockHit(e),this.applyHitToBlock(e,u,w,i,a,n,c,o,l,r,$),!$&&e.bouncesLeft<=0&&(e.bouncesLeft=0,e.alive=!1,this.events.onOrbExpired?.(e))}}segmentCircleHit(e,t,s,i,a,n,c){const o=s-e,l=i-t,r=o*o+l*l;if(r<=1e-6)return!1;const h=P(((a-e)*o+(n-t)*l)/r,0,1),y=e+o*h,p=t+l*h,u=y-a,_=p-n;return u*u+_*_<c*c}handlePortalEntry(e,t,s){if(e.portalCooldown>0)return;let i;for(let c=0;c<s.length;c++){const o=s[c];if(o.id===t.portalTargetId&&o.alive){i=o;break}}if(!i)return;e.x=i.x+i.width*.5,e.y=i.y+i.height*.5+e.radius+6,e.portalCooldown=g.PORTAL_COOLDOWN_S,e.bouncesLeft=Math.min(e.maxBounces+6,e.bouncesLeft+g.PORTAL_BONUS_BOUNCES);const a=Math.min(g.MAX_ORB_SPEED,Math.hypot(e.vx,e.vy)*g.PORTAL_SPEED_BOOST),n=P(Math.atan2(Math.abs(e.vy)+120,e.vx),.35,Math.PI-.35);e.vx=Math.cos(n)*a,e.vy=Math.sin(n)*a,e.trail.length=0,e.trailPool[0].x=e.x,e.trailPool[0].y=e.y,e.trail.push(e.trailPool[0]),z.onBlockHit(e),this.events.onPortalWarp?.(e,t,i)}applyHitToBlock(e,t,s,i,a,n,c,o,l,r,h){if(t.hitFlashTimer=.045,t.kind==="boss_armor"){let u=null,_=Number.POSITIVE_INFINITY;for(let b=0;b<n.length;b++){const v=n[b];if(v.alive&&v.kind==="boss_core"&&v.row===t.row){const k=Math.abs(v.col-t.col);k<_&&(_=k,u=v)}}if(u){const b=e.damage*g.BOSS_ARMOR_SPLASH_RATIO;this.damageBlockDirect(u,b,n,c,o,l,r,e.damage)}this.events.onBlockHit?.(e,t,0,!1);return}if(t.kind==="frost"&&t.hp>e.damage){const u=s>=0?-1:1,_=t.col+u;this.grid.isCellOccupied(_,t.row,n)||(t.col=_,t.x=_*g.TILE_SIZE+2,this.grid.rebuild(n))}if(t.kind==="splitter"&&i+a.length<g.MAX_ACTIVE_ORBS&&e.bouncesLeft>=2){const _=Math.atan2(e.vy,-e.vx),b=this.createOrb(e.x,e.y,_,e.radius*.9,Math.max(2,Math.floor(e.bouncesLeft*.5)),e.damage*.85,!0,e.isOverdrive);a.push(b)}this.events.onBlockHit?.(e,t,e.damage,h);const y=t.biomeIndex>=1?.38:.5,p=t.kind==="granite"&&!h?e.damage*y:e.damage;this.damageBlockDirect(t,p,n,c,o,l,r,e.damage)}damageBlockDirect(e,t,s,i,a,n,c,o){if(!e.alive||!Number.isFinite(e.hp)||(e.hp-=t,e.hitFlashTimer=.045,e.kind==="boss_core"&&this.events.onBossCoreDamaged?.(e.biomeIndex,e.bossCoreIndex??0,Math.max(0,e.hp),e.maxHp),e.hp>0))return;e.hp=0,e.alive=!1;const l=Ve(e.depthMeters,e.kind,i,n,c),r=e.kind==="tnt",h=e.kind==="vault";if(this.events.onBlockDestroyed?.(e,l,r,h),r){const y=e.x+e.width*.5,p=e.y+e.height*.5,u=Pt(a);this.events.onTntExplode?.(y,p,u);const _=o*At;for(let b=0;b<s.length;b++){const v=s[b];if(!v.alive||v.id===e.id||!Number.isFinite(v.hp))continue;const k=v.x+v.width*.5,S=v.y+v.height*.5;if(Math.hypot(k-y,S-p)<=u+v.width*.4){const w=v.kind==="granite"?_*1.25:_;this.damageBlockDirect(v,w,s,i,a,n,c,o)}}}else if(e.kind==="laser"){const y=e.y+e.height*.5;this.events.onLaserFire?.(y,e.biomeIndex);const p=o*Et;for(let u=0;u<s.length;u++){const _=s[u];!_.alive||_.id===e.id||_.row!==e.row||Number.isFinite(_.hp)&&this.damageBlockDirect(_,p,s,i,a,n,c,o)}}else if(e.kind==="boss_core"){let y=!1;for(let p=0;p<s.length;p++){const u=s[p];if(u.alive&&u.kind==="boss_core"&&u.row===e.row){y=!0;break}}if(!y){for(let p=0;p<s.length;p++){const u=s[p];u.alive&&u.kind==="boss_armor"&&u.row===e.row&&(u.alive=!1)}this.events.onBossGateBroken?.(e.biomeIndex,e.row)}}}computeTrajectoryPreview(e,t,s,i,a,n=2){let c=null,o=null,l=e,r=t,h=Math.cos(s)*g.LAUNCH_SPEED,y=Math.sin(s)*g.LAUNCH_SPEED,p=0;const u=[{x:l,y:r,segment:0}];let _=-1;const b=1/120,v=96,k=(M,D)=>{p===0?(c={x:M,y:D},_=Math.max(0,u.length-1)):p===1&&(o={x:M,y:D}),p++};for(let M=0;M<v&&p<n;M++){y+=g.GRAVITY*b;const D=this.clampVelocity(h,y);h=D.vx,y=D.vy;const L=h*b,N=y*b,G=Math.hypot(L,N),X=Math.max(1,Math.ceil(G/Math.max(2,i*.35))),ie=b/X;for(let ae=0;ae<X&&p<n;ae++){const pe=l,Te=r;l+=h*ie,r+=y*ie;let Me=!1;if(l-i<0){l=i,h=Math.abs(h)*g.RESTITUTION_BLOCK;const F=this.clampVelocity(h,y);h=F.vx,y=F.vy,u.push({x:l,y:r,segment:p}),k(0,r),Me=!0}else if(l+i>g.SHAFT_WIDTH){l=g.SHAFT_WIDTH-i,h=-Math.abs(h)*g.RESTITUTION_BLOCK;const F=this.clampVelocity(h,y);h=F.vx,y=F.vy,u.push({x:l,y:r,segment:p}),k(g.SHAFT_WIDTH,r),Me=!0}if(Me){if(p>=n)break;continue}let H=null,J=0,ee=0,ne=l,re=r;for(let F=0;F<a.length;F++){const B=a[F];if(!(!B.alive||B.kind==="portal_exit"))if(B.kind==="bumper"||B.kind==="portal_entry"){const Q=B.x+B.width*.5,Z=B.y+B.height*.5,W=i+B.radius,q=l-Q,me=r-Z;if(q*q+me*me<W*W||this.segmentCircleHit(pe,Te,l,r,Q,Z,W)){const oe=Math.max(.001,Math.hypot(q,me));H=B,J=q/oe,ee=me/oe,ne=Q+J*B.radius,re=Z+ee*B.radius;break}}else{const Q=P(l,B.x,B.x+B.width),Z=P(r,B.y,B.y+B.height),W=l-Q,q=r-Z;if(W*W+q*q<i*i){const oe=Math.hypot(W,q);let le=0,ce=-1;if(oe>1e-4)le=W/oe,ce=q/oe;else{const Le=Math.abs(l-B.x),Oe=Math.abs(B.x+B.width-l),Pe=Math.abs(r-B.y),gt=Math.abs(B.y+B.height-r),Ae=Math.min(Le,Oe,Pe,gt);Ae===Le?(le=-1,ce=0):Ae===Oe?(le=1,ce=0):Ae===Pe?(le=0,ce=-1):(le=0,ce=1)}H=B,J=le,ee=ce,ne=Q,re=Z;break}}}if(H){if(H.kind==="portal_entry"){u.push({x:ne,y:re,segment:p}),k(ne,re),p=n;break}if(H.kind==="bumper"){const Z=H.x+H.width*.5,W=H.y+H.height*.5,q=i+H.radius+.5;l=Z+J*q,r=W+ee*q}else l=ne+J*(i+.5),r=re+ee*(i+.5);const F=h*J+y*ee,B=H.kind==="bumper"?g.RESTITUTION_BUMPER:g.RESTITUTION_BLOCK;F<0&&(h=(h-2*F*J)*B,y=(y-2*F*ee)*B);const Q=this.clampVelocity(h,y);if(h=Q.vx,y=Q.vy,u.push({x:l,y:r,segment:p}),k(ne,re),p>=n)break}}p<n&&u.push({x:l,y:r,segment:p})}const S=g.TRAJECTORY_DOTS,w=[0];for(let M=1;M<u.length;M++)w.push(w[M-1]+Math.hypot(u[M].x-u[M-1].x,u[M].y-u[M-1].y));const A=w[w.length-1],$=[],C=_>0&&_<w.length?w[_]:A+1;let R=S;if(A<1)for(let M=0;M<S;M++)$.push({x:e,y:t});else{let M=1;for(let D=1;D<=S;D++){const L=A*D/S;for(;M<u.length-1&&w[M]<L;)M++;const N=w[M-1],G=w[M],X=G>N?P((L-N)/(G-N),0,1):1;$.push({x:u[M-1].x+(u[M].x-u[M-1].x)*X,y:u[M-1].y+(u[M].y-u[M-1].y)*X}),R===S&&L>C&&(R=D-1)}}return{dots:$,impactPoint:c,secondImpactPoint:o,bounceStartIdx:R}}}const fe=48;class is{constructor(){d(this,"pool",[]);d(this,"cursor",0);for(let e=0;e<fe;e++)this.pool.push({active:!1,x:0,y:0,vy:-55,text:"",color:"#fbbf24",scale:1,life:0,maxLife:.7})}spawn(e,t,s,i="#fbbf24",a=1){const n=this.pool[this.cursor];this.cursor=(this.cursor+1)%fe,n.active=!0,n.x=e+(Math.random()-.5)*14,n.y=t,n.vy=-65,n.text=s,n.color=i,n.scale=a,n.life=.75,n.maxLife=.75}update(e){for(let t=0;t<fe;t++){const s=this.pool[t];if(s.active){if(s.life-=e,s.life<=0){s.active=!1;continue}s.y+=s.vy*e,s.vy*=.96}}}render(e){e.textAlign="center",e.textBaseline="middle";for(let t=0;t<fe;t++){const s=this.pool[t];if(!s.active)continue;const i=Math.min(1,s.life/s.maxLife*1.4);e.globalAlpha=i;const a=Math.round(15*s.scale);e.font=`800 ${a}px system-ui, sans-serif`,e.lineWidth=3,e.strokeStyle="rgba(9, 13, 22, 0.9)",e.strokeText(s.text,s.x,s.y),e.fillStyle=s.color,e.fillText(s.text,s.x,s.y)}e.globalAlpha=1}clear(){for(let e=0;e<fe;e++)this.pool[e].active=!1}}const ge=16,ye=8;class as{constructor(){d(this,"hitStopTimer",0);d(this,"shakeX",0);d(this,"shakeY",0);d(this,"shakeMagnitude",0);d(this,"vignetteAlpha",0);d(this,"shockwaves",[]);d(this,"shockwaveCursor",0);d(this,"laserBeams",[]);d(this,"laserCursor",0);d(this,"shakeOffset",{x:0,y:0});for(let e=0;e<ge;e++)this.shockwaves.push({active:!1,x:0,y:0,maxRadius:60,life:0,maxLife:.28,color:"#fb923c"});for(let e=0;e<ye;e++)this.laserBeams.push({active:!1,y:0,life:0,maxLife:.22,color:"#facc15"})}triggerHitStop(e){this.hitStopTimer=Math.max(this.hitStopTimer,Math.min(.05,e))}triggerShake(e){this.shakeMagnitude=Math.min(8,Math.max(this.shakeMagnitude,e))}triggerVignette(e=.35){this.vignetteAlpha=Math.max(this.vignetteAlpha,e)}addShockwave(e,t,s,i="#fb923c"){const a=this.shockwaves[this.shockwaveCursor];this.shockwaveCursor=(this.shockwaveCursor+1)%ge,a.active=!0,a.x=e,a.y=t,a.maxRadius=s,a.life=.28,a.maxLife=.28,a.color=i}addLaserBeam(e,t="#facc15"){const s=this.laserBeams[this.laserCursor];this.laserCursor=(this.laserCursor+1)%ye,s.active=!0,s.y=e,s.life=.22,s.maxLife=.22,s.color=t}consumeHitStop(e){return this.hitStopTimer>0?(this.hitStopTimer=Math.max(0,this.hitStopTimer-e),!0):!1}update(e){if(this.shakeMagnitude>.1){const t=Math.random()*Math.PI*2;this.shakeX=Math.cos(t)*this.shakeMagnitude,this.shakeY=Math.sin(t)*this.shakeMagnitude,this.shakeMagnitude*=Math.pow(.001,e)}else this.shakeMagnitude=0,this.shakeX=0,this.shakeY=0;this.vignetteAlpha>0&&(this.vignetteAlpha=Math.max(0,this.vignetteAlpha-e*1.4));for(let t=0;t<ge;t++){const s=this.shockwaves[t];s.active&&(s.life-=e,s.life<=0&&(s.active=!1))}for(let t=0;t<ye;t++){const s=this.laserBeams[t];s.active&&(s.life-=e,s.life<=0&&(s.active=!1))}}getShakeOffset(){return this.shakeOffset.x=this.shakeX,this.shakeOffset.y=this.shakeY,this.shakeOffset}getVignetteAlpha(){return this.vignetteAlpha}renderWorldEffects(e,t){for(let s=0;s<ge;s++){const i=this.shockwaves[s];if(!i.active)continue;const a=1-i.life/i.maxLife,n=i.maxRadius*a;e.save(),e.globalAlpha=(1-a)*.85,e.strokeStyle=i.color,e.lineWidth=4*(1-a)+1,e.beginPath(),e.arc(i.x,i.y,n,0,Math.PI*2),e.stroke(),e.restore()}for(let s=0;s<ye;s++){const i=this.laserBeams[s];if(!i.active)continue;const a=i.life/i.maxLife;e.save(),e.globalAlpha=a*.9,e.fillStyle=i.color,e.fillRect(0,i.y-10*a,t,20*a),e.fillStyle="#ffffff",e.fillRect(0,i.y-3*a,t,6*a),e.restore()}}clear(){this.hitStopTimer=0,this.shakeMagnitude=0,this.shakeX=0,this.shakeY=0,this.vignetteAlpha=0;for(let e=0;e<ge;e++)this.shockwaves[e].active=!1;for(let e=0;e<ye;e++)this.laserBeams[e].active=!1}}const be=240;class ns{constructor(){d(this,"pool",[]);d(this,"cursor",0);for(let e=0;e<be;e++)this.pool.push({active:!1,x:0,y:0,vx:0,vy:0,size:3,color:"#ffffff",alpha:1,life:0,maxLife:.4,gravity:300})}emitBurst(e,t,s,i,a=80,n=280,c=4,o=.45){for(let l=0;l<s;l++){const r=this.pool[this.cursor];this.cursor=(this.cursor+1)%be;const h=Math.PI*2*l/s+(Math.random()-.5)*.5,y=a+Math.random()*(n-a);r.active=!0,r.x=e,r.y=t,r.vx=Math.cos(h)*y,r.vy=Math.sin(h)*y-40,r.size=c*(.7+Math.random()*.6),r.color=i,r.alpha=1,r.life=o*(.8+Math.random()*.4),r.maxLife=r.life,r.gravity=380}}update(e){for(let t=0;t<be;t++){const s=this.pool[t];if(s.active){if(s.life-=e,s.life<=0){s.active=!1;continue}s.vy+=s.gravity*e,s.x+=s.vx*e,s.y+=s.vy*e,s.alpha=Math.max(0,s.life/s.maxLife)}}}render(e){for(let t=0;t<be;t++){const s=this.pool[t];s.active&&(e.globalAlpha=s.alpha,e.fillStyle=s.color,e.fillRect(s.x-s.size*.5,s.y-s.size*.5,s.size,s.size))}e.globalAlpha=1}clear(){for(let e=0;e<be;e++)this.pool[e].active=!1}}const We=["","K","M","B","T","Qa","Qi"];function O(m){if(!Number.isFinite(m)||m<0)return"0";if(m<1e3)return Math.floor(m).toString();const e=Math.min(Math.floor(Math.log10(m)/3),We.length-1),t=m/Math.pow(1e3,e),s=t>=100?0:t>=10?1:2;return`${t.toFixed(s).replace(/\.0+$/,"").replace(/(\.\d*[1-9])0+$/,"$1")}${We[e]}`}function De(m){return`${Math.floor(Math.max(0,m)).toLocaleString("en-US")}m`}function ke(m=Date.now()){return new Date(m).toISOString().slice(0,10)}class Ie{static getBiomeAtDepth(e){return lt(e)}static getBiomeByIndex(e){return I[Math.max(0,Math.min(I.length-1,e))]}}const rs=""+new URL("block_bedrock_core-CbaULw6l.webp",import.meta.url).href,os=""+new URL("block_frost-BKbLY_G6.webp",import.meta.url).href,ls=""+new URL("block_ore_gold-DJSEgpA0.webp",import.meta.url).href,cs=""+new URL("block_ore_molten-CxGFAYPT.webp",import.meta.url).href,ds=""+new URL("block_ore_nuggets-t3KjcRJB.webp",import.meta.url).href,hs=""+new URL("block_stone_granite-C0ZNjkiB.webp",import.meta.url).href,us=""+new URL("block_stone_sand-DH9-xNal.webp",import.meta.url).href,ps=""+new URL("block_stone_slate-BjwV-_iw.webp",import.meta.url).href,ms=""+new URL("block_tnt-C35s_eKg.webp",import.meta.url).href,fs=""+new URL("env_rock_flank-D6fqvt3t.webp",import.meta.url).href,gs=""+new URL("env_timber_beam-CD8uj98Z.webp",import.meta.url).href,Ke=""+new URL("logo_emblem-GMo4QHvg.webp",import.meta.url).href,ys=""+new URL("prop_bumper_amber-BrMf-UkK.webp",import.meta.url).href,bs=""+new URL("prop_bumper_cyan-SBGwHDL4.webp",import.meta.url).href,_s=""+new URL("prop_lantern-7HwfbphH.webp",import.meta.url).href,vs=""+new URL("prop_portal-BGRqxIbi.webp",import.meta.url).href,xs=""+new URL("prop_turret-Deh7Haz0.webp",import.meta.url).href,ks=""+new URL("skin_copper_gear-ONekgUKm.webp",import.meta.url).href,ws=""+new URL("skin_emerald_buzzsaw-FR8qhDFn.webp",import.meta.url).href,Ss=""+new URL("skin_frost_star-CQYvQZ_9.webp",import.meta.url).href,Ts=""+new URL("skin_gold_chakram-BD4eInXc.webp",import.meta.url).href,Ms=""+new URL("skin_magma_cutter-CCjdGM0R.webp",import.meta.url).href,dt=""+new URL("skin_steel_sawblade-B7zZhMTD.webp",import.meta.url).href,As=""+new URL("skin_tesla_rotor-C_EGx_C_.webp",import.meta.url).href,Es=""+new URL("skin_toxic_drill-nq0XhCic.webp",import.meta.url).href,Cs=""+new URL("skin_void_reaper-L4SDcbZ3.webp",import.meta.url).href,je={steel_sawblade:dt,copper_gear:ks,emerald_buzzsaw:ws,magma_cutter:Ms,frost_star:Ss,gold_chakram:Ts,tesla_rotor:As,toxic_drill:Es,void_reaper:Cs},Ye={0:"none",1:"hue-rotate(215deg) saturate(1.25) brightness(0.95)",2:"hue-rotate(-18deg) saturate(1.35) brightness(0.9)",3:"hue-rotate(175deg) saturate(1.1) brightness(1.05)",4:"hue-rotate(255deg) saturate(1.4) contrast(1.08)",5:"hue-rotate(30deg) saturate(1.25) brightness(1.08)"};class Rs{constructor(){d(this,"images",new Map);d(this,"tintedCache",new Map);d(this,"loaded",!1)}getLogoEmblemUrl(){return Ke}getSkinThumbnailUrl(e){return je[e]??dt}async loadAll(){if(this.loaded||typeof Image>"u")return;const e=[["stone_slate",ps],["stone_sand",us],["stone_granite",hs],["ore_nuggets",ds],["ore_gold",ls],["ore_molten",cs],["tnt",ms],["frost",os],["bedrock_core",rs],["bumper_amber",ys],["bumper_cyan",bs],["turret",xs],["lantern",_s],["portal",vs],["timber_beam",gs],["rock_flank",fs],["logo_emblem",Ke],...Object.entries(je).map(([t,s])=>[`skin:${t}`,s])];await Promise.all(e.map(([t,s])=>new Promise(i=>{const a=new Image;a.onload=()=>{this.images.set(t,a),i()},a.onerror=()=>i(),a.src=s}))),this.loaded=!0}getEnvTimberBeam(){return this.images.get("timber_beam")??null}getEnvRockFlank(e){const t=this.images.get("rock_flank");return t?e.index===0?t:this.getTinted(`flank:${e.index}`,t,Ye[e.index]??"none",e.palette.strataFill):null}getPropTurret(){return this.images.get("turret")??null}getPropLantern(){return this.images.get("lantern")??null}getPropPortal(){return this.images.get("portal")??null}getPropBumper(e){return this.images.get(e?"bumper_amber":"bumper_cyan")??null}getPropSawblade(e){return this.images.get(`skin:${e.id}`)??this.images.get("skin:steel_sawblade")??null}getBlockSprite(e,t,s,i){const a=Math.abs(s*73856093^i*19349663)%3;let n="stone_slate",c=!0;switch(e){case"strata":n=a===0?"stone_slate":a===1?"stone_sand":"stone_granite";break;case"granite":case"boss_armor":n="stone_granite";break;case"ore":n=a===0?"ore_nuggets":a===1?"ore_gold":"ore_molten";break;case"tnt":n="tnt",c=!1;break;case"frost":n="frost",c=!1;break;case"boss_core":n="bedrock_core",c=!1;break;case"splitter":n="frost";break;case"laser":n="ore_molten",c=!1;break;case"vault":n="ore_gold",c=!1;break;default:n="stone_slate"}const o=this.images.get(n);return o?!c||t.index===0?o:this.getTinted(`blk:${n}:${t.index}`,o,Ye[t.index]??"none",t.palette.strataFill,.24):null}getTinted(e,t,s,i,a=.28){const n=this.tintedCache.get(e);if(n)return n;if(typeof document>"u")return t;const c=t.naturalWidth||t.width,o=t.naturalHeight||t.height;if(!c||!o)return t;const l=document.createElement("canvas");l.width=c,l.height=o;const r=l.getContext("2d");return r?(s!=="none"&&"filter"in r?(r.filter=s,r.drawImage(t,0,0,c,o),r.filter="none"):(r.drawImage(t,0,0,c,o),r.globalCompositeOperation="source-atop",r.fillStyle=i,r.globalAlpha=a,r.fillRect(0,0,c,o),r.globalCompositeOperation="source-over",r.globalAlpha=1),this.tintedCache.set(e,l),l):t}}const ht=new Rs;class Bs{constructor(e){d(this,"ctx");d(this,"atlas",ht);const t=e.getContext("2d",{alpha:!1});if(!t)throw new Error("Could not initialize 2D canvas context");this.ctx=t}async preloadAssets(){await this.atlas.loadAll()}getLogoEmblemUrl(){return this.atlas.getLogoEmblemUrl()}render(e,t){const s=this.ctx,{cssWidth:i,cssHeight:a,dpr:n,scale:c,shaftX:o}=e,l=Math.round(t.cameraY*c)/c,r=t.baseDepthMeters+l/g.TILE_SIZE*g.METERS_PER_ROW,h=Ie.getBiomeAtDepth(r);s.save(),s.scale(n,n),s.imageSmoothingEnabled=!0,s.imageSmoothingQuality="high",this.renderRockFlanks(s,i,a,o,e.shaftWidthPx,l,t.baseDepthMeters,c,h,e.isPortrait);const y=t.juice.getShakeOffset(),p=26*c;s.save(),s.beginPath(),s.rect(o-p,0,e.shaftWidthPx+p*2,a),s.clip(),s.translate(o+y.x*c,y.y*c),s.scale(c,c),s.translate(0,-l),this.renderShaftInterior(s,l,a/c,h,t.timeS);const u=l-90,_=l+a/c+90;for(let v=0;v<t.entities.length;v++){const k=t.entities[v];k.alive&&(k.y+k.height<u||k.y>_||this.renderEntity(s,k,h,t.timeS))}t.aimAngleRad!==null&&t.trajectoryDots.length>0&&this.renderTrajectory(s,t.trajectoryDots,t.trajectoryImpact,t.trajectorySecondImpact??null,t.trajectoryBounceIdx??t.trajectoryDots.length,t.timeS),this.renderLauncher(s,t.launcherX,t.launcherY,t.aimAngleRad,t.turretRecoil??0,!!t.isAimingState,t.skin,t.loadedOrbRadius??14,t.timeS),t.aimFeedback&&this.renderAimFeedback(s,t.aimFeedback,t.timeS);for(let v=0;v<t.coins.length;v++){const k=t.coins[v];k.alive&&(s.save(),s.fillStyle="rgba(255, 216, 77, 0.28)",s.beginPath(),s.arc(k.x,k.y,11,0,Math.PI*2),s.fill(),s.fillStyle="#ffd84d",s.beginPath(),s.arc(k.x,k.y,6.5,0,Math.PI*2),s.fill(),s.strokeStyle="#181210",s.lineWidth=2,s.stroke(),s.restore())}for(let v=0;v<t.orbs.length;v++){const k=t.orbs[v];k.alive&&this.renderOrb(s,k,t.skin)}t.juice.renderWorldEffects(s,g.SHAFT_WIDTH),t.particles.render(s),t.floatingText.render(s),this.renderTimberShaftFrame(s,l,a/c,h,t.timeS),s.restore();const b=t.juice.getVignetteAlpha();b>.01&&(s.fillStyle=`rgba(251, 146, 60, ${b.toFixed(2)})`,s.fillRect(0,0,i,14),s.fillRect(0,a-14,i,14)),s.restore()}renderRockFlanks(e,t,s,i,a,n,c,o,l,r){if(e.fillStyle=l.index===0?"#16110e":l.palette.bgBottom,e.fillRect(0,0,t,s),r)return;const h=i+a,y=t-h,p=this.atlas.getEnvRockFlank(l);if(p){const b=Math.max(i,y,320),v=p.width||512,k=p.height||768,S=Math.round(k/v*b),w=n*.65*o%S;e.save(),e.beginPath(),e.rect(0,0,i,s),e.clip();for(let A=-w-S;A<s+S;A+=S)e.drawImage(p,i-b,A,b,S);e.restore(),e.save(),e.beginPath(),e.rect(h,0,y,s),e.clip(),e.translate(h+b,0),e.scale(-1,1);for(let A=-w-S;A<s+S;A+=S)e.drawImage(p,0,A,b,S);e.restore()}const u=e.createLinearGradient(0,0,i,0);u.addColorStop(0,"rgba(6, 5, 4, 0.72)"),u.addColorStop(.75,"rgba(6, 5, 4, 0.22)"),u.addColorStop(1,"rgba(6, 5, 4, 0.05)"),e.fillStyle=u,e.fillRect(0,0,i,s);const _=e.createLinearGradient(h,0,t,0);_.addColorStop(0,"rgba(6, 5, 4, 0.05)"),_.addColorStop(.25,"rgba(6, 5, 4, 0.22)"),_.addColorStop(1,"rgba(6, 5, 4, 0.72)"),e.fillStyle=_,e.fillRect(h,0,y,s),this.renderDepthRuler(e,s,n,c,o)}renderDepthRuler(e,t,s,i,a){const n=g.TILE_SIZE/g.METERS_PER_ROW,c=Math.max(0,Math.floor((i+s/n)/10)*10),o=c+Math.ceil(t/(n*a*10))*10+10;e.save(),e.font="900 12px system-ui, sans-serif",e.textAlign="left",e.textBaseline="middle";for(let l=c;l<=o;l+=5){const h=((l-i)*n-s)*a;if(h<58||h>t-16)continue;const y=l%10===0;e.fillStyle=y?"#fde68a":"rgba(226, 232, 240, 0.55)",e.fillRect(0,h-1,y?14:7,2),y&&l>0&&(e.strokeStyle="#181210",e.lineWidth=3.5,e.strokeText(`${l}m`,18,h),e.fillText(`${l}m`,18,h))}e.restore()}renderShaftInterior(e,t,s,i,a){e.fillStyle=i.index===0?"#1e1612":i.palette.bgBottom,e.fillRect(0,t,g.SHAFT_WIDTH,s),e.save();for(let l=0;l<3;l++){const r=70+l*165+Math.sin(a*.4+l)*12,h=e.createLinearGradient(r,t,r+90,t+s*.75);h.addColorStop(0,this.hexToRgba(i.palette.glow,.14)),h.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=h,e.beginPath(),e.moveTo(r-30,t),e.lineTo(r+42,t),e.lineTo(r+150,t+s),e.lineTo(r+40,t+s),e.closePath(),e.fill()}e.restore();const n=g.TILE_SIZE,c=Math.floor(t/n)*n,o=t+s+n;e.save(),e.strokeStyle="#ffffff",e.globalAlpha=.04,e.lineWidth=1;for(let l=n;l<g.SHAFT_WIDTH;l+=n)e.beginPath(),e.moveTo(l,c),e.lineTo(l,o),e.stroke();for(let l=c;l<=o;l+=n)e.beginPath(),e.moveTo(0,l),e.lineTo(g.SHAFT_WIDTH,l),e.stroke();for(let l=0;l<18;l++){const r=((l*89+Math.sin(a*.7+l)*20)%g.SHAFT_WIDTH+g.SHAFT_WIDTH)%g.SHAFT_WIDTH,h=t+((l*67+a*(10+l%4*3))%s+s)%s;e.globalAlpha=.28+.25*Math.sin(a*2+l),e.fillStyle=i.palette.glow,e.beginPath(),e.arc(r,h,1.6,0,Math.PI*2),e.fill()}e.restore()}renderTimberShaftFrame(e,t,s,i,a){const c=this.atlas.getEnvTimberBeam();if(e.save(),c){const h=c.width||128,y=c.height||512,p=Math.round(y/h*24),u=Math.floor((t-20)/p)*p,_=t+s+p;for(let b=u;b<_;b+=p)e.drawImage(c,-24,b,24,p+1),e.drawImage(c,g.SHAFT_WIDTH,b,24,p+1)}else e.fillStyle="#6b3e1e",e.fillRect(-24,t-20,24,s+40),e.fillRect(g.SHAFT_WIDTH,t-20,24,s+40);const o=g.TILE_SIZE*5,l=Math.floor(t/o)*o+120,r=this.atlas.getPropLantern();for(let h=l;h<t+s+o;h+=o){const y=.85+.15*Math.sin(a*11+h),p=Math.sin(a*2.4+h*.01)*.035;for(const u of[-24*.5,g.SHAFT_WIDTH+24*.5]){e.save(),e.globalCompositeOperation="lighter";const _=e.createRadialGradient(u,h+16,2,u,h+16,86*y);if(_.addColorStop(0,this.hexToRgba(i.palette.glow,.3*y)),_.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=_,e.beginPath(),e.arc(u,h+16,86*y,0,Math.PI*2),e.fill(),e.restore(),e.strokeStyle="#181210",e.lineWidth=3,e.beginPath(),e.moveTo(u,h-4),e.lineTo(u,h+2),e.stroke(),r){e.save(),e.translate(u,h),e.rotate(p);const b=(r.width||100)/(r.height||160),v=Math.min(20,30*b),k=v/b;e.drawImage(r,-v*.5,0,v,k),e.restore()}}}e.restore()}renderTrajectory(e,t,s,i,a,n){const c=n*5%1;for(let o=0;o<t.length;o++){const l=t[o],r=o>=a,h=(r?.62:1)*(1-o/(t.length+3))*(.78+.22*Math.sin((o-c)*1.4));e.fillStyle=r?`rgba(56, 189, 248, ${h.toFixed(2)})`:`rgba(255, 224, 102, ${h.toFixed(2)})`,e.beginPath(),e.arc(l.x,l.y,Math.max(1.8,(r?3.5:4.6)-o*.14),0,Math.PI*2),e.fill()}if(s){e.save();const o=8.5+Math.sin(n*8)*1.8;e.strokeStyle="rgba(255, 216, 77, 0.95)",e.lineWidth=2.5,e.beginPath(),e.arc(s.x,s.y,o,0,Math.PI*2),e.stroke(),e.fillStyle="rgba(255, 216, 77, 0.35)",e.beginPath(),e.arc(s.x,s.y,3.5,0,Math.PI*2),e.fill(),e.restore()}i&&(e.save(),e.strokeStyle="rgba(56, 189, 248, 0.8)",e.lineWidth=2,e.beginPath(),e.arc(i.x,i.y,6.5,0,Math.PI*2),e.stroke(),e.restore())}renderLauncher(e,t,s,i,a,n,c,o,l){const r=i??Math.PI*.5,h=t-Math.cos(r)*a*6,p=s-Math.sin(r)*a*6+g.MUZZLE_PIVOT_OFFSET_Y;if(n){const b=Be(t,s,r),v=Math.min(18,o);e.save(),e.fillStyle="rgba(251, 191, 36, 0.24)",e.beginPath(),e.arc(b.x,b.y,v+4,0,Math.PI*2),e.fill();const k=this.atlas.getPropSawblade(c);if(e.translate(b.x,b.y),e.rotate(l*4.5),k?e.drawImage(k,-v,-v,v*2,v*2):(e.fillStyle=c.primaryColor,e.beginPath(),e.arc(0,0,v,0,Math.PI*2),e.fill()),e.restore(),i===null){e.save();for(let S=0;S<3;S++){const w=b.y+20+S*16,A=.28+.24*Math.sin(l*5-S*.9);e.strokeStyle=`rgba(255, 224, 102, ${A.toFixed(2)})`,e.lineWidth=2.2,e.beginPath(),e.moveTo(b.x-6,w-4),e.lineTo(b.x,w+2),e.lineTo(b.x+6,w-4),e.stroke()}e.restore()}}e.save();const u=e.createLinearGradient(0,s-42,0,s-24);u.addColorStop(0,"#475569"),u.addColorStop(1,"#1e293b"),e.fillStyle=u,e.fillRect(0,s-42,g.SHAFT_WIDTH,16),e.strokeStyle="#181210",e.lineWidth=2.5,e.strokeRect(0,s-42,g.SHAFT_WIDTH,16);for(let b=24;b<g.SHAFT_WIDTH;b+=48)e.fillStyle="#94a3b8",e.beginPath(),e.arc(b,s-34,2.2,0,Math.PI*2),e.fill();const _=this.atlas.getPropTurret();if(e.translate(h,p),e.rotate(r-Math.PI*.5),_){const v=(_.width||180)/(_.height||220)*66;e.drawImage(_,-v*.5,0,v,66)}else e.fillStyle="#d97706",e.strokeStyle="#181210",e.lineWidth=2.5,e.fillRect(-14,0,28,34),e.strokeRect(-14,0,28,34);e.restore()}renderAimFeedback(e,t,s){if(t.dragging){if(e.save(),t.mode==="slingshot"){const i=t.canceled?"rgba(248, 113, 113, 0.9)":"rgba(255, 224, 102, 0.72)";if(e.strokeStyle=i,e.lineWidth=2.2,e.setLineDash([5,4]),e.beginPath(),e.arc(t.originWorld.x,t.originWorld.y,t.deadzoneWorldRadius,0,Math.PI*2),e.stroke(),e.setLineDash([]),t.canceled){const a=t.originWorld.x,n=t.originWorld.y;e.strokeStyle="#f87171",e.lineWidth=2.8,e.beginPath(),e.moveTo(a-6,n-6),e.lineTo(a+6,n+6),e.moveTo(a+6,n-6),e.lineTo(a-6,n+6),e.stroke()}else{e.strokeStyle="rgba(251, 191, 36, 0.65)",e.lineWidth=2.5,e.beginPath(),e.moveTo(t.originWorld.x,t.originWorld.y),e.lineTo(t.currentWorld.x,t.currentWorld.y),e.stroke();const a=6+Math.sin(s*8)*.8;e.fillStyle="#fde047",e.strokeStyle="#181210",e.lineWidth=2,e.beginPath(),e.arc(t.currentWorld.x,t.currentWorld.y,a,0,Math.PI*2),e.fill(),e.stroke()}}else if(t.canceled){const i=t.currentWorld.x,a=t.currentWorld.y;e.strokeStyle="#f87171",e.lineWidth=2.4,e.beginPath(),e.arc(i,a,16,0,Math.PI*2),e.moveTo(i-5,a-5),e.lineTo(i+5,a+5),e.moveTo(i+5,a-5),e.lineTo(i-5,a+5),e.stroke()}e.restore()}}renderEntity(e,t,s,i){const a=t.x+t.width*.5,n=t.y+t.height*.5;if(t.kind==="portal_entry"||t.kind==="portal_exit"){e.save();const o=t.kind==="portal_entry",l=this.atlas.getPropPortal();if(e.translate(a,n),e.rotate(i*(o?2.4:-2.4)),l){const r=t.radius*2.5;e.drawImage(l,-r*.5,-r*.5,r,r)}else e.strokeStyle=o?"#28e0d8":"#f43f5e",e.lineWidth=3,e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.stroke();e.restore();return}if(t.kind==="bumper"){e.save();const o=t.id%2===0,l=this.atlas.getPropBumper(o),r=t.hitFlashTimer>0?1.22:1+Math.sin(i*5+t.id)*.03;if(e.translate(a,n),e.scale(r,r),l){const h=t.radius*2.45;e.drawImage(l,-h*.5,-h*.5,h,h)}else e.fillStyle="#d97706",e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.fill();t.hitFlashTimer>0&&(e.strokeStyle="#ffffff",e.lineWidth=3,e.beginPath(),e.arc(0,0,t.radius*1.15,0,Math.PI*2),e.stroke()),e.restore();return}const c=this.atlas.getBlockSprite(t.kind,s,t.col,t.row);if(e.save(),c)if(t.kind==="vault"){const l=t.x+2,r=t.y+2,h=t.width-4,y=t.height-4,p=r+y*.34;e.fillStyle="#4c1d95",e.fillRect(l,r,h,y),e.globalAlpha=.25,e.drawImage(c,l+4,r+4,h-8,y-8),e.globalAlpha=1,e.fillStyle="#6d28d9",e.fillRect(l,r,h,p-r);const u=7;e.fillStyle="#d97706",e.fillRect(l+12,r,u,y),e.fillRect(l+h-12-u,r,u,y),e.fillStyle="#181210",e.fillRect(l,p-2,h,4),e.fillStyle="#fbbf24",e.fillRect(l,p-1,h,2),e.strokeStyle="#fbbf24",e.lineWidth=3,e.strokeRect(l,r,h,y);const _=14,b=11;e.fillStyle="#181210",e.fillRect(a-_*.5-1.5,p-b*.5-1.5,_+3,b+3),e.fillStyle="#fde047",e.fillRect(a-_*.5,p-b*.5,_,b)}else e.drawImage(c,t.x,t.y,t.width,t.height);else e.fillStyle=s.palette.strataFill,e.fillRect(t.x,t.y,t.width,t.height);if(t.kind==="splitter")e.fillStyle="rgba(6, 182, 212, 0.34)",e.beginPath(),e.moveTo(a,t.y+4),e.lineTo(t.x+t.width-4,n),e.lineTo(a,t.y+t.height-4),e.lineTo(t.x+4,n),e.closePath(),e.fill(),e.strokeStyle="#22d3ee",e.lineWidth=2.8,e.stroke(),e.strokeStyle="#cffafe",e.lineWidth=1.8,e.beginPath(),e.moveTo(a,t.y+11),e.lineTo(a,n-6),e.moveTo(a,n+4),e.lineTo(a-11,t.y+t.height-12),e.moveTo(a,n+4),e.lineTo(a+11,t.y+t.height-12),e.stroke();else if(t.kind==="laser"){const o=t.x+2,l=t.y+2,r=t.width-4,h=t.height-4,y=7;e.save(),e.beginPath(),e.rect(o,l,r,y),e.rect(o,l+h-y,r,y),e.clip(),e.fillStyle="#181210",e.fillRect(o,l,r,h),e.fillStyle="#f59e0b";for(let p=-h;p<r+h;p+=12)e.beginPath(),e.moveTo(o+p,l),e.lineTo(o+p+6,l),e.lineTo(o+p-4,l+h),e.lineTo(o+p-10,l+h),e.closePath(),e.fill();e.restore(),e.strokeStyle="rgba(254, 240, 138, 0.55)",e.lineWidth=2,e.beginPath(),e.moveTo(o+10,n),e.lineTo(o+r-10,n),e.stroke(),e.strokeStyle="#fbbf24",e.lineWidth=2.5,e.strokeRect(o,l,r,h),e.fillStyle="#fde047",e.fillRect(t.x+2,n-6,8,12),e.fillRect(t.x+t.width-10,n-6,8,12),e.fillStyle="#ffffff",e.fillRect(t.x+3,n-3,4,6),e.fillRect(t.x+t.width-7,n-3,4,6)}else t.kind==="granite"&&t.biomeIndex>=1&&(e.strokeStyle="#94a3b8",e.lineWidth=2.5,e.strokeRect(t.x+2,t.y+2,t.width-4,t.height-4));if(t.hitFlashTimer>0&&(e.fillStyle="rgba(255, 255, 255, 0.65)",e.fillRect(t.x+2,t.y+2,t.width-4,t.height-4)),Number.isFinite(t.hp)&&t.maxHp>0){const o=t.hp/t.maxHp;if(o<1&&(e.strokeStyle="rgba(255, 216, 77, 0.92)",e.lineWidth=2.2,e.beginPath(),o<=.75&&(e.moveTo(t.x+8,t.y+8),e.lineTo(a,n)),o<=.5&&(e.moveTo(t.x+t.width-8,t.y+10),e.lineTo(a-4,n+4)),o<=.25&&(e.moveTo(t.x+10,t.y+t.height-8),e.lineTo(a+8,n-4)),e.stroke()),t.kind!=="tnt"&&(t.hp<t.maxHp||t.hp>=10)){const l=O(Math.ceil(t.hp));e.font="900 17px system-ui, sans-serif",e.textAlign="center",e.textBaseline="middle",e.lineWidth=4.5,e.strokeStyle="#181210",e.strokeText(l,a,n+1),e.fillStyle="#ffffff",e.fillText(l,a,n+1)}}e.restore()}renderOrb(e,t,s){const i=t.bouncesLeft<=2||t.overheatDraining,a=i?"#f59e0b":t.isOverdrive?"#fde047":s.trailColor,n=1+Math.min(.4,t.comboCount*.025);if(t.trail.length>1){e.save();for(let l=1;l<t.trail.length;l++){const r=t.trail[l-1],h=t.trail[l],y=l/t.trail.length;e.strokeStyle=a,e.globalAlpha=y*.72,e.lineWidth=t.radius*1.2*n*y,e.lineCap="round",e.beginPath(),e.moveTo(r.x,r.y),e.lineTo(h.x,h.y),e.stroke()}e.restore()}const c=Math.max(0,Math.min(1,t.bouncesLeft/Math.max(1,t.maxBounces)));e.save(),e.strokeStyle=i?"#f59e0b":"#ffe066",e.lineWidth=2.5,e.beginPath(),e.arc(t.x,t.y,t.radius+5,-Math.PI/2,-Math.PI/2+Math.PI*2*c),e.stroke(),e.translate(t.x,t.y),e.rotate(t.rotation);const o=this.atlas.getPropSawblade(s);if(o){const l=t.radius*2.45;e.drawImage(o,-l*.5,-l*.5,l,l)}else e.fillStyle=s.primaryColor,e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.fill();e.restore()}hexToRgba(e,t){const s=e.replace("#","");if(s.length!==6)return`rgba(255, 191, 71, ${t})`;const i=parseInt(s.slice(0,2),16),a=parseInt(s.slice(2,4),16),n=parseInt(s.slice(4,6),16);return`rgba(${i}, ${a}, ${n}, ${t})`}}class Is{constructor(){d(this,"name","crazygames");d(this,"supportsBanners",!0);d(this,"hideFullscreenButton",!0)}get sdk(){return window.CrazyGames?.SDK}async init(){try{this.sdk?.init&&await this.sdk.init()}catch{}}loadingStart(){try{this.sdk?.game?.loadingStart?.()}catch{}}loadingStop(){try{this.sdk?.game?.loadingStop?.()}catch{}}gameplayStart(){try{this.sdk?.game?.gameplayStart?.()}catch{}}gameplayStop(){try{this.sdk?.game?.gameplayStop?.()}catch{}}happytime(){try{this.sdk?.game?.happytime?.()}catch{}}requestAd(e){return new Promise(t=>{const s=this.sdk?.ad?.requestAd;if(!s){t({rewarded:!1,reason:"error"});return}let i=!1;const a=setTimeout(()=>{i||(i=!0,t({rewarded:!1,reason:"error"}))},6e4);try{s(e,{adFinished:()=>{i||(i=!0,clearTimeout(a),t({rewarded:!0,reason:"finished"}))},adError:()=>{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}})}catch{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}})}showMidgameAd(){return this.requestAd("midgame")}showRewardedAd(e){return this.requestAd("rewarded")}requestBanner(e){try{this.sdk?.banner?.requestResponsiveBanner?.(e)}catch{}}clearBanner(e){try{this.sdk?.banner?.clearBanner?.(e)}catch{}}async saveCloudData(e){try{this.sdk?.data?.setItem?.("ricochet_miner_save",e)}catch{}}async loadCloudData(){try{return this.sdk?.data?.getItem?.("ricochet_miner_save")??null}catch{return null}}getLocale(){return this.sdk?.environment?.locale??navigator.language??"en"}getDeviceType(){const e=this.sdk?.environment?.device?.type;return e==="mobile"||e==="tablet"||e==="desktop"?e:window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}class Ds{constructor(){d(this,"name","gamedistribution");d(this,"supportsBanners",!1);d(this,"hideFullscreenButton",!1);d(this,"rewardedGranted",!1);d(this,"adResolve",null)}get sdk(){return window.gdsdk}async init(){const e=window,t=e.GD_OPTIONS??{};e.GD_OPTIONS={...t,onEvent:s=>{if(s?.name==="SDK_REWARDED_WATCH_COMPLETE")this.rewardedGranted=!0;else if(s?.name==="SDK_GAME_START"){const i=this.adResolve;this.adResolve=null,i&&i({rewarded:this.rewardedGranted,reason:this.rewardedGranted?"finished":"skipped"})}}}}loadingStart(){}loadingStop(){}gameplayStart(){}gameplayStop(){}happytime(){}async showMidgameAd(){if(!this.sdk?.showAd)return{rewarded:!1,reason:"error"};this.rewardedGranted=!0;try{return await this.sdk.showAd("interstitial"),{rewarded:!0,reason:"finished"}}catch{return{rewarded:!1,reason:"error"}}}showRewardedAd(e){return this.sdk?.showAd?(this.rewardedGranted=!1,new Promise(t=>{const s=setTimeout(()=>{this.adResolve&&(this.adResolve=null,t({rewarded:!1,reason:"error"}))},6e4);this.adResolve=i=>{clearTimeout(s),t(i)},this.sdk.showAd("rewarded").catch(()=>{clearTimeout(s),this.adResolve=null,t({rewarded:!1,reason:"error"})})})):Promise.resolve({rewarded:!1,reason:"error"})}requestBanner(){}clearBanner(){}async saveCloudData(){}async loadCloudData(){return null}getLocale(){return navigator.language??"en"}getDeviceType(){return window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}class Qe{constructor(e="mock",t=!0){d(this,"name");d(this,"supportsBanners");d(this,"hideFullscreenButton",!1);d(this,"simulateAdError",!1);d(this,"simulateAdBlock",!1);d(this,"simulatedDelayMs",450);this.name=e,this.supportsBanners=t}async init(){return Promise.resolve()}loadingStart(){}loadingStop(){}gameplayStart(){}gameplayStop(){}happytime(){}async showMidgameAd(){return this.name==="standalone"?{rewarded:!1,reason:"skipped"}:this.simulateAdBlock?{rewarded:!1,reason:"adblock"}:this.simulateAdError?{rewarded:!1,reason:"error"}:(await new Promise(e=>setTimeout(e,this.simulatedDelayMs)),{rewarded:!0,reason:"finished"})}async showRewardedAd(e){return this.name==="standalone"?{rewarded:!1,reason:"error"}:this.simulateAdBlock?{rewarded:!1,reason:"adblock"}:this.simulateAdError?{rewarded:!1,reason:"error"}:(await new Promise(t=>setTimeout(t,this.simulatedDelayMs)),{rewarded:!0,reason:"finished"})}requestBanner(e){const t=typeof document<"u"?document.getElementById(e):null;t&&(t.textContent="BANNER AD SLOT (DEV)",t.style.display="flex")}clearBanner(e){const t=typeof document<"u"?document.getElementById(e):null;t&&(t.textContent="",t.style.display="none")}async saveCloudData(e){return Promise.resolve()}async loadCloudData(){return Promise.resolve(null)}getLocale(){return typeof navigator<"u"?navigator.language:"en"}getDeviceType(){return typeof window>"u"?"desktop":window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}const Xe=45e3;class Ls{constructor(){d(this,"name","poki");d(this,"supportsBanners",!1);d(this,"hideFullscreenButton",!1)}get sdk(){return window.PokiSDK}async init(){try{await this.sdk?.init?.()}catch{}}loadingStart(){}loadingStop(){try{this.sdk?.gameLoadingFinished?.()}catch{}}gameplayStart(){try{this.sdk?.gameplayStart?.()}catch{}}gameplayStop(){try{this.sdk?.gameplayStop?.()}catch{}}happytime(){}async showMidgameAd(){if(!this.sdk?.commercialBreak)return{rewarded:!1,reason:"error"};try{let e;const t=await Promise.race([this.sdk.commercialBreak().then(()=>({rewarded:!0,reason:"finished"})),new Promise(s=>{e=setTimeout(()=>s({rewarded:!1,reason:"error"}),Xe)})]);return e&&clearTimeout(e),t}catch{return{rewarded:!1,reason:"error"}}}async showRewardedAd(e){if(!this.sdk?.rewardedBreak)return{rewarded:!1,reason:"error"};try{let t;const s=await Promise.race([this.sdk.rewardedBreak().then(i=>({rewarded:!!i,reason:i?"finished":"skipped"})),new Promise(i=>{t=setTimeout(()=>i({rewarded:!1,reason:"error"}),Xe)})]);return t&&clearTimeout(t),s}catch{return{rewarded:!1,reason:"error"}}}requestBanner(){}clearBanner(){}async saveCloudData(){}async loadCloudData(){return null}getLocale(){return navigator.language??"en"}getDeviceType(){return window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}const Ze=45e3;class Os{constructor(){d(this,"name","yandex");d(this,"supportsBanners",!0);d(this,"hideFullscreenButton",!1);d(this,"ysdk",null);d(this,"player",null)}async init(){try{const e=window.YaGames;if(e?.init){this.ysdk=await e.init();try{this.player=await this.ysdk.getPlayer?.({scopes:!1})??null}catch{this.player=null}}}catch{this.ysdk=null}}loadingStart(){}loadingStop(){try{this.ysdk?.features?.LoadingAPI?.ready?.()}catch{}}gameplayStart(){try{this.ysdk?.features?.GameplayAPI?.start?.()}catch{}}gameplayStop(){try{this.ysdk?.features?.GameplayAPI?.stop?.()}catch{}}happytime(){}showMidgameAd(){return new Promise(e=>{if(!this.ysdk?.adv?.showFullscreenAdv){e({rewarded:!1,reason:"error"});return}let t=!1;const s=setTimeout(()=>{t||(t=!0,e({rewarded:!1,reason:"error"}))},Ze);try{this.ysdk.adv.showFullscreenAdv({callbacks:{onClose:i=>{t||(t=!0,clearTimeout(s),e({rewarded:!!i,reason:"finished"}))},onError:()=>{t||(t=!0,clearTimeout(s),e({rewarded:!1,reason:"error"}))}}})}catch{t||(t=!0,clearTimeout(s),e({rewarded:!1,reason:"error"}))}})}showRewardedAd(e){return new Promise(t=>{if(!this.ysdk?.adv?.showRewardedVideo){t({rewarded:!1,reason:"error"});return}let s=!1,i=!1;const a=setTimeout(()=>{i||(i=!0,t({rewarded:!1,reason:"error"}))},Ze);try{this.ysdk.adv.showRewardedVideo({callbacks:{onRewarded:()=>{s=!0},onClose:()=>{i||(i=!0,clearTimeout(a),t({rewarded:s,reason:s?"finished":"skipped"}))},onError:()=>{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}}})}catch{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}})}requestBanner(){try{window.innerHeight>=600&&this.ysdk?.adv?.showBannerAdv?.()}catch{}}clearBanner(){try{this.ysdk?.adv?.hideBannerAdv?.()}catch{}}async saveCloudData(e){try{await this.player?.setData({ricochet_miner_save:e},!0)}catch{}}async loadCloudData(){try{const t=(await this.player?.getData(["ricochet_miner_save"]))?.ricochet_miner_save;return typeof t=="string"?t:null}catch{return null}}getLocale(){return this.ysdk?.environment?.i18n?.lang??navigator.language??"en"}getDeviceType(){const e=this.ysdk?.deviceInfo?.type;return e==="mobile"||e==="tablet"||e==="desktop"?e:window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){try{const e=this.ysdk?.serverTime?.();if(typeof e=="number"&&e>0)return e}catch{}return Date.now()}}class Ps{constructor(e){d(this,"adapter");d(this,"initialized",!1);d(this,"playstate","IDLE");d(this,"lifecycle",{onBeforeAd:()=>{},onAfterAd:()=>{}});this.adapter=e??this.createAdapter()}createAdapter(){switch("yandex"){case"crazygames":return new Is;case"poki":return new Ls;case"gamedistribution":return new Ds;case"yandex":return new Os;case"standalone":return new Qe("standalone",!1);default:return new Qe("mock",!0)}}setAdapterForTest(e){this.adapter=e,this.initialized=!1,this.playstate="IDLE"}setAdLifecycleCallbacks(e){this.lifecycle=e}getAdapter(){return this.adapter}get activePlaystate(){return this.playstate}get gameplayActive(){return this.playstate==="GAMEPLAY"}get adInFlight(){return this.playstate==="AD_PAUSED"}get supportsBanners(){return this.adapter.supportsBanners}get hideFullscreenButton(){return this.adapter.hideFullscreenButton}async init(){this.initialized||(this.initialized=!0,await this.adapter.init())}loadingStart(){this.adapter.loadingStart()}loadingStop(){this.adapter.loadingStop()}gameplayStart(){this.playstate==="IDLE"&&(this.playstate="GAMEPLAY",this.adapter.gameplayStart())}gameplayStop(){this.playstate==="GAMEPLAY"&&(this.playstate="IDLE",this.adapter.gameplayStop())}happytime(){this.playstate!=="AD_PAUSED"&&this.adapter.happytime()}async showMidgameAd(){if(this.playstate==="AD_PAUSED")return{rewarded:!1,reason:"skipped"};this.gameplayStop(),this.playstate="AD_PAUSED",this.lifecycle.onBeforeAd();try{return await this.adapter.showMidgameAd()}catch{return{rewarded:!1,reason:"error"}}finally{this.playstate="IDLE",this.lifecycle.onAfterAd()}}async showRewardedAd(e){if(this.playstate==="AD_PAUSED")return{rewarded:!1,reason:"skipped"};this.gameplayStop(),this.playstate="AD_PAUSED",this.lifecycle.onBeforeAd();try{return await this.adapter.showRewardedAd(e)}catch{return{rewarded:!1,reason:"error"}}finally{this.playstate="IDLE",this.lifecycle.onAfterAd()}}requestBanner(e,t){this.playstate==="AD_PAUSED"||!this.adapter.supportsBanners||this.adapter.requestBanner(e,t)}clearBanner(e){this.playstate==="AD_PAUSED"||!this.adapter.supportsBanners||this.adapter.clearBanner(e)}async saveCloudData(e){await this.adapter.saveCloudData(e)}async loadCloudData(){return await this.adapter.loadCloudData()}getLocale(){return this.adapter.getLocale()}getDeviceType(){return this.adapter.getDeviceType()}getServerTimeMs(){return this.adapter.getServerTimeMs()}}const T=new Ps,ut=1,he="ricochet_miner_save_v1";function Se(m=Date.now()){return{version:ut,saveTimestamp:m,coins:0,totalCoinsEarned:0,shards:0,prestigeLevel:0,relicGems:0,ascensionTier:0,ascensionRecords:[],unlockedAchievements:[],claimedAchievements:[],runsCompleted:0,recentRunEarnings:[],recentRunCoinsPerMin:120,maxDepthMeters:0,unlockedBiomeIndex:0,selectedBiomeIndex:0,bossGateHpByBiome:{},upgrades:{damage:1,bounces:1,multiorb:1,orbsize:1,luck:1,orevalue:1},unlockedSkins:["steel_sawblade"],equippedSkin:"steel_sawblade",skinRvProgress:{},overdrivePasses:0,stats:{tntDetonated:0,bumpersHit:0,blocksDestroyed:0,vaultsBroken:0,maxBounceCombo:0,runsCompleted:0},loginStreak:{day:1,lastClaimDate:"",claimedToday:!1},dailyQuests:{dateKey:ke(m),quests:[],megaChestClaimed:!1},settings:{muted:!1,sfxMuted:!1,musicMuted:!1,musicVolume:"high",aimMode:"direct",aimModeUserSet:!1},ftueDone:!1,lastActiveTimestamp:m}}function we(m,e=Date.now()){const t=Se(e);if(!m)return t;try{const s=JSON.parse(m);if(!s||typeof s!="object")return t;const i={...t,...s,upgrades:{...t.upgrades,...s.upgrades??{}},stats:{...t.stats,...s.stats??{}},loginStreak:{...t.loginStreak,...s.loginStreak??{}},dailyQuests:{...t.dailyQuests,...s.dailyQuests??{}},settings:{...t.settings,...s.settings??{}},version:ut};return(!Array.isArray(i.unlockedSkins)||i.unlockedSkins.length===0)&&(i.unlockedSkins=["steel_sawblade"]),i.unlockedSkins.includes(i.equippedSkin)||(i.equippedSkin="steel_sawblade"),(!Number.isFinite(i.coins)||i.coins<0)&&(i.coins=0),(!Number.isFinite(i.totalCoinsEarned)||i.totalCoinsEarned<0)&&(i.totalCoinsEarned=i.coins),(!Number.isFinite(i.ascensionTier)||i.ascensionTier<0)&&(i.ascensionTier=0),Array.isArray(i.ascensionRecords)||(i.ascensionRecords=[]),Array.isArray(i.unlockedAchievements)||(i.unlockedAchievements=[]),Array.isArray(i.claimedAchievements)||(i.claimedAchievements=[]),i.settings.musicVolume!=="off"&&i.settings.musicVolume!=="low"&&i.settings.musicVolume!=="high"&&(i.settings.musicVolume=i.settings.musicMuted?"off":"high"),i.settings.musicVolume==="off"&&(i.settings.musicMuted=!0),i}catch{return t}}function Us(m,e){return e?e.totalCoinsEarned>m.totalCoinsEarned?e:m.totalCoinsEarned>e.totalCoinsEarned?m:e.saveTimestamp>m.saveTimestamp?e:m:m}class Ns{constructor(e){d(this,"storage");d(this,"memoryFallback",new Map);d(this,"storageWriteFailed",!1);if(e!==void 0)this.storage=e;else if(typeof window<"u")try{this.storage=window.localStorage}catch{this.storage=null}else this.storage=null}loadLocal(e=Date.now()){if(this.storageWriteFailed){const t=this.memoryFallback.get(he)??null;return we(t,e)}try{const t=this.storage?.getItem(he)??this.memoryFallback.get(he)??null;return we(t,e)}catch{this.storageWriteFailed=!0;const t=this.memoryFallback.get(he)??null;return we(t,e)}}saveLocal(e){e.saveTimestamp=Date.now();const t=JSON.stringify(e);this.memoryFallback.set(he,t);try{this.storage?.setItem(he,t),this.storageWriteFailed=!1}catch{this.storageWriteFailed=!0}return t}resetProgress(e=Date.now()){const t=Se(e);return this.saveLocal(t),t}}class Fs{getSpec(e){const t=te.find(s=>s.id===e);if(!t)throw new Error(`Unknown upgrade: ${e}`);return t}getLevel(e,t){return e.upgrades[t]??1}getMaxLevel(e,t){return this.getSpec(t).maxLevel+nt(e.ascensionTier)}isMaxLevel(e,t){return this.getLevel(e,t)>=this.getMaxLevel(e,t)}getUpgradeCost(e,t){const s=this.getSpec(t),i=this.getLevel(e,t);return Bt(s,i)}canAfford(e,t){return this.isMaxLevel(e,t)?!1:e.coins>=this.getUpgradeCost(e,t)}buyUpgrade(e,t){if(!this.canAfford(e,t))return!1;const s=this.getUpgradeCost(e,t);return e.coins-=s,e.upgrades[t]=this.getLevel(e,t)+1,!0}grantFreeUpgrade(e,t){return this.isMaxLevel(e,t)?!1:(e.upgrades[t]=this.getLevel(e,t)+1,!0)}getCheapestNearlyAffordableUpgrade(e,t,s){let i=null,a=Number.POSITIVE_INFINITY;for(const n of te){if(this.isMaxLevel(e,n.id))continue;const c=this.getUpgradeCost(e,n.id);if(e.coins>=c)continue;const o=(c-e.coins)/c;o>=t&&o<=s&&c<a&&(a=c,i=n.id)}return i}getEffectiveDrillDamage(e){return It(e.upgrades.damage,e.prestigeLevel,e.ascensionTier)}getEffectiveMaxBounces(e){return Dt(e.upgrades.bounces)}getEffectiveMultiOrbCount(e){return Lt(e.upgrades.multiorb)}getEffectiveOrbRadius(e){return Ot(e.upgrades.orbsize)}getEffectiveOreValueMultiplier(e){return ct(e.upgrades.orevalue)}}class Vs{constructor(){d(this,"sessionElapsedS",0);d(this,"lastMidgameAdTimeS",-9999);d(this,"lastDoubleRunAt",-99);d(this,"lastFreeUpgradeAt",-99);d(this,"lastOverdriveAt",-99)}updateSessionTime(e){this.sessionElapsedS+=e}canShowMidgameAd(){return this.sessionElapsedS<j.MIDGAME_GRACE_PERIOD_S?!1:this.sessionElapsedS-this.lastMidgameAdTimeS>=j.MIDGAME_COOLDOWN_S}resetMidgameCooldown(){this.lastMidgameAdTimeS=this.sessionElapsedS}async tryShowMidgameAd(){return this.canShowMidgameAd()?(this.lastMidgameAdTimeS=this.sessionElapsedS,await T.showMidgameAd()):{rewarded:!1,reason:"skipped"}}async showRewarded(e){const t=await T.showRewardedAd(e);return t.rewarded&&this.resetMidgameCooldown(),t}canOfferDoubleRun(e,t){if(t<=0||e.runsCompleted<1||e.runsCompleted-this.lastDoubleRunAt<j.RV_DOUBLE_RUN_COOLDOWN_RUNS)return!1;if(e.recentRunEarnings.length===0)return!0;const s=e.recentRunEarnings.reduce((i,a)=>i+a,0)/e.recentRunEarnings.length;return t>=s*j.RV_DOUBLE_RUN_RATIO}markDoubleRunOffered(e){this.lastDoubleRunAt=e}canOfferFreeUpgrade(e){return e-this.lastFreeUpgradeAt>=j.RV_FREE_UPGRADE_COOLDOWN_RUNS}markFreeUpgradeOffered(e){this.lastFreeUpgradeAt=e}canOfferOverdriveTrial(e){return e>=2&&e-this.lastOverdriveAt>=j.RV_OVERDRIVE_COOLDOWN_RUNS}markOverdriveOffered(e){this.lastOverdriveAt=e}}class $s{getSelectedBiome(e){const t=Math.max(0,Math.min(e.unlockedBiomeIndex,e.selectedBiomeIndex));return I[t]??I[0]}getBaseRowOffset(e){const t=this.getSelectedBiome(e);return Math.floor(t.startDepthM/g.METERS_PER_ROW)}selectBiome(e,t){return t<0||t>e.unlockedBiomeIndex||t>=I.length?!1:(e.selectedBiomeIndex=t,!0)}unlockNextBiome(e,t){const s=t+1;return s>=I.length?!1:(delete e.bossGateHpByBiome[t],s>e.unlockedBiomeIndex?(e.unlockedBiomeIndex=s,e.selectedBiomeIndex=s,!0):!1)}recordBossCoreDamage(e,t,s,i){e.bossGateHpByBiome[t]||(e.bossGateHpByBiome[t]=[-1,-1,-1]),e.bossGateHpByBiome[t][s]=Math.max(0,i)}completeFinalGateClear(e,t,s){if(delete e.bossGateHpByBiome[U.FINAL_BIOME_INDEX],!t)return{ascended:!1,newTier:e.ascensionTier};const i=e.ascensionTier+1;e.ascensionTier=i;const a=ot(i);return e.ascensionRecords.push({tier:i,titleKey:a.titleKey,blocksSmashed:s.blocksSmashed,maxCombo:s.maxCombo,timestamp:s.timestamp}),e.selectedBiomeIndex=0,{ascended:!0,newTier:i}}checkMasteryFeats(e,t){const s=[],i=a=>{e.unlockedAchievements.includes(a)||(e.unlockedAchievements.push(a),s.push(a))};return t.tntChainMax>=5&&i("chain_detonator"),t.maxCombo>=50&&i("combo_master"),te.some(a=>(e.upgrades[a.id]??1)>=20)&&i("heavy_investor"),t.isFullShaftRun&&t.maxDepthMeters>=I[3].startDepthM&&i("zero_skip_purist"),s}claimMasteryFeat(e,t){if(!e.unlockedAchievements.includes(t)||e.claimedAchievements.includes(t))return 0;const s=st.find(i=>i.id===t);return s?(e.claimedAchievements.push(t),e.coins+=s.rewardCoins,e.totalCoinsEarned+=s.rewardCoins,s.rewardCoins):0}hasUnclaimedFeats(e){return e.unlockedAchievements.some(t=>!e.claimedAchievements.includes(t))}canPrestige(e){return e.maxDepthMeters>=Ct}triggerPrestige(e){return this.canPrestige(e)?(e.prestigeLevel+=1,e.relicGems+=1,e.coins=0,e.unlockedBiomeIndex=0,e.selectedBiomeIndex=0,e.bossGateHpByBiome={},e.upgrades={damage:1,bounces:1,multiorb:1,orbsize:1,luck:1,orevalue:1},!0):!1}}class Gs{calculateOfflineEarnings(e,t){if(e.runsCompleted<V.OFFLINE_UNLOCK_RUNS||!e.lastActiveTimestamp||t<=e.lastActiveTimestamp)return 0;const i=(t-e.lastActiveTimestamp)/6e4;if(i<V.OFFLINE_MIN_MINUTES)return 0;const a=V.OFFLINE_MAX_HOURS*60,n=Math.min(i,a),c=Math.max(10,e.recentRunCoinsPerMin)*V.OFFLINE_RATE_FRACTION;return Math.max(1,Math.floor(n*c))}refreshDailyQuestsIfNeeded(e,t){const s=ke(t);if(e.dailyQuests.dateKey===s&&e.dailyQuests.quests.length===3)return;const i=[...V.DAILY_QUEST_POOL];let a=0;for(let c=0;c<s.length;c++)a=a*31+s.charCodeAt(c)>>>0;const n=[];for(let c=0;c<3;c++){const o=(a+c*2)%i.length,l=i.splice(o,1)[0];n.push({id:l.id,progress:0,target:l.target,claimed:!1})}e.dailyQuests={dateKey:s,quests:n,megaChestClaimed:!1}}recordQuestProgress(e,t,s){for(const i of e.dailyQuests.quests){const a=V.DAILY_QUEST_POOL.find(n=>n.id===i.id);a&&a.metric===t&&!i.claimed&&(i.progress=Math.min(i.target,i.progress+s))}}claimQuest(e,t){const s=e.dailyQuests.quests.find(a=>a.id===t);if(!s||s.claimed||s.progress<s.target)return 0;const i=V.DAILY_QUEST_POOL.find(a=>a.id===s.id);return i?(s.claimed=!0,e.coins+=i.rewardCoins,e.totalCoinsEarned+=i.rewardCoins,i.rewardCoins):0}canClaimMegaChest(e){return e.dailyQuests.megaChestClaimed?!1:e.dailyQuests.quests.length===3&&e.dailyQuests.quests.every(t=>t.claimed)}claimMegaChest(e){return this.canClaimMegaChest(e)?(e.dailyQuests.megaChestClaimed=!0,e.coins+=V.DAILY_MEGA_CHEST_COINS,e.totalCoinsEarned+=V.DAILY_MEGA_CHEST_COINS,e.shards+=V.DAILY_MEGA_CHEST_SHARDS,!0):!1}syncLoginStreakState(e,t){const s=ke(t);if(e.loginStreak.lastClaimDate===s){e.loginStreak.claimedToday=!0;return}if(e.loginStreak.claimedToday=!1,e.loginStreak.lastClaimDate){const i=Date.parse(`${e.loginStreak.lastClaimDate}T00:00:00Z`),a=Date.parse(`${s}T00:00:00Z`),n=Math.round((a-i)/864e5);n>1?e.loginStreak.day=1:n===1&&(e.loginStreak.day=e.loginStreak.day>=7?1:e.loginStreak.day+1)}}claimDailyLoginReward(e,t){if(this.syncLoginStreakState(e,t),e.loginStreak.claimedToday)return!1;const s=Math.max(0,Math.min(6,e.loginStreak.day-1)),i=V.LOGIN_REWARDS[s];return i.type==="coins"?(e.coins+=i.amount,e.totalCoinsEarned+=i.amount):i.type==="free_damage"?e.upgrades.damage=Math.min(40,e.upgrades.damage+i.amount):i.type==="shards"?e.shards+=i.amount:i.type==="overdrive_pass"?e.overdrivePasses+=i.amount:i.type==="skin"&&(e.unlockedSkins.includes(i.skinId)||e.unlockedSkins.push(i.skinId)),e.loginStreak.lastClaimDate=ke(t),e.loginStreak.claimedToday=!0,!0}}class qs{getEquippedSkin(e){return ue.find(t=>t.id===e.equippedSkin)??ue[0]}checkAndUnlockEligibleSkins(e){const t=[];for(const s of ue)e.unlockedSkins.includes(s.id)||(s.category==="milestone"&&typeof s.unlockBiomeIndex=="number"&&e.unlockedBiomeIndex>=s.unlockBiomeIndex||s.category==="mastery"&&s.masteryStat&&typeof s.masteryTarget=="number"&&e.stats[s.masteryStat]>=s.masteryTarget)&&(e.unlockedSkins.push(s.id),t.push(s.id));return t}equipSkin(e,t){return e.unlockedSkins.includes(t)?(e.equippedSkin=t,!0):!1}unlockWithCoins(e,t){const s=ue.find(i=>i.id===t);return!s||e.unlockedSkins.includes(t)||!s.coinCost||e.coins<s.coinCost?!1:(e.coins-=s.coinCost,e.unlockedSkins.push(t),e.equippedSkin=t,!0)}addRvProgress(e,t){const s=ue.find(n=>n.id===t);if(!s||e.unlockedSkins.includes(t)||!s.rvCost)return!1;const a=(e.skinRvProgress[t]??0)+1;return e.skinRvProgress[t]=a,a>=s.rvCost?(e.unlockedSkins.push(t),e.equippedSkin=t,!0):!1}}const Hs={coin:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9.5" fill="#fbbf24" stroke="#1a1310" stroke-width="2.2"/><circle cx="12" cy="12" r="5.5" stroke="#b45309" stroke-width="1.8"/></svg>',pickaxe:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M5 19L15 9" stroke="#d97706" stroke-width="3" stroke-linecap="round"/><path d="M9 5c4-1 8 1 10 5l-3 2c-1.5-2.5-4-3.8-7-4V5z" fill="#94a3b8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',pause:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="6" y="5" width="4.5" height="14" rx="1.5" fill="#f8fafc" stroke="#1a1310" stroke-width="1.8"/><rect x="13.5" y="5" width="4.5" height="14" rx="1.5" fill="#f8fafc" stroke="#1a1310" stroke-width="1.8"/></svg>',play:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M7 5l12 7-12 7V5z" fill="#f8fafc" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',soundOn:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9z" fill="#f8fafc" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><path d="M16.5 8.5a5 5 0 010 7M19 6a8.5 8.5 0 010 12" stroke="#f8fafc" stroke-width="2.2" stroke-linecap="round"/></svg>',soundOff:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9z" fill="#94a3b8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><path d="M16 9l5 6m0-6l-5 6" stroke="#ef4444" stroke-width="2.4" stroke-linecap="round"/></svg>',upgradePickaxe:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><path d="M5 19L15 9" stroke="#fde68a" stroke-width="3" stroke-linecap="round"/><path d="M8 4c5-1 9 2 11 6l-3 2c-1.5-2.5-4.5-4-8-4.5V4z" fill="#38bdf8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',questClipboard:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="5" y="4" width="14" height="16" rx="2.5" fill="#e2e8f0" stroke="#1a1310" stroke-width="2"/><rect x="9" y="2" width="6" height="4" rx="1" fill="#fbbf24" stroke="#1a1310" stroke-width="1.8"/><path d="M8.5 11h7M8.5 15h5" stroke="#334155" stroke-width="2" stroke-linecap="round"/></svg>',streakArrows:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M7 18V7m0 0l-3.5 3.5M7 7l3.5 3.5M17 18V7m0 0l-3.5 3.5M17 7l3.5 3.5" stroke="#fb923c" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',elevatorCar:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="5" y="4" width="14" height="16" rx="2" fill="#64748b" stroke="#1a1310" stroke-width="2"/><path d="M12 8l3 3.5H9L12 8zm0 8l-3-3.5h6L12 16z" fill="#fde047"/></svg>',adPlay:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><rect x="3" y="5" width="18" height="14" rx="3" fill="#fffbeb" stroke="#1a1310" stroke-width="2"/><path d="M10 9l6 3-6 3V9z" fill="#d97706" stroke="#1a1310" stroke-width="1.4" stroke-linejoin="round"/></svg>',handPointer:'<svg viewBox="0 0 36 36" width="38" height="38" fill="none"><path d="M18 4v14m0 0l-5-5m5 5l5-5" stroke="#fde047" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="18" cy="27" r="6" fill="#fbbf24" stroke="#1a1310" stroke-width="2.5"/></svg>',globe:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9" fill="#38bdf8" stroke="#1a1310" stroke-width="2"/><ellipse cx="12" cy="12" rx="4" ry="9" stroke="#1a1310" stroke-width="1.6"/><path d="M3.5 9h17M3.5 15h17" stroke="#1a1310" stroke-width="1.6"/></svg>',palette:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9" fill="#e879f9" stroke="#1a1310" stroke-width="2"/><circle cx="9" cy="10" r="1.8" fill="#fde047"/><circle cx="14.5" cy="9.5" r="1.8" fill="#38bdf8"/><circle cx="14" cy="14.5" r="1.8" fill="#4ade80"/></svg>',lightning:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',orb:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="8" fill="#c084fc" stroke="#1a1310" stroke-width="2"/><circle cx="9.5" cy="9.5" r="2.2" fill="#f5d0fe"/></svg>',blast:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M12 2l2.5 5.5L20 6l-3 5.5L22 14l-5.5 2L18 21l-5.5-2.5L9 22l-1-5.5L2 15l4.5-3.5L4 6l5.5 1.5L12 2z" fill="#fb923c" stroke="#1a1310" stroke-width="1.8" stroke-linejoin="round"/></svg>',clover:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="9" cy="9" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/><circle cx="15" cy="9" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/><circle cx="12" cy="14.5" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/></svg>',gem:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M6 4h12l4 6-10 11L2 10l4-6z" fill="#e879f9" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',close:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#f8fafc" stroke-width="2.8" stroke-linecap="round"/></svg>',lock:'<svg viewBox="0 0 24 24" width="14" height="14" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" fill="#94a3b8" stroke="#1a1310" stroke-width="2"/><path d="M8 11V8a4 4 0 018 0v3" stroke="#cbd5e1" stroke-width="2.2"/></svg>',check:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M5 13l4 4L19 7" stroke="#4ade80" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',fastForward:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 6l8 6-8 6V6zm9 0l8 6-8 6V6z" fill="#fde047" stroke="#1a1310" stroke-width="1.8" stroke-linejoin="round"/></svg>',recall:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M12 19V6m0 0l-5 5m5-5l5 5" stroke="#f8fafc" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',restart:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 12a8 8 0 102.3-5.6L4 9m0-5v5h5" stroke="#f8fafc" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',gear:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="3.5" fill="#fbbf24" stroke="#1a1310" stroke-width="2"/><path d="M12 2v3m0 14v3M4.9 4.9l2.1 2.1m10 10l2.1 2.1M2 12h3m14 0h3M4.9 19.1l2.1-2.1m10-10l2.1-2.1" stroke="#cbd5e1" stroke-width="2.6" stroke-linecap="round"/></svg>',home:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M3 11l9-7 9 7v9a1.5 1.5 0 01-1.5 1.5H4.5A1.5 1.5 0 013 20v-9z" fill="#fbbf24" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><rect x="9.5" y="13" width="5" height="8" fill="#4b382a" stroke="#1a1310" stroke-width="1.6"/></svg>',bossCore:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><circle cx="12" cy="12" r="9" fill="#be123c" stroke="#1a1310" stroke-width="2"/><circle cx="12" cy="12" r="4.5" fill="#fde047"/></svg>'};function x(m){return`<span class="rm-ico" aria-hidden="true">${Hs[m]}</span>`}const zs=""+new URL("badge_ascension_star-B45ww98k.webp",import.meta.url).href,Ws=""+new URL("badge_chain_detonator-D65INHL_.webp",import.meta.url).href,Ks=""+new URL("badge_combo_master-Cnbs7_AW.webp",import.meta.url).href,js=""+new URL("badge_heavy_investor-BQfZH7w7.webp",import.meta.url).href,Ys=""+new URL("badge_zero_skip-KfsgLs7p.webp",import.meta.url).href,Qs=""+new URL("crest_tier_1-DAg54eJv.webp",import.meta.url).href,Xs=""+new URL("crest_tier_2-CS3GvrQL.webp",import.meta.url).href,Zs=""+new URL("crest_tier_3-D32WghhJ.webp",import.meta.url).href,Js=""+new URL("crest_tier_4-Bn1DmMec.webp",import.meta.url).href,ei=""+new URL("icon_chest-D_cFWHcx.webp",import.meta.url).href,pt=""+new URL("icon_drill_damage-D6r6sewr.webp",import.meta.url).href,ti=""+new URL("icon_gear_elevator-CSNPXUG4.webp",import.meta.url).href,si=""+new URL("icon_luck-S_sqklRE.webp",import.meta.url).href,mt=""+new URL("icon_max_bounces-p3pl0hif.webp",import.meta.url).href,ii=""+new URL("icon_multiball-DR5vWYDa.webp",import.meta.url).href,ai=""+new URL("icon_orb_size-Bz8fW7IA.webp",import.meta.url).href,ft=""+new URL("icon_ore_value-BdPwZk7R.webp",import.meta.url).href,ni=""+new URL("icon_trophy-Cq8U42vz.webp",import.meta.url).href,ri=""+new URL("ui_modal_frame-CTlqQCEp.webp",import.meta.url).href,oi=ri,E={drillDamage:pt,maxBounces:mt,oreValue:ft,trophy:ni,gearElevator:ti,chest:ei,badgeChainDetonator:Ws,badgeComboMaster:Ks,badgeHeavyInvestor:js,badgeZeroSkip:Ys,badgeAscensionStar:zs};function _e(m){return m<=1?Qs:m===2?Xs:m===3?Zs:Js}const li={damage:pt,bounces:mt,multiorb:ii,orbsize:ai,luck:si,orevalue:ft},ci={chain_detonator:E.badgeChainDetonator,combo_master:E.badgeComboMaster,heavy_investor:E.badgeHeavyInvestor,zero_skip_purist:E.badgeZeroSkip};class di{constructor(e){d(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}open(e,t,s){this.render(e,t,s),this.backdrop.style.display="flex"}render(e,t,s){const i=e.ascensionTier,a=it(i),n=at(i),c=nt(i),o=Math.round((rt(i)-1)*100),l=i>0?_e(i):E.badgeAscensionStar,r=i>0?`${f.t("tier_label").toUpperCase()} ${se(i)}`:f.t("no_ascension_yet"),h=Re.map(p=>{const u=i>=p.tier,_=e.ascensionRecords.find(k=>p.tier===4?k.tier>=4:k.tier===p.tier),b=_e(p.tier),v=se(p.tier);return`
        <div class="rm-achievement-card ${u?"unlocked":"locked"}">
          <div class="rm-icon-socket" style="border-color:${u?"#fbbf24":"#3b3531"};">
            <img src="${b}" style="${u?"":"filter:grayscale(1) brightness(0.45);"}" alt="" />
          </div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
              <span style="font-weight:900;font-size:13px;color:${u?"#fde047":"#94a3b8"};">
                ${f.t(p.titleKey)} (${f.t("tier_label")} ${v}${p.tier===4?"+":""})
              </span>
            </div>
            <div style="font-size:11px;color:${u?"#e2e8f0":"#94a3b8"};">
              ${_?`${f.t("blocks_smashed")}: ${O(_.blocksSmashed)} • ${f.t("max_combo_label")}: ${_.maxCombo}x`:f.t("asc_req_hint").replace("{tier}",v)}
            </div>
          </div>
          <span class="rm-lv-pill" style="border-color:${u?"#4ade80":"#4a3728"};color:${u?"#4ade80":"#94a3b8"};">
            ${x(u?"check":"lock")}
          </span>
        </div>
      `}).join(""),y=st.map(p=>{const u=e.unlockedAchievements.includes(p.id),_=e.claimedAchievements.includes(p.id),b=ci[p.id]??E.trophy;return`
        <div class="rm-achievement-card ${u?"unlocked":"locked"}">
          <div class="rm-icon-socket" style="border-color:${u?"#fbbf24":"#3b3531"};">
            <img src="${b}" style="${u?"":"filter:grayscale(1) brightness(0.45);"}" alt="" />
          </div>
          <div style="flex:1;min-width:0;">
            <div style="font-weight:900;font-size:13px;color:${u?"#fffbeb":"#94a3b8"};">
              ${f.t(p.nameKey)}
            </div>
            <div style="font-size:11px;color:#cbd5e1;">
              ${f.t(p.descKey)}
            </div>
          </div>
          ${_?`<span class="rm-lv-pill" style="color:#4ade80;border-color:#4ade80;">${f.t("claimed")}</span>`:u?`<button class="rm-btn rm-btn-green" style="min-height:36px;padding:4px 9px;font-size:11px;" data-feat-claim="${p.id}">
                  <img src="${E.oreValue}" style="width:14px;height:14px;object-fit:contain;" alt="" /> +${O(p.rewardCoins)}
                </button>`:`<span class="rm-lv-pill">${O(p.rewardCoins)}</span>`}
        </div>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div class="rm-modal-header">
          <div class="rm-header-plaque">
            <img src="${E.trophy}" style="width:22px;height:22px;object-fit:contain;" alt="" />
            ${f.t("hall_of_ascension")}
          </div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>

        <div class="rm-stat-plaque" style="flex-direction:row;justify-content:space-between;padding:8px 10px;border-color:#8c5a2b;flex-shrink:0;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img src="${l}" style="width:44px;height:44px;object-fit:contain;" alt="" />
            <div>
              <div style="font-weight:900;font-size:13px;color:#fde047;">${r}</div>
              <div style="font-size:11px;color:#e2e8f0;font-weight:800;">
                ${a}x HP • ${n.toFixed(2).replace(/\.00$/,"")}x ${f.t("coins")} • +${c} Cap • +${o}% DMG
              </div>
            </div>
          </div>
        </div>

        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">
            <div style="font-size:11px;font-weight:900;color:#fbbf24;letter-spacing:0.6px;margin-top:2px;">
              ${f.t("ascension_milestones").toUpperCase()}
            </div>
            ${h}
            <div style="font-size:11px;font-weight:900;color:#38bdf8;letter-spacing:0.6px;margin-top:6px;">
              ${f.t("mastery_feats").toUpperCase()}
            </div>
            ${y}
          </div>
        </div>
      </div>
    `,this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelectorAll("[data-feat-claim]").forEach(p=>{p.addEventListener("click",()=>{t(p.dataset.featClaim),this.render(e,t,s)})})}hide(){this.backdrop.style.display="none"}}function Je(m){const e=Math.max(1,Math.min(4,m));return new Array(e).fill('<svg viewBox="0 0 24 24" width="22" height="22" fill="none"><path d="M12 2l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 16.9 6.1 20l1.2-6.5L2.5 8.9l6.6-.9L12 2z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>').join("")}class hi{constructor(e){d(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}show(e){const t=ot(e.newTier),s=f.t(t.titleKey),i=f.t(t.quoteKey),a=se(e.newTier),n=se(e.newTier+1),c=_e(e.newTier),o=_e(e.newTier+1);this.backdrop.innerHTML=`
      <div class="arcade-modal-shell rm-victory-shell">
        <div class="rm-sunburst" aria-hidden="true"></div>

        <div class="rm-victory-crest-wrap">
          <div class="rm-victory-stars">${Je(Math.min(2,e.newTier))}</div>
          <img src="${c}" class="rm-victory-crest" alt="" />
          <div class="rm-victory-stars">${Je(Math.min(2,Math.max(1,e.newTier-1)))}</div>
        </div>

        <div class="rm-victory-ribbon">${f.t("one_shot_victory")}</div>

        <div style="text-align:center;position:relative;z-index:2;">
          <div class="rm-victory-title">${s.toUpperCase()} — ${f.t("tier_label").toUpperCase()} ${a}</div>
          <div class="rm-victory-quote">"${i}"</div>
        </div>

        <div class="rm-scroll-area" style="position:relative;z-index:2;">
          <div class="rm-stat-row">
            <div class="rm-stat-plaque">
              <img src="${E.drillDamage}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${f.t("blocks_smashed").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fffbeb;text-shadow:0 2px 0 #120c08;">${O(e.blocksSmashed)}</div>
            </div>
            <div class="rm-stat-plaque">
              <img src="${E.maxBounces}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${f.t("max_combo_label").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fde047;text-shadow:0 2px 0 #120c08;">${e.maxCombo}x</div>
            </div>
            <div class="rm-stat-plaque">
              <img src="${E.oreValue}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${f.t("earned_coins").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fbbf24;text-shadow:0 2px 0 #120c08;" data-vic="coins">${O(e.coinsEarned)}</div>
            </div>
            <div class="rm-stat-plaque" style="border-color:#d97706;">
              <img src="${o}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#fde68a;font-weight:900;letter-spacing:0.4px;">${f.t("next_tier_label").toUpperCase()} ${n}</div>
              <div style="font-size:10px;font-weight:900;color:#fffbeb;text-align:center;line-height:1.25;">${f.t("next_tier_preview")}</div>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;position:relative;z-index:2;flex-shrink:0;">
          <button class="rm-btn rm-btn-ascend" style="width:100%;min-height:48px;font-size:14px;" data-vic="descend">
            ${f.t("descend_to_tier").replace("{tier}",n)}
          </button>
          <div style="display:flex;gap:8px;">
            <button class="rm-btn rm-btn-primary" style="flex:1;min-height:44px;" data-vic="upgrades">
              <img src="${E.drillDamage}" style="width:18px;height:18px;object-fit:contain;" alt="" />
              ${f.t("upgrades").toUpperCase()}
            </button>
            ${e.coinsEarned>0?`<button class="rm-btn rm-btn-gold" style="flex:1;min-height:44px;" data-vic="double">
                    ${x("adPlay")} ${f.t("double_victory_coins")}
                  </button>`:""}
          </div>
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-vic="descend"]')?.addEventListener("click",()=>{this.hide(),e.onDescendNextTier()}),this.backdrop.querySelector('[data-vic="upgrades"]')?.addEventListener("click",()=>{this.hide(),e.onOpenUpgrades()});const l=this.backdrop.querySelector('[data-vic="double"]');l?.addEventListener("click",async()=>{if(l.disabled=!0,await e.onDoubleVictoryCoins()){const h=this.backdrop.querySelector('[data-vic="coins"]');h&&(h.textContent=O(e.coinsEarned*2)),l.style.display="none"}else l.disabled=!1})}hide(){this.backdrop.style.display="none"}}class ui{constructor(e,t){d(this,"panel",null)}}class pi{constructor(e){d(this,"el");this.el=document.createElement("div"),this.el.className="rm-ftue",this.el.innerHTML=`
      <div class="rm-ftue-hand">${x("handPointer")}</div>
      <div class="rm-pill" style="margin-top:8px;border-color:#fde047;color:#fde047;">
        ${f.t("drag_to_shoot")}
      </div>
    `,e.appendChild(this.el)}setVisible(e){this.el.style.display=e?"block":"none"}refreshText(){const e=this.el.querySelector(".rm-pill");e&&(e.textContent=f.t("drag_to_shoot"))}}const mi='<svg viewBox="0 0 24 24" width="14" height="14" fill="none"><path d="M12 2l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 8.3l6-.8L12 2z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>';class fi{constructor(e,t){d(this,"root");d(this,"topEl");d(this,"depthEl");d(this,"coinsEl");d(this,"biomeEl");d(this,"crestPillEl");d(this,"crestTextEl");d(this,"bouncesEl");d(this,"muteBtn");d(this,"speedBtn");d(this,"recallBtn");d(this,"overdriveBtn");d(this,"shopBtn");d(this,"shopBadgeEl");d(this,"achievementsBtn");d(this,"achievementsDotEl");d(this,"questBtn");d(this,"questDotEl");d(this,"loginBtn");d(this,"loginDotEl");d(this,"elevatorBtn");d(this,"toastEl");d(this,"toastTimer",null);d(this,"arcadeConsole");d(this,"runningBar");d(this,"bossRowEl");d(this,"bossBarEl");d(this,"bossTextEl");d(this,"bossFillEl");d(this,"bossIcoEl");d(this,"fullShaftPillEl");d(this,"gateHpBarEl");d(this,"gateTitleEl");d(this,"gateHpTextEl");d(this,"gateHpFillEl");this.root=e;const s=document.createElement("div");s.className="rm-hud-stack",this.root.appendChild(s),this.topEl=document.createElement("div"),this.topEl.className="rm-hud-top",this.topEl.innerHTML=`
      <div class="rm-pill-row">
        <div class="rm-pill">${x("coin")} <span data-hud="coins">0</span></div>
        <div class="rm-pill">${x("pickaxe")} <span data-hud="depth">0m</span></div>
        <div class="rm-pill"><span data-hud="biome">Sunlit Quarry</span></div>
        <div class="rm-ascension-crest-pill" data-hud="crest-pill" style="display:none;">
          <img src="${E.badgeAscensionStar}" style="width:16px;height:16px;object-fit:contain;" alt="" />
          <span data-hud="crest-text">TIER I</span>
        </div>
        <div class="rm-pill" data-hud="bounces-pill" style="display:none;">${x("lightning")} <span data-hud="bounces">0</span></div>
      </div>
      <div class="rm-pill-row rm-pill-row-nowrap">
        <button class="rm-btn" data-interactive="true" data-hud="pause" aria-label="Pause">${x("pause")}</button>
        <button class="rm-btn" data-interactive="true" data-hud="mute" aria-label="Mute">${x("soundOn")}</button>
      </div>
    `,s.appendChild(this.topEl),this.bossRowEl=document.createElement("div"),this.bossRowEl.className="rm-boss-row",this.bossRowEl.style.display="none",s.appendChild(this.bossRowEl),this.bossBarEl=document.createElement("div"),this.bossBarEl.className="rm-boss-bar",this.bossBarEl.innerHTML=`
      <span data-hud="boss-ico" class="rm-boss-pulse">${x("bossCore")}</span>
      <span data-hud="boss-text">0m / 150m to Biome 2 Boss</span>
      <div class="rm-boss-track"><div class="rm-boss-fill" data-hud="boss-fill" style="width:0%;"></div></div>
    `,this.bossRowEl.appendChild(this.bossBarEl),this.bossTextEl=this.bossBarEl.querySelector('[data-hud="boss-text"]'),this.bossFillEl=this.bossBarEl.querySelector('[data-hud="boss-fill"]'),this.bossIcoEl=this.bossBarEl.querySelector('[data-hud="boss-ico"]'),this.fullShaftPillEl=document.createElement("div"),this.fullShaftPillEl.className="rm-fullshaft-pill",this.fullShaftPillEl.innerHTML=`<span class="rm-ico" aria-hidden="true">${mi}</span> <span data-lbl="fullshaft">${f.t("full_shaft_run")}</span>`,this.bossRowEl.appendChild(this.fullShaftPillEl),this.gateHpBarEl=document.createElement("div"),this.gateHpBarEl.className="rm-gate-hp-bar",this.gateHpBarEl.innerHTML=`
      <div class="rm-gate-hp-head">
        <span style="display:inline-flex;align-items:center;gap:5px;">${x("bossCore")} <span data-hud="gate-title">${f.t("boss_gate")}</span></span>
        <span data-hud="gate-hp-text">0 / 0</span>
      </div>
      <div class="rm-gate-hp-track">
        <div class="rm-gate-hp-fill" data-hud="gate-hp-fill" style="width:100%;"></div>
      </div>
    `,s.appendChild(this.gateHpBarEl),this.gateTitleEl=this.gateHpBarEl.querySelector('[data-hud="gate-title"]'),this.gateHpTextEl=this.gateHpBarEl.querySelector('[data-hud="gate-hp-text"]'),this.gateHpFillEl=this.gateHpBarEl.querySelector('[data-hud="gate-hp-fill"]'),this.coinsEl=this.topEl.querySelector('[data-hud="coins"]'),this.depthEl=this.topEl.querySelector('[data-hud="depth"]'),this.biomeEl=this.topEl.querySelector('[data-hud="biome"]'),this.crestPillEl=this.topEl.querySelector('[data-hud="crest-pill"]'),this.crestTextEl=this.topEl.querySelector('[data-hud="crest-text"]'),this.bouncesEl=this.topEl.querySelector('[data-hud="bounces"]'),this.muteBtn=this.topEl.querySelector('[data-hud="mute"]'),this.muteBtn.addEventListener("click",t.onToggleMute),this.topEl.querySelector('[data-hud="pause"]')?.addEventListener("click",t.onTogglePause),this.runningBar=document.createElement("div"),this.runningBar.className="rm-bottom-bar",this.runningBar.style.display="none",this.runningBar.innerHTML=`
      <button class="rm-btn" data-interactive="true" data-hud="speed">${x("fastForward")} <span data-lbl="speed">${f.t("fast_forward")}</span></button>
      <button class="rm-btn rm-btn-gold" data-interactive="true" data-hud="recall">${x("recall")} <span data-lbl="recall">${f.t("recall")}</span></button>
    `,this.root.appendChild(this.runningBar),this.speedBtn=this.runningBar.querySelector('[data-hud="speed"]'),this.recallBtn=this.runningBar.querySelector('[data-hud="recall"]'),this.speedBtn.addEventListener("click",t.onToggleSpeed),this.recallBtn.addEventListener("click",t.onRecall),this.arcadeConsole=document.createElement("div"),this.arcadeConsole.className="rm-arcade-console",this.arcadeConsole.innerHTML=`
      <button class="rm-btn rm-btn-primary" data-interactive="true" data-hud="shop">
        ${x("upgradePickaxe")} <span data-lbl="upgrades">${f.t("upgrades").toUpperCase()}</span>
        <span class="rm-badge-count" data-hud="shop-badge" style="display:none;">0</span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="achievements">
        <img src="${E.trophy}" style="width:18px;height:18px;object-fit:contain;" alt="" />
        <span data-lbl="achievements">${f.t("achievements")}</span>
        <span class="rm-dot" data-hud="ach-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="quests">
        ${x("questClipboard")} <span data-lbl="quests">${f.t("quests")}</span>
        <span class="rm-dot" data-hud="quest-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="login">
        ${x("streakArrows")} <span data-lbl="streak">${f.t("streak_short")}</span>
        <span class="rm-dot" data-hud="login-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="elevator" style="display:none;">
        ${x("elevatorCar")} <span data-lbl="elevator">${f.t("elevator")}</span>
      </button>
      <button class="rm-btn rm-btn-gold" data-interactive="true" data-hud="overdrive" style="display:none;flex-direction:column;gap:1px;padding:6px 10px;">
        <span style="display:inline-flex;align-items:center;gap:6px;">${x("adPlay")} <span data-lbl="superorb">${f.t("super_orb_label")}</span></span>
        <span data-lbl="freead" style="font-size:10px;opacity:0.9;">${f.t("free_ad_sub")}</span>
      </button>
    `,this.root.appendChild(this.arcadeConsole),this.shopBtn=this.arcadeConsole.querySelector('[data-hud="shop"]'),this.shopBadgeEl=this.arcadeConsole.querySelector('[data-hud="shop-badge"]'),this.achievementsBtn=this.arcadeConsole.querySelector('[data-hud="achievements"]'),this.achievementsDotEl=this.arcadeConsole.querySelector('[data-hud="ach-dot"]'),this.questBtn=this.arcadeConsole.querySelector('[data-hud="quests"]'),this.questDotEl=this.arcadeConsole.querySelector('[data-hud="quest-dot"]'),this.loginBtn=this.arcadeConsole.querySelector('[data-hud="login"]'),this.loginDotEl=this.arcadeConsole.querySelector('[data-hud="login-dot"]'),this.elevatorBtn=this.arcadeConsole.querySelector('[data-hud="elevator"]'),this.overdriveBtn=this.arcadeConsole.querySelector('[data-hud="overdrive"]'),this.shopBtn.addEventListener("click",t.onOpenShop),this.achievementsBtn.addEventListener("click",t.onOpenAchievements),this.questBtn.addEventListener("click",t.onOpenQuests),this.loginBtn.addEventListener("click",t.onOpenDailyLogin),this.elevatorBtn.addEventListener("click",t.onOpenElevator),this.overdriveBtn.addEventListener("click",t.onTriggerOverdriveAd),this.toastEl=document.createElement("div"),this.toastEl.className="rm-toast",this.toastEl.style.display="none",this.root.appendChild(this.toastEl)}refreshLabels(){const e=(t,s)=>{const i=this.root.querySelector(t);i&&(i.textContent=s)};e('[data-lbl="speed"]',f.t("fast_forward")),e('[data-lbl="recall"]',f.t("recall")),e('[data-lbl="upgrades"]',f.t("upgrades").toUpperCase()),e('[data-lbl="achievements"]',f.t("achievements")),e('[data-lbl="quests"]',f.t("quests")),e('[data-lbl="streak"]',f.t("streak_short")),e('[data-lbl="elevator"]',f.t("elevator")),e('[data-lbl="superorb"]',f.t("super_orb_label")),e('[data-lbl="freead"]',f.t("free_ad_sub")),e('[data-lbl="fullshaft"]',f.t("full_shaft_run"))}update(e){if(this.topEl.style.display=e.isTitle?"none":"flex",this.bossRowEl.style.display=e.isTitle?"none":"flex",this.bossTextEl.textContent=e.bossProgressText,this.bossFillEl.style.width=`${Math.max(0,Math.min(100,e.bossProgressPct))}%`,this.bossIcoEl.classList.toggle("rm-boss-pulse",e.bossNear||e.isRunning),this.fullShaftPillEl.style.display=e.isFullShaftRun?"inline-flex":"none",e.ascensionTier>=1?(this.crestPillEl.style.display="inline-flex",this.crestTextEl.textContent=`${f.t("tier_label").toUpperCase()} ${se(e.ascensionTier)}`):this.crestPillEl.style.display="none",!e.isTitle&&e.activeGate&&e.activeGate.maxHp>0){const s=Math.max(0,Math.min(100,e.activeGate.hp/e.activeGate.maxHp*100));this.gateHpBarEl.style.display="flex",this.gateHpBarEl.classList.toggle("critical",s<=20),this.gateTitleEl.textContent=`${f.t("boss_gate")} (${e.activeGate.coresAlive}/3)`,this.gateHpTextEl.textContent=`${O(Math.ceil(e.activeGate.hp))} / ${O(Math.ceil(e.activeGate.maxHp))}`,this.gateHpFillEl.style.width=`${s}%`}else this.gateHpBarEl.style.display="none",this.gateHpBarEl.classList.remove("critical");this.coinsEl.textContent=O(e.coins),this.depthEl.textContent=De(e.depthMeters),this.biomeEl.textContent=e.biomeName,this.muteBtn.innerHTML=x(e.muted?"soundOff":"soundOn");const t=this.topEl.querySelector('[data-hud="bounces-pill"]');t&&(t.style.display=e.isRunning?"inline-flex":"none"),this.bouncesEl.textContent=Math.ceil(e.bouncesLeft).toString(),this.runningBar.style.display=e.isRunning?"flex":"none",this.speedBtn.style.borderColor=e.speedMult>1?"#fde047":"#1a1310",this.arcadeConsole.style.display=e.isAiming?"flex":"none",this.elevatorBtn.style.display=e.hasElevator?"inline-flex":"none",this.overdriveBtn.style.display=e.showOverdriveOffer?"inline-flex":"none",this.achievementsDotEl.style.display=e.hasUnclaimedFeats?"block":"none",this.loginDotEl.style.display=e.hasClaimableLogin?"block":"none",this.questDotEl.style.display=e.hasClaimableQuest?"block":"none",this.shopBadgeEl.style.display=e.affordableUpgradeCount>0?"inline-flex":"none",this.shopBadgeEl.textContent=e.affordableUpgradeCount.toString()}showToast(e,t=2200){this.toastEl.textContent=e,this.toastEl.style.display="block",this.toastTimer!==null&&window.clearTimeout(this.toastTimer),this.toastTimer=window.setTimeout(()=>{this.toastEl.style.display="none",this.toastTimer=null},t)}}class gi{constructor(e){d(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}showOfflineModal(e,t){this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.chest}" class="rm-crown-icon" alt="" />
        <div style="display:flex;justify-content:center;">
          <div class="rm-header-plaque">${f.t("welcome_back")}</div>
        </div>
        <p style="margin:0;text-align:center;color:#cbd5e1;font-size:13px;">${f.t("offline_earned")}</p>
        <div class="rm-stat-plaque" style="flex-direction:row;justify-content:center;gap:10px;">
          <img src="${E.oreValue}" style="width:32px;height:32px;object-fit:contain;" alt="" />
          <span style="font-size:26px;font-weight:900;color:#fbbf24;">${O(e)}</span>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="rm-btn rm-btn-green" style="flex:1.1;min-height:48px;" data-act="collect">${f.t("collect")}</button>
          <button class="rm-btn rm-btn-gold" style="flex:1;min-height:48px;" data-act="collect2x">${x("adPlay")} ${f.t("collect_2x")}</button>
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="collect"]')?.addEventListener("click",()=>{this.hide(),t(!1)}),this.backdrop.querySelector('[data-act="collect2x"]')?.addEventListener("click",()=>{this.hide(),t(!0)})}showDailyLogin(e,t,s){const i=V.LOGIN_REWARDS.map(a=>{const n=a.day===e.loginStreak.day,c=a.day<e.loginStreak.day||n&&e.loginStreak.claimedToday;return`
        <div class="rm-upgrade-plaque" style="justify-content:space-between;border-color:${n?"#fbbf24":"#120c08"};">
          <span style="font-weight:900;font-size:13px;">Day ${a.day}: ${f.t(a.labelKey)}</span>
          <span style="font-size:12px;color:${c?"#4ade80":"#fbbf24"};">${c?x("check"):n?"READY":x("lock")}</span>
        </div>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.chest}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${f.t("daily_login")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${i}</div></div>
        ${e.loginStreak.claimedToday?`<button class="rm-btn" disabled>${f.t("claimed")}</button>`:`<button class="rm-btn rm-btn-green" data-act="claim">${f.t("claim")}</button>`}
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelector('[data-act="claim"]')?.addEventListener("click",()=>{t(),this.hide(),s()})}showDailyQuests(e,t,s,i,a){const n=e.dailyQuests.quests.map(o=>{const l=V.DAILY_QUEST_POOL.find(y=>y.id===o.id),r=l?f.t(l.labelKey):o.id,h=o.progress>=o.target;return`
          <div class="rm-upgrade-plaque" style="justify-content:space-between;">
            <div>
              <div style="font-weight:900;font-size:13px;">${r}</div>
              <div style="font-size:12px;color:#cbd5e1;display:inline-flex;align-items:center;gap:5px;">
                ${o.progress}/${o.target}
                <img src="${E.oreValue}" style="width:15px;height:15px;object-fit:contain;" alt="" />
                ${l?.rewardCoins??0}
              </div>
            </div>
            ${o.claimed?`${x("check")}`:h?`<button class="rm-btn rm-btn-green" style="min-height:36px;" data-qclaim="${o.id}">${f.t("claim")}</button>`:`<span class="rm-lv-pill">${o.progress}/${o.target}</span>`}
          </div>
        `}).join(""),c=t.canClaimMegaChest(e);this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.chest}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${f.t("quests")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${n}</div></div>
        <button class="rm-btn rm-btn-gold" data-act="mega" ${c?"":"disabled"}>
          <img src="${E.chest}" style="width:22px;height:22px;object-fit:contain;" alt="" />
          ${f.t("daily_mega_chest")}
        </button>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),a()}),this.backdrop.querySelectorAll("[data-qclaim]").forEach(o=>{o.addEventListener("click",()=>{s(o.dataset.qclaim)})}),this.backdrop.querySelector('[data-act="mega"]')?.addEventListener("click",i)}showElevator(e,t,s){const i=I.map(a=>{const n=a.index<=e.unlockedBiomeIndex;return`
        <button class="rm-btn ${a.index===e.selectedBiomeIndex?"rm-btn-primary":""}" data-biome="${a.index}" ${n?"":"disabled"} style="justify-content:space-between;">
          <span>${f.t(a.nameKey)} (${a.startDepthM}m)</span>
          <span class="rm-lv-pill">${n?`${a.coinMultiplier}x`:x("lock")}</span>
        </button>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.gearElevator}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${f.t("elevator")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${i}</div></div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelectorAll("[data-biome]").forEach(a=>{a.addEventListener("click",()=>{t(Number(a.dataset.biome)),this.hide(),s()})})}showPauseModal(e,t,s,i){this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div style="display:flex;justify-content:center;">
          <div class="rm-header-plaque">${x("pause")} ${f.t("paused")}</div>
        </div>
        <button class="rm-btn rm-btn-green" style="min-height:48px;" data-act="resume">${x("play")} ${f.t("resume")}</button>
        <button class="rm-btn" data-act="restart">${x("restart")} ${f.t("restart_run")}</button>
        <div style="display:flex;gap:8px;">
          <button class="rm-btn" style="flex:1;" data-act="settings">
            <img src="${E.gearElevator}" style="width:20px;height:20px;object-fit:contain;" alt="" /> ${f.t("settings")}
          </button>
          <button class="rm-btn rm-btn-gold" style="flex:1;" data-act="home">${x("home")} ${f.t("home_btn")}</button>
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="resume"]')?.addEventListener("click",()=>{this.hide(),e()}),this.backdrop.querySelector('[data-act="restart"]')?.addEventListener("click",()=>{this.hide(),t()}),this.backdrop.querySelector('[data-act="settings"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelector('[data-act="home"]')?.addEventListener("click",()=>{this.hide(),i()})}showBiomeUnlockModal(e,t,s,i){const a=s.length>0?`<div class="rm-stat-plaque" style="border-color:#4ade80;padding:8px;">
            <div style="font-size:11px;color:#86efac;font-weight:900;">${f.t("skin_unlocked_badge").toUpperCase()}</div>
            <div style="font-size:15px;font-weight:900;color:#fffbeb;">${s.join(", ")}</div>
          </div>`:"";this.backdrop.innerHTML=`
      <div class="arcade-modal-shell" style="border-color:#fbbf24;">
        <img src="${E.trophy}" class="rm-crown-icon" style="width:68px;height:68px;" alt="" />
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
          <div class="rm-new-best">${f.t("biome_unlocked_desc").toUpperCase()}</div>
          <div class="rm-header-plaque" style="color:#fde047;">${f.t("biome_unlocked_title")}</div>
        </div>
        <div class="rm-stat-plaque" style="border-color:#fbbf24;">
          <div style="font-size:22px;font-weight:900;color:#38bdf8;text-shadow:0 2px 0 #120c08;">${e}</div>
          <div style="font-size:14px;font-weight:900;color:#fbbf24;">${t}x ${f.t("coin_mult_badge")}</div>
        </div>
        ${a}
        <button class="rm-btn rm-btn-green" style="min-height:50px;font-size:16px;" data-act="biome-go">
          ${x("elevatorCar")} ${f.t("descend_now")}
        </button>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="biome-go"]')?.addEventListener("click",()=>{this.hide(),i()})}hide(){this.backdrop.style.display="none"}}class yi{constructor(e){d(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}show(e){const t=se((e.currentAscensionTier??0)+1),s=e.clearedBiome6ViaElevator?`
        <div class="rm-teaser-banner">
          <img src="${E.badgeZeroSkip}" style="width:42px;height:42px;object-fit:contain;flex-shrink:0;" alt="" />
          <div style="flex:1;min-width:0;">
            <div style="font-weight:900;font-size:13px;color:#fde047;">${f.t("elevator_clear_title")}</div>
            <div style="font-size:11px;color:#fffbeb;line-height:1.3;">${f.t("elevator_clear_desc").replace("{tier}",t)}</div>
          </div>
          <button class="rm-btn rm-btn-gold" style="min-height:38px;padding:6px 10px;font-size:11px;flex-shrink:0;" data-act="start0m">
            ${f.t("start_0m_run")}
          </button>
        </div>
      `:"";this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.trophy}" class="rm-crown-icon" style="width:64px;height:64px;" alt="" />
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
          ${e.isNewBest?`<div class="rm-new-best">${f.t("new_best_badge")}</div>`:""}
          <div class="rm-header-plaque">${f.t("run_complete")}</div>
        </div>

        ${s}

        <div class="rm-stat-row">
          <div class="rm-stat-plaque">
            <img src="${E.oreValue}" style="width:36px;height:36px;object-fit:contain;" alt="" />
            <div style="font-size:11px;color:#cbd5e1;font-weight:800;">${f.t("earned_coins")}</div>
            <div style="font-size:21px;font-weight:900;color:#fbbf24;text-shadow:0 2px 0 #120c08;">${O(e.coinsEarned)}</div>
          </div>
          <div class="rm-stat-plaque">
            <img src="${E.drillDamage}" style="width:36px;height:36px;object-fit:contain;" alt="" />
            <div style="font-size:11px;color:#cbd5e1;font-weight:800;">${f.t("max_depth")}</div>
            <div style="font-size:21px;font-weight:900;color:#fffbeb;text-shadow:0 2px 0 #120c08;">${De(e.maxDepthMeters)}</div>
          </div>
        </div>

        <div style="display:flex;gap:8px;">
          <button class="rm-btn rm-btn-green" style="flex:1.15;min-height:50px;" data-act="relaunch">
            ${x("play")} ${f.t("launch_again")}
          </button>
          <button class="rm-btn rm-btn-primary" style="flex:1;min-height:50px;" data-act="shop">
            <img src="${E.drillDamage}" style="width:20px;height:20px;object-fit:contain;" alt="" />
            ${f.t("upgrades")}
            ${e.affordableUpgradeCount>0?`<span class="rm-badge-count">${e.affordableUpgradeCount}</span>`:""}
          </button>
        </div>

        ${e.showExtraLaunchAd?`<button class="rm-btn rm-btn-gold" data-act="extra">${x("adPlay")} ${f.t("extra_launch_cta")}</button>`:""}
        ${e.showDoubleAd?`<button class="rm-btn rm-btn-gold" data-act="double">
                <img src="${E.oreValue}" style="width:20px;height:20px;object-fit:contain;" alt="" />
                ${x("adPlay")} ${f.t("double_run_cta")}
              </button>`:""}
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="start0m"]')?.addEventListener("click",()=>{this.hide(),e.onStartZeroMeterRun?.()}),this.backdrop.querySelector('[data-act="relaunch"]')?.addEventListener("click",()=>{this.hide(),e.onRelaunch()}),this.backdrop.querySelector('[data-act="shop"]')?.addEventListener("click",()=>{this.hide(),e.onOpenShop()}),this.backdrop.querySelector('[data-act="double"]')?.addEventListener("click",e.onDoubleAd),this.backdrop.querySelector('[data-act="extra"]')?.addEventListener("click",e.onExtraLaunchAd)}hide(){this.backdrop.style.display="none"}}const bi=[{code:"en",label:"English"},{code:"ru",label:"Русский"},{code:"es",label:"Español"},{code:"pt",label:"Português"},{code:"fr",label:"Français"},{code:"de",label:"Deutsch"},{code:"tr",label:"Türkçe"},{code:"ja",label:"日本語"},{code:"ko",label:"한국어"}];class _i{constructor(e){d(this,"backdrop");d(this,"confirmingReset",!1);this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}open(e,t,s){this.confirmingReset=!1,this.render(e,t,s),this.backdrop.style.display="flex"}render(e,t,s){if(this.confirmingReset){this.backdrop.innerHTML=`
        <div class="arcade-modal-shell">
          <div style="display:flex;justify-content:center;">
            <div class="rm-header-plaque" style="color:#fca5a5;">${f.t("reset_progress")}</div>
          </div>
          <p style="margin:0;text-align:center;color:#e2e8f0;font-size:14px;line-height:1.45;">
            ${f.t("reset_confirm_desc")}
          </p>
          <div style="display:flex;gap:10px;">
            <button class="rm-btn rm-btn-primary" style="flex:1;" data-set="cancel-reset">${f.t("cancel_btn")}</button>
            <button class="rm-btn rm-btn-crimson" style="flex:1;" data-set="confirm-reset">${f.t("confirm_reset_btn")}</button>
          </div>
        </div>
      `,this.backdrop.querySelector('[data-set="cancel-reset"]')?.addEventListener("click",()=>{this.confirmingReset=!1,this.render(e,t,s)}),this.backdrop.querySelector('[data-set="confirm-reset"]')?.addEventListener("click",()=>{this.hide(),s.onConfirmReset()});return}const i=bi.map(n=>`<option value="${n.code}" ${n.code===t?"selected":""}>${n.label}</option>`).join(""),a=e.settings.musicVolume??(e.settings.musicMuted?"off":"high");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${E.gearElevator}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${f.t("settings")}</div>
          <button class="rm-btn rm-close-btn" data-set="close" aria-label="Close">${x("close")}</button>
        </div>

        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">
            <button class="rm-btn" style="justify-content:space-between;" data-set="sfx">
              <span>${x(e.settings.sfxMuted?"soundOff":"soundOn")} ${f.t("sfx_label")}</span>
              <span style="color:${e.settings.sfxMuted?"#fca5a5":"#4ade80"};">${e.settings.sfxMuted?f.t("vol_off"):"ON"}</span>
            </button>

            <div class="rm-btn" style="justify-content:space-between;cursor:default;">
              <span style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;" data-set="music">
                ${x(a==="off"?"soundOff":"soundOn")} ${f.t("music_label")}
              </span>
              <span style="display:inline-flex;gap:4px;">
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="off"?"#ef4444":"#3f2e21"};color:${a==="off"?"#fca5a5":"#94a3b8"};" data-set="music-vol" data-vol="off">${f.t("vol_off")}</button>
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="low"?"#fbbf24":"#3f2e21"};color:${a==="low"?"#fde047":"#94a3b8"};" data-set="music-vol" data-vol="low">${f.t("vol_low")}</button>
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="high"?"#22c55e":"#3f2e21"};color:${a==="high"?"#4ade80":"#94a3b8"};" data-set="music-vol" data-vol="high">${f.t("vol_high")}</button>
              </span>
            </div>

            <button class="rm-btn" style="justify-content:space-between;" data-set="aim">
              <span>${x("orb")} ${f.t("aim_mode_label")}</span>
              <span style="color:#38bdf8;">${e.settings.aimMode==="slingshot"?f.t("aim_slingshot"):f.t("aim_direct")}</span>
            </button>

            <label class="rm-btn" style="justify-content:space-between;">
              <span style="display:inline-flex;align-items:center;gap:6px;">${x("globe")} ${f.t("language_label")}</span>
              <select data-set="lang" style="background:#181210;color:#fffbeb;border:1.5px solid #8c5a2b;border-radius:6px;padding:4px 8px;font-weight:800;font-size:13px;">
                ${i}
              </select>
            </label>
          </div>
        </div>

        <button class="rm-btn rm-btn-crimson" data-set="reset" style="margin-top:4px;">
          ${f.t("reset_progress")}
        </button>
      </div>
    `,this.backdrop.querySelector('[data-set="close"]')?.addEventListener("click",()=>{this.hide(),s.onClose()}),this.backdrop.querySelector('[data-set="sfx"]')?.addEventListener("click",()=>{s.onToggleSfx(),this.render(e,t,s)}),this.backdrop.querySelector('[data-set="music"]')?.addEventListener("click",()=>{s.onToggleMusic(),this.render(e,t,s)}),this.backdrop.querySelectorAll('[data-set="music-vol"]').forEach(n=>{n.addEventListener("click",()=>{const c=n.dataset.vol;s.onSetMusicVolume(c),this.render(e,t,s)})}),this.backdrop.querySelector('[data-set="aim"]')?.addEventListener("click",()=>{s.onToggleAimMode(),this.render(e,t,s)}),this.backdrop.querySelector('[data-set="lang"]')?.addEventListener("change",n=>{const c=n.target.value;s.onSelectLocale(c),this.render(e,c,s)}),this.backdrop.querySelector('[data-set="reset"]')?.addEventListener("click",()=>{this.confirmingReset=!0,this.render(e,t,s)})}hide(){this.backdrop.style.display="none"}}const Ee="rm-shop-banner-slot";class vi{constructor(e){d(this,"backdrop");d(this,"tab","upgrades");d(this,"isOpen",!1);this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}open(e,t,s,i,a,n,c="upgrades"){this.tab=c,this.isOpen=!0,this.render(e,t,s,i,a,n),this.backdrop.style.display="flex",T.supportsBanners&&T.requestBanner(Ee)}render(e,t,s,i,a,n){if(!this.isOpen)return;const c=i.canPrestige(e)?`<button class="rm-btn rm-btn-gold" data-act="prestige">${x("lightning")} ${f.t("prestige_btn")} (+50%)</button>`:"";let o="";this.tab==="upgrades"?o=`
        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">${te.map(r=>{const h=t.getLevel(e,r.id),y=t.getMaxLevel(e,r.id),p=t.isMaxLevel(e,r.id),u=t.getUpgradeCost(e,r.id),_=t.canAfford(e,r.id),b=a===r.id;return`
          <div class="rm-upgrade-plaque">
            <div class="rm-icon-socket">
              <img src="${li[r.id]}" alt="" />
            </div>
            <div style="flex:1;min-width:0;">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                <span style="font-weight:900;font-size:13px;text-shadow:0 2px 0 #120c08;">${f.t(r.nameKey)}</span>
                <span class="rm-lv-pill">LV. ${h}/${y}</span>
              </div>
              <div style="font-size:11px;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                ${f.t(r.descKey)}
              </div>
            </div>
            <div style="display:flex;gap:5px;align-items:center;">
              ${b?`<button class="rm-btn rm-btn-gold" style="min-height:40px;padding:4px 8px;font-size:11px;" data-free-upg="${r.id}">${x("adPlay")}</button>`:""}
              <button class="rm-btn rm-buy-btn ${p?"":_?"rm-btn-green":"unaffordable"}" data-upg="${r.id}" ${p||!_?"disabled":""}>
                ${p?f.t("maxed"):`<img src="${E.oreValue}" style="width:16px;height:16px;object-fit:contain;" alt="" /> ${O(u)}`}
              </button>
            </div>
          </div>
        `}).join("")}</div>
        </div>
        ${c}
      `:o=`<div class="rm-scroll-area"><div class="rm-upgrade-grid">${ue.map(r=>{const h=e.unlockedSkins.includes(r.id),y=e.equippedSkin===r.id,p=e.skinRvProgress[r.id]??0,u=ht.getSkinThumbnailUrl(r.id);let _="";if(y)_=`<span class="rm-btn rm-btn-gold" style="min-height:34px;font-size:11px;cursor:default;">${x("check")} ${f.t("equipped")}</span>`;else if(h)_=`<button class="rm-btn rm-btn-green" style="min-height:34px;font-size:11px;" data-equip="${r.id}">${f.t("select_btn")}</button>`;else{const b=!!(r.coinCost&&e.coins>=r.coinCost);_=`
            <div style="display:flex;flex-direction:column;gap:4px;align-items:center;width:100%;">
              ${r.coinCost?`<button class="rm-btn ${b?"rm-btn-green":"unaffordable"}" style="min-height:32px;font-size:11px;padding:4px 8px;width:100%;" data-coin-unlock="${r.id}" ${b?"":"disabled"}>
                      <img src="${E.oreValue}" style="width:15px;height:15px;object-fit:contain;" alt="" /> ${O(r.coinCost)}
                    </button>`:""}
              ${r.rvCost?`<button class="rm-btn rm-btn-gold" style="min-height:32px;font-size:11px;padding:4px 8px;width:100%;" data-rv-skin="${r.id}">${x("adPlay")} ${p}/${r.rvCost}</button>`:""}
              <span style="font-size:10px;color:#cbd5e1;display:inline-flex;align-items:center;gap:3px;">${x("lock")} ${f.t(r.unlockDescKey)}</span>
            </div>
          `}return`
          <div class="rm-skin-card">
            <div class="rm-skin-showcase" style="border-color:${y?"#fbbf24":"#8c5a2b"};">
              <img src="${u}" alt="${f.t(r.nameKey)}" />
            </div>
            <div class="rm-skin-name">${f.t(r.nameKey)}</div>
            ${_}
          </div>
        `}).join("")}</div></div>`,this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div class="rm-modal-header">
          <div style="display:flex;gap:6px;">
            <button class="rm-btn ${this.tab==="upgrades"?"rm-btn-primary":""}" data-tab="upgrades">
              <img src="${E.drillDamage}" style="width:18px;height:18px;object-fit:contain;" alt="" /> ${f.t("upgrades")}
            </button>
            <button class="rm-btn ${this.tab==="skins"?"rm-btn-primary":""}" data-tab="skins">
              ${x("palette")} ${f.t("skins")}
            </button>
          </div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        ${o}
        <div id="${Ee}" class="rm-banner-slot"></div>
      </div>
    `,this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.close(),n.onClose()}),this.backdrop.querySelector('[data-tab="upgrades"]')?.addEventListener("click",()=>{this.tab="upgrades",this.render(e,t,s,i,a,n)}),this.backdrop.querySelector('[data-tab="skins"]')?.addEventListener("click",()=>{this.tab="skins",this.render(e,t,s,i,a,n)}),this.backdrop.querySelector('[data-act="prestige"]')?.addEventListener("click",n.onPrestige),this.backdrop.querySelectorAll("[data-upg]").forEach(l=>{l.addEventListener("click",()=>{const r=l.dataset.upg;n.onBuyUpgrade(r)})}),this.backdrop.querySelectorAll("[data-free-upg]").forEach(l=>{l.addEventListener("click",()=>{const r=l.dataset.freeUpg;n.onFreeUpgradeAd(r)})}),this.backdrop.querySelectorAll("[data-equip]").forEach(l=>{l.addEventListener("click",()=>{const r=l.dataset.equip;n.onEquipSkin(r)})}),this.backdrop.querySelectorAll("[data-coin-unlock]").forEach(l=>{l.addEventListener("click",()=>{const r=l.dataset.coinUnlock;n.onUnlockSkinCoins(r)})}),this.backdrop.querySelectorAll("[data-rv-skin]").forEach(l=>{l.addEventListener("click",()=>{const r=l.dataset.rvSkin;n.onUnlockSkinAd(r)})})}close(){this.isOpen&&(this.isOpen=!1,this.backdrop.style.display="none",T.supportsBanners&&T.clearBanner(Ee))}}class xi{constructor(e){d(this,"el");d(this,"visible",!1);this.el=document.createElement("div"),this.el.className="rm-title-overlay",this.el.style.display="none",e.appendChild(this.el)}show(e){this.visible=!0,this.el.classList.remove("hiding"),this.el.style.display="flex";const t=e.ascensionTier>=1?`<div class="rm-ascension-crest-pill">
            <img src="${_e(e.ascensionTier)}" style="width:20px;height:20px;object-fit:contain;" alt="" />
            <img src="${E.badgeAscensionStar}" style="width:16px;height:16px;object-fit:contain;" alt="" />
            <span>${f.t("tier_label").toUpperCase()} ${se(e.ascensionTier)}</span>
          </div>`:"";this.el.innerHTML=`
      <img src="${e.logoUrl}" class="rm-logo-img" alt="Ricochet Miner" />

      <button class="rm-btn rm-btn-green rm-play-btn" data-title="play" data-interactive="true">
        ${x("play")} ${f.t("play_btn")}
      </button>

      ${e.bestDepthMeters>0?`<div class="rm-pill" style="border-color:#fbbf24;">${x("pickaxe")} ${f.t("best_depth")}: ${De(e.bestDepthMeters)}</div>`:""}
      ${t}

      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:center;">
        <button class="rm-btn" data-title="mute" data-interactive="true" aria-label="Mute">
          ${x(e.muted?"soundOff":"soundOn")}
        </button>
        <button class="rm-btn" data-title="skins" data-interactive="true">
          ${x("palette")} ${f.t("skins")}
        </button>
        <button class="rm-btn" data-title="achievements" data-interactive="true">
          <img src="${E.trophy}" style="width:18px;height:18px;object-fit:contain;" alt="" />
          ${f.t("achievements")}
          ${e.hasUnclaimedFeats?'<span class="rm-dot"></span>':""}
        </button>
        <button class="rm-btn" data-title="settings" data-interactive="true">
          ${x("gear")} ${f.t("settings")}
        </button>
      </div>
    `,this.el.querySelector('[data-title="play"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),this.hideAnimated(e.callbacks.onPlay)}),this.el.querySelector('[data-title="mute"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onToggleMute()}),this.el.querySelector('[data-title="skins"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenSkins()}),this.el.querySelector('[data-title="achievements"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenAchievements()}),this.el.querySelector('[data-title="settings"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenSettings()})}hideAnimated(e){this.visible&&(this.visible=!1,this.el.classList.add("hiding"),window.setTimeout(()=>{this.el.style.display="none",this.el.classList.remove("hiding"),e()},220))}hideImmediate(){this.visible=!1,this.el.style.display="none"}}function ki(){if(typeof document>"u"||document.getElementById("rm-styles"))return;const m=document.createElement("style");m.id="rm-styles",m.textContent=`
    html, body, #app, #ui-root {
      scrollbar-width: none;
      -ms-overflow-style: none;
    }
    html::-webkit-scrollbar,
    body::-webkit-scrollbar,
    .rm-modal::-webkit-scrollbar,
    .arcade-modal-shell::-webkit-scrollbar,
    .rm-scroll-area::-webkit-scrollbar {
      display: none;
      width: 0;
      height: 0;
    }
    .rm-ico {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .rm-hud-stack {
      position: absolute;
      top: max(8px, env(safe-area-inset-top));
      left: max(8px, env(safe-area-inset-left));
      right: max(8px, env(safe-area-inset-right));
      display: flex;
      flex-direction: column;
      gap: 6px;
      pointer-events: none;
      z-index: 10;
    }
    .rm-hud-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 6px;
      pointer-events: none;
    }
    .rm-pill-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      align-items: center;
      min-width: 0;
    }
    .rm-pill-row-nowrap {
      flex-wrap: nowrap;
      flex-shrink: 0;
    }
    .rm-pill {
      background: linear-gradient(180deg, #4b382a 0%, #2e2017 100%);
      border: 2.5px solid #1a1310;
      box-shadow: inset 0 2px 0 rgba(255, 240, 200, 0.22), 0 4px 0 #1a1310;
      border-radius: 12px;
      padding: 5px 10px;
      font-size: clamp(11px, 2.8vw, 14px);
      font-weight: 900;
      color: #fffbeb;
      text-shadow: 0 2px 0 #1a1310;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      max-width: 42vw;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .rm-btn {
      position: relative;
      min-width: 42px;
      min-height: 42px;
      border-radius: 12px;
      border: 2.5px solid #1a1310;
      background: linear-gradient(180deg, #5c4433 0%, #3d2b1f 100%);
      box-shadow: inset 0 2px 0 rgba(255, 245, 220, 0.25), 0 4px 0 #1a1310;
      color: #fffbeb;
      text-shadow: 0 2px 0 #1a1310;
      font-size: clamp(11px, 2.7vw, 14px);
      font-weight: 900;
      padding: 7px 11px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      overflow: visible;
      white-space: nowrap;
      transition: transform 0.06s ease, box-shadow 0.06s ease;
    }
    .rm-btn:active:not(:disabled) {
      transform: translateY(3px);
      box-shadow: inset 0 2px 0 rgba(255, 245, 220, 0.15), 0 1px 0 #1a1310;
    }
    .rm-btn-primary {
      background: linear-gradient(180deg, #38bdf8 0%, #0284c7 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.45), 0 4px 0 #0c4a6e, 0 6px 0 #1a1310;
    }
    .rm-btn-gold {
      background: linear-gradient(180deg, #fbbf24 0%, #d97706 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 220, 0.55), 0 4px 0 #92400e, 0 6px 0 #1a1310;
      color: #fffbeb;
    }
    .rm-btn-green {
      background: linear-gradient(180deg, #4ade80 0%, #16a34a 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.5), 0 4px 0 #14532d, 0 6px 0 #1a1310;
    }
    .rm-btn-crimson {
      background: linear-gradient(180deg, #b91c1c 0%, #7f1d1d 100%);
      box-shadow: inset 0 2px 0 rgba(255, 220, 220, 0.3), 0 4px 0 #450a0a, 0 6px 0 #1a1310;
    }
    .rm-btn:disabled {
      opacity: 0.45;
      cursor: not-allowed;
    }
    .rm-badge-count {
      position: absolute;
      top: -7px;
      right: -7px;
      min-width: 20px;
      height: 20px;
      border-radius: 999px;
      background: #ef4444;
      border: 2px solid #1a1310;
      color: #ffffff;
      font-size: 11px;
      font-weight: 900;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0 4px;
    }
    .rm-dot {
      position: absolute;
      top: 5px;
      right: 5px;
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: #ef4444;
      border: 2px solid #1a1310;
    }
    .rm-arcade-console {
      position: absolute;
      bottom: max(10px, env(safe-area-inset-bottom));
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(180deg, #332720 0%, #1e1612 100%);
      border: 3px solid #1a1310;
      box-shadow: inset 0 2px 0 rgba(255, 235, 200, 0.16), 0 6px 18px rgba(0,0,0,0.65);
      border-radius: 16px;
      padding: 7px;
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
      justify-content: center;
      width: max-content;
      max-width: calc(100vw - 16px);
      z-index: 12;
      pointer-events: auto;
    }
    @media (min-width: 900px) and (min-aspect-ratio: 11/10) {
      .rm-arcade-console {
        left: auto;
        right: 16px;
        bottom: 20px;
        transform: none;
        flex-direction: column;
        align-items: stretch;
        width: 206px;
        padding: 10px;
        gap: 8px;
      }
    }
    .rm-bottom-bar {
      position: absolute;
      bottom: max(12px, env(safe-area-inset-bottom));
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 8px;
      justify-content: center;
      z-index: 12;
    }
    .rm-modal-backdrop {
      position: absolute;
      inset: 0;
      background: rgba(10, 8, 7, 0.78);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: clamp(8px, 2.5vw, 16px);
      pointer-events: auto;
      z-index: 30;
    }
    .rm-modal,
    .arcade-modal-shell {
      position: relative;
      width: min(490px, 100%);
      max-height: 88dvh;
      overflow: hidden;
      background: #231b16;
      border-style: solid;
      border-width: clamp(14px, 3.2vw, 22px);
      border-image-source: url("${oi}");
      border-image-slice: 74;
      border-image-repeat: stretch;
      box-shadow: inset 0 0 26px rgba(0, 0, 0, 0.75), 0 24px 55px rgba(0, 0, 0, 0.85);
      padding: 6px 8px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      color: #fffbeb;
      scrollbar-width: none;
      -ms-overflow-style: none;
    }
    .rm-scroll-area {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      scrollbar-width: none;
      -ms-overflow-style: none;
      padding-right: 1px;
    }
    .rm-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    .rm-header-plaque {
      background: linear-gradient(180deg, #4b3526 0%, #312117 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 225, 165, 0.25), 0 3px 0 #120c08;
      border-radius: 10px;
      padding: 6px 12px;
      color: #fbbf24;
      font-weight: 900;
      font-size: clamp(14px, 3.5vw, 18px);
      text-shadow: 0 2px 0 #120c08;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      letter-spacing: 0.4px;
      white-space: nowrap;
    }
    .rm-close-btn {
      min-width: 38px;
      min-height: 38px;
      padding: 6px;
      border-radius: 10px;
      background: linear-gradient(180deg, #7f1d1d 0%, #450a0a 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 200, 200, 0.25), 0 3px 0 #120c08;
      flex-shrink: 0;
    }
    .rm-crown-icon {
      width: 52px;
      height: 52px;
      object-fit: contain;
      display: block;
      margin: -2px auto 0 auto;
      flex-shrink: 0;
      filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.75));
    }
    .rm-new-best {
      align-self: center;
      background: linear-gradient(180deg, #fde047 0%, #d97706 100%);
      border: 2px solid #120c08;
      color: #120c08;
      font-size: 11px;
      font-weight: 900;
      padding: 2px 10px;
      border-radius: 999px;
      letter-spacing: 0.8px;
      box-shadow: 0 2px 0 #120c08;
    }
    .rm-stat-row {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .rm-stat-plaque {
      background: #19130f;
      border: 2px solid #4a3728;
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.65);
      border-radius: 12px;
      padding: 10px 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
    .rm-upgrade-list {
      display: flex;
      flex-direction: column;
      gap: 7px;
    }
    .rm-upgrade-plaque {
      background: linear-gradient(180deg, #3c2e24 0%, #271d16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 7px 8px;
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
    }
    .rm-icon-socket {
      width: 46px;
      height: 46px;
      border-radius: 10px;
      background: #181210;
      border: 2px solid #4a3728;
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.75);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      padding: 3px;
    }
    .rm-icon-socket img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
    .rm-lv-pill {
      display: inline-block;
      background: #181210;
      border: 1.5px solid #8c5a2b;
      color: #fbbf24;
      font-size: 10px;
      font-weight: 900;
      padding: 1px 6px;
      border-radius: 6px;
      letter-spacing: 0.4px;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .rm-buy-btn {
      min-width: 78px;
      min-height: 40px;
      padding: 6px 9px;
      font-size: 12px;
      flex-shrink: 0;
    }
    .rm-buy-btn.unaffordable {
      opacity: 0.72;
      background: linear-gradient(180deg, #3b3531 0%, #24201d 100%);
      box-shadow: 0 3px 0 #120c08;
    }
    .rm-upgrade-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .rm-skin-card {
      background: linear-gradient(180deg, #3c2e24 0%, #241b16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      text-align: center;
      min-width: 0;
    }
    .rm-skin-name {
      font-weight: 900;
      font-size: 12px;
      text-shadow: 0 2px 0 #120c08;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .rm-skin-showcase {
      width: 62px;
      height: 62px;
      border-radius: 14px;
      background: #181210;
      border: 2.5px solid #8c5a2b;
      box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 5px;
    }
    .rm-skin-showcase img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
    .rm-toast {
      position: absolute;
      top: 96px;
      left: 50%;
      transform: translateX(-50%);
      background: #1a1310;
      border: 2px solid #fbbf24;
      color: #fde047;
      padding: 8px 16px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 900;
      z-index: 60;
      pointer-events: none;
      white-space: nowrap;
      max-width: 90vw;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .rm-banner-slot {
      width: 100%;
      min-height: 54px;
      background: rgba(10, 8, 7, 0.75);
      border: 1.5px dashed rgba(251, 191, 36, 0.35);
      border-radius: 10px;
      display: none;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      color: #cbd5e1;
      flex-shrink: 0;
    }
    .rm-ftue {
      position: absolute;
      top: 29%;
      left: 50%;
      transform: translateX(-50%);
      text-align: center;
      pointer-events: none;
      z-index: 15;
    }
    .rm-ftue-hand {
      display: inline-block;
      animation: rmPull 1.3s ease-in-out infinite;
    }
    @keyframes rmPull {
      0%, 100% { transform: translateY(0px); opacity: 0.95; }
      50% { transform: translateY(28px); opacity: 0.65; }
    }
    .rm-title-overlay {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 50% 35%, rgba(26, 19, 16, 0.45), rgba(10, 8, 7, 0.78));
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 18px;
      padding: 20px;
      z-index: 25;
      pointer-events: auto;
      transition: opacity 0.22s ease, transform 0.22s ease;
    }
    .rm-title-overlay.hiding {
      opacity: 0;
      transform: scale(1.03);
      pointer-events: none;
    }
    .rm-logo-img {
      width: min(440px, 86vw);
      max-height: 36vh;
      object-fit: contain;
      filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.85));
      animation: rmLogoFloat 3.2s ease-in-out infinite;
      pointer-events: none;
    }
    .rm-boss-bar {
      align-self: flex-start;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(26, 19, 16, 0.9);
      border: 2px solid #1a1310;
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fde68a;
      pointer-events: none;
      box-shadow: 0 3px 0 #1a1310;
      max-width: calc(100vw - 24px);
    }
    .rm-boss-track {
      width: 78px;
      height: 8px;
      background: #2e2017;
      border: 1.5px solid #1a1310;
      border-radius: 999px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .rm-boss-fill {
      height: 100%;
      background: linear-gradient(90deg, #f59e0b, #ef4444);
      transition: width 0.15s ease;
    }
    .rm-boss-pulse {
      animation: rmBossPulse 0.9s ease-in-out infinite;
    }
    .rm-gate-hp-bar {
      align-self: center;
      width: min(360px, calc(100vw - 24px));
      background: linear-gradient(180deg, #3b1318 0%, #220b0e 100%);
      border: 2.5px solid #1a1310;
      border-radius: 12px;
      padding: 5px 10px;
      box-shadow: inset 0 2px 0 rgba(255, 180, 180, 0.2), 0 4px 0 #1a1310;
      display: none;
      flex-direction: column;
      gap: 4px;
      pointer-events: none;
    }
    .rm-gate-hp-bar.critical {
      border-color: #fbbf24;
      animation: rmGateCritical 0.75s ease-in-out infinite;
    }
    @keyframes rmGateCritical {
      0%, 100% { box-shadow: 0 0 8px rgba(251, 191, 36, 0.45), 0 4px 0 #1a1310; }
      50% { box-shadow: 0 0 18px rgba(239, 68, 68, 0.85), 0 4px 0 #1a1310; }
    }
    .rm-gate-hp-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      font-weight: 900;
      color: #fecaca;
      text-shadow: 0 1px 0 #120c08;
    }
    .rm-gate-hp-track {
      width: 100%;
      height: 10px;
      background: #18090b;
      border: 1.5px solid #120c08;
      border-radius: 999px;
      overflow: hidden;
    }
    .rm-gate-hp-fill {
      height: 100%;
      background: linear-gradient(90deg, #ef4444 0%, #f97316 55%, #fde047 100%);
      transition: width 0.08s linear;
    }
    .rm-boss-row {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      pointer-events: none;
    }
    .rm-fullshaft-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: linear-gradient(180deg, #4b3519 0%, #2d1d0b 100%);
      border: 2px solid #fbbf24;
      box-shadow: 0 3px 0 #1a1310, 0 0 10px rgba(251, 191, 36, 0.35);
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fde047;
      text-shadow: 0 1px 0 #120c08;
      white-space: nowrap;
    }
    .rm-ascension-crest-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: linear-gradient(180deg, #6b4c14 0%, #3d2807 100%);
      border: 2px solid #fde047;
      box-shadow: inset 0 1px 0 rgba(255, 250, 210, 0.4), 0 3px 0 #1a1310;
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fffbeb;
      text-shadow: 0 1px 0 #120c08;
      white-space: nowrap;
    }
    .rm-victory-shell {
      overflow: visible;
      padding-top: 38px;
    }
    .rm-sunburst {
      position: absolute;
      top: -90px;
      left: 50%;
      width: 260px;
      height: 260px;
      margin-left: -130px;
      background: conic-gradient(
        from 0deg,
        rgba(253, 224, 71, 0.28) 0deg 15deg,
        transparent 15deg 30deg,
        rgba(251, 191, 36, 0.26) 30deg 45deg,
        transparent 45deg 60deg,
        rgba(253, 224, 71, 0.28) 60deg 75deg,
        transparent 75deg 90deg,
        rgba(251, 191, 36, 0.26) 90deg 105deg,
        transparent 105deg 120deg,
        rgba(253, 224, 71, 0.28) 120deg 135deg,
        transparent 135deg 150deg,
        rgba(251, 191, 36, 0.26) 150deg 165deg,
        transparent 165deg 180deg,
        rgba(253, 224, 71, 0.28) 180deg 195deg,
        transparent 195deg 210deg,
        rgba(251, 191, 36, 0.26) 210deg 225deg,
        transparent 225deg 240deg,
        rgba(253, 224, 71, 0.28) 240deg 255deg,
        transparent 255deg 270deg,
        rgba(251, 191, 36, 0.26) 270deg 285deg,
        transparent 285deg 300deg,
        rgba(253, 224, 71, 0.28) 300deg 315deg,
        transparent 315deg 330deg,
        rgba(251, 191, 36, 0.26) 330deg 345deg,
        transparent 345deg 360deg
      );
      border-radius: 50%;
      mask-image: radial-gradient(circle, #000 18%, transparent 72%);
      -webkit-mask-image: radial-gradient(circle, #000 18%, transparent 72%);
      animation: rmSunburstSpin 18s linear infinite;
      pointer-events: none;
      z-index: 1;
    }
    @keyframes rmSunburstSpin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    .rm-victory-crest-wrap {
      position: absolute;
      top: -54px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      z-index: 3;
      pointer-events: none;
    }
    .rm-victory-crest {
      width: 86px;
      height: 86px;
      object-fit: contain;
      filter: drop-shadow(0 6px 12px rgba(0, 0, 0, 0.85));
    }
    .rm-victory-stars {
      display: inline-flex;
      gap: 2px;
      filter: drop-shadow(0 3px 4px rgba(0, 0, 0, 0.85));
    }
    .rm-victory-ribbon {
      align-self: center;
      position: relative;
      z-index: 2;
      background: linear-gradient(180deg, #4b3526 0%, #2b1c12 100%);
      border: 2.5px solid #fbbf24;
      box-shadow: inset 0 2px 0 rgba(255, 240, 200, 0.3), 0 4px 0 #120c08;
      border-radius: 10px;
      padding: 4px 16px;
      color: #fde68a;
      font-weight: 900;
      font-size: 13px;
      letter-spacing: 0.8px;
      text-shadow: 0 2px 0 #120c08;
    }
    .rm-victory-title {
      font-size: clamp(18px, 4.4vw, 22px);
      font-weight: 900;
      color: #fde047;
      text-shadow: 0 3px 0 #120c08;
      letter-spacing: 0.6px;
      margin-top: 2px;
    }
    .rm-victory-quote {
      font-size: 12px;
      font-style: italic;
      color: #fef3c7;
      line-height: 1.35;
      margin-top: 4px;
      text-shadow: 0 1px 0 #120c08;
    }
    .rm-btn-ascend {
      background: linear-gradient(180deg, #dc2626 0%, #b45309 100%);
      border-color: #fde047;
      box-shadow: inset 0 2px 0 rgba(255, 235, 190, 0.5), 0 4px 0 #7f1d1d, 0 6px 0 #1a1310;
      color: #fffbeb;
    }
    .rm-teaser-banner {
      background: linear-gradient(180deg, #4a3118 0%, #2a1b0d 100%);
      border: 2.5px solid #fbbf24;
      border-radius: 12px;
      padding: 8px 10px;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.2), 0 3px 0 #120c08;
    }
    .rm-achievement-card {
      background: linear-gradient(180deg, #3c2e24 0%, #271d16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 7px 9px;
      display: flex;
      align-items: center;
      gap: 9px;
      min-width: 0;
    }
    .rm-achievement-card.unlocked {
      border-color: #fbbf24;
    }
    .rm-achievement-card.locked {
      opacity: 0.78;
    }
    @keyframes rmBossPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.24); }
    }
    .rm-skin-thumb {
      width: 40px;
      height: 40px;
      object-fit: contain;
      flex-shrink: 0;
      filter: drop-shadow(0 2px 2px rgba(0,0,0,0.6));
    }
    @keyframes rmLogoFloat {
      0%, 100% { transform: translateY(-4px); }
      50% { transform: translateY(4px); }
    }
    .rm-play-btn {
      min-width: 210px;
      min-height: 58px;
      font-size: 22px;
      letter-spacing: 1px;
      border-radius: 16px;
      animation: rmPlayPulse 2s ease-in-out infinite;
    }
    @keyframes rmPlayPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.04); }
    }
    @media (max-width: 430px) {
      .rm-pill {
        padding: 4px 8px;
        font-size: 11px;
        max-width: 39vw;
      }
      .rm-arcade-console .rm-btn {
        min-height: 38px;
        padding: 6px 8px;
        font-size: 11px;
      }
      .rm-icon-socket {
        width: 40px;
        height: 40px;
      }
      .rm-buy-btn {
        min-width: 68px;
        min-height: 38px;
        padding: 5px 7px;
        font-size: 11px;
      }
      .rm-boss-track {
        width: 62px;
      }
    }
  `,document.head.appendChild(m)}class wi{constructor(e){d(this,"nextEntityId",1);d(this,"generatedChunks",new Set);d(this,"rng");d(this,"options");d(this,"spawnedBossGates",new Set);this.options=e,this.rng=new $e(e.seed??1380533071)}updateOptions(e){Object.assign(this.options,e)}reset(e){this.nextEntityId=1,this.generatedChunks.clear(),this.spawnedBossGates.clear(),this.options=e,this.rng=new $e(e.seed??1380533071)}ensureChunksUpToRow(e,t){const s=Math.floor(e/g.CHUNK_ROWS);for(let i=0;i<=s;i++)this.generatedChunks.has(i)||(this.generatedChunks.add(i),this.generateChunk(i,t))}generateChunk(e,t){const s=e*g.CHUNK_ROWS,i=s+g.CHUNK_ROWS-1,{tntChance:a,bumperChance:n}=Ut(this.options.luckLevel),c=e===0?3:s;for(let o=c;o<=i;o++){const l=this.options.baseRowOffset+o,r=l*g.METERS_PER_ROW,h=this.getBiomeForRow(l),y=this.options.unlockedBiomeIndex,p=I[y+1],u=p?p.startDepthM:y===U.FINAL_BIOME_INDEX?U.FINAL_GATE_DEPTH_M:null;if(u!==null&&r>=u&&r<u+g.METERS_PER_ROW&&!this.spawnedBossGates.has(y)){this.spawnedBossGates.add(y),this.spawnBossGate(o,r,y,t);continue}if(e===0&&this.options.baseRowOffset===0&&o>=4&&o<=6){this.spawnFtueRow(o,r,h.index,t);continue}const _=(l-1)*g.METERS_PER_ROW;if(l>8&&Math.floor(r/Ne)>Math.floor(_/Ne)){const S=this.rng.int(2,g.GRID_COLS-4);t.push(this.createBlock("vault",S,o,r,h.index,2));for(let w=0;w<g.GRID_COLS;w++)w===S||w===S+1||this.rng.next()<.45&&t.push(this.createBlock("ore",w,o,r,h.index));continue}const v=Math.min(.72,.48+h.index*.04);let k=!1;for(let S=0;S<g.GRID_COLS;S++){if(this.rng.next()>v)continue;const w=this.rng.next();let A="strata";if(w<a)A="tnt";else if(w<a+n)A="bumper";else if(h.index>=1&&w<a+n+.06)A="splitter";else if(h.index>=2&&w<a+n+.11)A="laser";else if(h.index>=3&&w<a+n+.18)A="frost";else if(h.index>=4&&!k&&w<a+n+.22){k=!0,this.spawnPortalPair(S,o,r,h.index,t);continue}else w<a+n+.36?A="ore":r>=60&&w<a+n+.54?A="granite":A="strata";t.push(this.createBlock(A,S,o,r,h.index))}}}spawnFtueRow(e,t,s,i){e===4?(i.push(this.createBlock("strata",2,e,t,s)),i.push(this.createBlock("ore",3,e,t,s)),i.push(this.createBlock("ore",5,e,t,s)),i.push(this.createBlock("strata",6,e,t,s))):e===5?(i.push(this.createBlock("strata",2,e,t,s)),i.push(this.createBlock("ore",3,e,t,s)),i.push(this.createBlock("tnt",4,e,t,s)),i.push(this.createBlock("ore",5,e,t,s)),i.push(this.createBlock("strata",6,e,t,s))):e===6&&(i.push(this.createBlock("strata",1,e,t,s)),i.push(this.createBlock("strata",3,e,t,s)),i.push(this.createBlock("bumper",4,e,t,s)),i.push(this.createBlock("strata",5,e,t,s)),i.push(this.createBlock("strata",7,e,t,s)))}spawnBossGate(e,t,s,i){const a=[1,4,7],n=this.options.bossGateHpByBiome[s],c=Fe(t,"boss_core",this.options.ascensionTier??0);for(let o=0;o<g.GRID_COLS;o++){const l=a.indexOf(o);if(l!==-1){const r=n&&typeof n[l]=="number"?n[l]:c;if(r>0){const h=this.createBlock("boss_core",o,e,t,s);h.hp=r,h.maxHp=c,h.bossCoreIndex=l,i.push(h)}else i.push(this.createBlock("boss_armor",o,e,t,s))}else i.push(this.createBlock("boss_armor",o,e,t,s))}}spawnPortalPair(e,t,s,i,a){const n=t+16,c=Si(e+this.rng.int(-2,2)),o=(this.options.baseRowOffset+n)*g.METERS_PER_ROW,l=this.createBlock("portal_exit",c,n,o,i),r=this.createBlock("portal_entry",e,t,s,i);r.portalTargetId=l.id,a.push(r,l)}getBiomeForRow(e){const t=e*g.METERS_PER_ROW;for(let s=I.length-1;s>=0;s--)if(t>=I[s].startDepthM)return I[s];return I[0]}createBlock(e,t,s,i,a,n=1){const c=g.TILE_SIZE,o=c*n-4,l=c-4,r=t*c+2,h=s*c+2,y=Fe(i,e,this.options.ascensionTier??0);return{id:this.nextEntityId++,kind:e,col:t,row:s,colSpan:n,x:r,y:h,width:o,height:l,radius:e==="bumper"?22:e==="portal_entry"||e==="portal_exit"?20:0,hp:y,maxHp:y,depthMeters:i,biomeIndex:a,hitFlashTimer:0,hitsRemaining:e==="bumper"?g.BUMPER_MAX_HITS:void 0,alive:!0}}}function Si(m){return Math.max(0,Math.min(g.GRID_COLS-1,m))}const Ce=96;class Ti{constructor(){d(this,"canvas");d(this,"uiRoot");d(this,"adShield");d(this,"saveManager",new Ns);d(this,"save",Se());d(this,"stateMachine",new $t);d(this,"viewport");d(this,"renderer");d(this,"physics",new ss);d(this,"particles",new ns);d(this,"floatingText",new is);d(this,"juice",new as);d(this,"economy",new Fs);d(this,"progression",new $s);d(this,"retention",new Gs);d(this,"skins",new qs);d(this,"monetization",new Vs);d(this,"audio",new Tt(!1));d(this,"hud");d(this,"ftue");d(this,"shop");d(this,"summary");d(this,"victoryModal");d(this,"achievementsModal");d(this,"retentionModals");d(this,"settingsModal");d(this,"titleOverlay");d(this,"input");d(this,"loop");d(this,"generator");d(this,"entities",[]);d(this,"orbs",[]);d(this,"coins",[]);d(this,"coinCursor",0);d(this,"cameraY",0);d(this,"aimAngleRad",null);d(this,"trajectoryDots",[]);d(this,"trajectoryImpact",null);d(this,"trajectorySecondImpact",null);d(this,"trajectoryBounceIdx",14);d(this,"aimFeedback",null);d(this,"pendingVolleyOrbs",0);d(this,"volleyTimerS",0);d(this,"volleyAngleRad",Math.PI/2);d(this,"isOverdriveRun",!1);d(this,"runCoins",0);d(this,"runMaxDepthM",0);d(this,"runStartBestDepthM",0);d(this,"runElapsedS",0);d(this,"isFullShaftRun",!0);d(this,"runBlocksSmashed",0);d(this,"runMaxCombo",0);d(this,"runTntCount",0);d(this,"clearedBiome6ThisRun",!1);d(this,"victorySlowMoTimer",0);d(this,"pendingVictoryTier",null);d(this,"hasStartedGameplayOnce",!1);d(this,"pausedFromState",null);d(this,"bossActiveForAudio",!1);d(this,"pendingBiomeUnlock",null);d(this,"turretRecoil",0);d(this,"timeS",0);ki();const e=document.getElementById("game-canvas"),t=document.getElementById("ui-root");if(!e||!t)throw new Error("Missing #game-canvas or #ui-root");this.canvas=e,this.uiRoot=t,this.adShield=document.createElement("div"),this.adShield.style.cssText="position:absolute;inset:0;z-index:999;background:transparent;pointer-events:auto;display:none;",this.uiRoot.appendChild(this.adShield);for(let s=0;s<Ce;s++)this.coins.push({x:0,y:0,vx:0,vy:0,value:0,life:0,magnetized:!1,alive:!1});this.viewport=new qt(this.canvas),this.renderer=new Bs(this.canvas)}async boot(){T.loadingStart();const e=T.getServerTimeMs(),t=this.saveManager.loadLocal(e),s=await T.loadCloudData(),i=s?we(s,e):null;this.save=Us(t,i),f.setLocale(this.save.settings.localeOverride??T.getLocale()),this.audio.setUserMuted(this.save.settings.muted),this.audio.setSfxMuted(this.save.settings.sfxMuted),this.audio.setMusicVolume(this.save.settings.musicVolume??(this.save.settings.musicMuted?"off":"high")),this.save.settings.aimModeUserSet||(this.save.settings.aimMode=this.getDefaultAimModeForDevice()),this.retention.refreshDailyQuestsIfNeeded(this.save,e),this.retention.syncLoginStreakState(this.save,e),typeof document<"u"&&document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"?T.gameplayStop():this.hasStartedGameplayOnce&&(this.stateMachine.state==="AIMING"||this.stateMachine.state==="RUNNING")&&T.gameplayStart()}),T.setAdLifecycleCallbacks({onBeforeAd:()=>{this.stateMachine.pauseForAd(),this.audio.pauseForAd(),this.input.setLocked(!0),this.adShield.style.display="block"},onAfterAd:()=>{this.adShield.style.display="none",this.audio.resumeFromAd(),this.input.setLocked(!1),this.stateMachine.resumeFromAd(),this.hasStartedGameplayOnce&&(this.stateMachine.state==="AIMING"||this.stateMachine.state==="RUNNING")&&T.gameplayStart(),this.loop.resetAccumulator()}}),this.setupUI(),this.setupInput(),this.setupPhysicsEvents(),await this.renderer.preloadAssets(),this.generator=new wi({baseRowOffset:this.progression.getBaseRowOffset(this.save),luckLevel:this.save.upgrades.luck,bossGateHpByBiome:this.save.bossGateHpByBiome,unlockedBiomeIndex:this.save.unlockedBiomeIndex,ascensionTier:this.save.ascensionTier}),this.resetShaft(),this.loop=new Ft({onFixedUpdate:n=>this.fixedUpdate(n),onRender:(n,c)=>this.render(c),onVisibilityBlur:()=>{this.input?.setLocked(!1)}}),this.stateMachine.transition("TITLE"),this.showTitleScreen(),T.loadingStop(),this.loop.start();const a=this.retention.calculateOfflineEarnings(this.save,e);a>0&&this.retentionModals.showOfflineModal(a,async n=>{let c=a;if(n){const o=await this.monetization.showRewarded("rv_offline_double");o.rewarded?c*=2:this.showAdFailureToast(o.reason)}this.save.coins+=c,this.save.totalCoinsEarned+=c,this.persistSave()})}setupUI(){this.ftue=new pi(this.uiRoot),this.ftue.setVisible(!1),this.shop=new vi(this.uiRoot),this.summary=new yi(this.uiRoot),this.victoryModal=new hi(this.uiRoot),this.achievementsModal=new di(this.uiRoot),this.retentionModals=new gi(this.uiRoot),this.settingsModal=new _i(this.uiRoot),this.titleOverlay=new xi(this.uiRoot),this.hud=new fi(this.uiRoot,{onToggleMute:()=>{this.save.settings.muted=this.audio.toggleMute(),this.persistSave()},onTogglePause:()=>this.togglePause(),onToggleSpeed:()=>{const e=this.loop.getSpeedMultiplier()>1?1:2;this.loop.setSpeedMultiplier(e)},onRecall:()=>{for(const e of this.orbs)e.alive=!1;this.pendingVolleyOrbs=0},onOpenShop:()=>this.openShop(),onOpenAchievements:()=>this.openAchievements(!1),onOpenQuests:()=>{T.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showDailyQuests(this.save,this.retention,e=>{this.retention.claimQuest(this.save,e)>0&&(this.audio.playUpgrade(),this.persistSave(),this.retentionModals.hide(),this.resumeToAiming())},()=>{this.retention.claimMegaChest(this.save)&&(this.audio.playUpgrade(),this.persistSave(),this.retentionModals.hide(),this.resumeToAiming())},()=>this.resumeToAiming())},onOpenDailyLogin:()=>{T.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showDailyLogin(this.save,()=>{this.retention.claimDailyLoginReward(this.save,T.getServerTimeMs())&&(this.audio.playUpgrade(),this.persistSave())},()=>this.resumeToAiming())},onOpenElevator:()=>{T.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showElevator(this.save,e=>{this.progression.selectBiome(this.save,e)&&(this.persistSave(),this.resetShaft())},()=>this.resumeToAiming())},onTriggerOverdriveAd:async()=>{const e=await this.monetization.showRewarded("rv_overdrive_trial");e.rewarded?(this.monetization.markOverdriveOffered(this.save.runsCompleted),this.save.overdrivePasses+=1,this.persistSave(),this.hud.showToast("Super-Orb Armed!")):this.showAdFailureToast(e.reason)}}),new ui(this.uiRoot,{getSave:()=>this.save,onAddCoins:e=>{this.save.coins+=e,this.save.totalCoinsEarned+=e,this.persistSave()},onUnlockAllBiomes:()=>{this.save.unlockedBiomeIndex=5,this.persistSave()},onSimulateOneShotClear:()=>this.simulateFinalGateClear(!0),onSimulateElevatorClear:()=>this.simulateFinalGateClear(!1),onResetSave:()=>{this.save=Se(),this.persistSave(),this.resetShaft(),this.ftue.setVisible(!0)}})}setupInput(){this.input=new Vt(this.canvas,{canAim:()=>this.stateMachine.state==="AIMING",getAimMode:()=>this.save.settings.aimMode,getLauncherPos:()=>({x:g.SHAFT_WIDTH*.5,y:g.LAUNCHER_Y}),clientToWorld:(e,t)=>this.viewport.clientToWorld(e,t,this.cameraY),onAimStart:()=>{this.audio.unlock(),this.hasStartedGameplayOnce||(this.hasStartedGameplayOnce=!0,T.gameplayStart())},onAimUpdate:(e,t,s)=>{if(this.aimFeedback=s??null,t||e===null){this.aimAngleRad=null,this.trajectoryDots=[],this.trajectoryImpact=null,this.trajectorySecondImpact=null,this.trajectoryBounceIdx=g.TRAJECTORY_DOTS;return}this.aimAngleRad=e;const i=this.economy.getEffectiveOrbRadius(this.save),a=Be(g.SHAFT_WIDTH*.5,g.LAUNCHER_Y,e),n=this.physics.computeTrajectoryPreview(a.x,a.y,e,i,this.entities);this.trajectoryDots=n.dots,this.trajectoryImpact=n.impactPoint,this.trajectorySecondImpact=n.secondImpactPoint,this.trajectoryBounceIdx=n.bounceStartIdx},onLaunch:e=>{this.save.ftueDone||(this.save.ftueDone=!0,this.ftue.setVisible(!1)),this.launchVolley(e)},onQuickRelaunch:()=>{this.stateMachine.state==="RUN_SUMMARY"&&(this.summary.hide(),this.prepareNextRun())},onToggleMute:()=>{this.save.settings.muted=this.audio.toggleMute(),this.persistSave()},onTogglePause:()=>this.togglePause(),onBuyUpgradeSlot:e=>{if(this.stateMachine.state!=="SHOP")return;const t=te[e];t&&this.economy.buyUpgrade(this.save,t.id)&&(this.audio.playUpgrade(),this.persistSave())}})}spawnCoinDrop(e,t,s){const i=this.coins[this.coinCursor];this.coinCursor=(this.coinCursor+1)%Ce,i.x=e,i.y=t,i.vx=(Math.random()-.5)*140,i.vy=-140-Math.random()*80,i.value=s,i.life=.7,i.magnetized=!0,i.alive=!0}setupPhysicsEvents(){this.physics.setEvents({onWallHit:(e,t,s)=>{this.audio.playWallHit(Math.hypot(e.vx,e.vy)),this.particles.emitBurst(t,s,4,"#38bdf8",50,140,3,.25)},onBlockHit:(e,t,s,i)=>{const a=t.x+t.width*.5,n=t.y+t.height*.5;this.audio.playHit(e.comboCount,i,t.kind==="granite"||t.kind==="boss_armor",Math.hypot(e.vx,e.vy)),this.particles.emitBurst(a,n,i?8:5,"#e2e8f0",70,200,3.5,.3),this.juice.triggerShake(i?3.5:1.8),i&&this.floatingText.spawn(a,n-12,"CLEAVE!","#38bdf8",1.05),e.comboCount>this.runMaxCombo&&(this.runMaxCombo=e.comboCount),e.comboCount>this.save.stats.maxBounceCombo&&(this.save.stats.maxBounceCombo=e.comboCount)},onBlockDestroyed:(e,t,s,i)=>{const a=e.x+e.width*.5,n=e.y+e.height*.5;this.runCoins+=t,this.runBlocksSmashed+=1,this.save.coins+=t,this.save.totalCoinsEarned+=t,this.save.stats.blocksDestroyed+=1,this.retention.recordQuestProgress(this.save,"blocksDestroyed",1),s||this.audio.playCrunch(e.kind==="granite"),s&&(this.runTntCount+=1,this.save.stats.tntDetonated+=1,this.retention.recordQuestProgress(this.save,"tntDetonated",1)),i&&(this.save.stats.vaultsBroken+=1,this.save.shards+=1,this.retention.recordQuestProgress(this.save,"vaultsBroken",1),this.audio.playFanfare(),this.juice.triggerHitStop(.04),this.floatingText.spawn(a,n-18,"+1 SHARD!","#e879f9",1.25),T.happytime()),t>0&&(this.audio.playCoin(),this.floatingText.spawn(a,n,`+${O(t)}`,"#fbbf24",1),this.spawnCoinDrop(a,n,t))},onTntExplode:(e,t,s)=>{this.audio.playExplosion(),this.runTntCount>=2&&this.audio.duck(500),this.juice.triggerHitStop(.035),this.juice.triggerShake(7.5),this.juice.triggerVignette(.35),this.juice.addShockwave(e,t,s,"#fb923c"),this.particles.emitBurst(e,t,22,"#fb923c",120,380,5,.45)},onBumperHit:(e,t,s)=>{const i=t.x+t.width*.5,a=t.y+t.height*.5;this.audio.playBumper(e.comboCount),this.save.stats.bumpersHit+=1,this.retention.recordQuestProgress(this.save,"bumpersHit",1),this.runCoins+=s,this.save.coins+=s,this.save.totalCoinsEarned+=s,this.floatingText.spawn(i,a-10,"+2 BOUNCE","#22d3ee",1.1),this.particles.emitBurst(i,a,8,"#e879f9",80,220,4,.3)},onLaserFire:e=>{this.audio.playExplosion(),this.juice.addLaserBeam(e,"#fef08a"),this.juice.triggerShake(4.5)},onPortalWarp:(e,t,s)=>{this.audio.playBumper(6),this.particles.emitBurst(t.x+28,t.y+28,10,"#a3e635",60,180,4,.35),this.particles.emitBurst(s.x+28,s.y+28,10,"#f43f5e",60,180,4,.35),this.floatingText.spawn(s.x+28,s.y,"+2 WARP!","#a3e635",1.15)},onBossCoreDamaged:(e,t,s)=>{this.progression.recordBossCoreDamage(this.save,e,t,s)},onBossGateBroken:e=>{if(e>=U.FINAL_BIOME_INDEX){this.clearedBiome6ThisRun=!0;const a=this.progression.completeFinalGateClear(this.save,this.isFullShaftRun,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,timestamp:T.getServerTimeMs()});if(a.ascended){this.audio.playVictoryFanfare(),this.juice.triggerHitStop(.06),this.juice.triggerShake(10),T.happytime();const n=g.SHAFT_WIDTH*.5,c=this.cameraY+240;this.particles.emitBurst(n,c,50,"#fde047",120,440,6,1.3),this.particles.emitBurst(n-70,c-30,40,"#f59e0b",110,400,5.5,1.25),this.particles.emitBurst(n+70,c-30,40,"#fffbeb",110,400,5,1.2),this.particles.emitBurst(n,c-60,25,"#38bdf8",90,360,5,1.15),this.pendingVictoryTier=a.newTier,this.victorySlowMoTimer=.45}else this.audio.playFanfare(),this.juice.triggerHitStop(.05),this.juice.triggerShake(8),T.happytime(),this.hud.showToast(f.t("elevator_clear_title"));this.persistSave();return}this.audio.playFanfare(),this.juice.triggerHitStop(.05),this.juice.triggerShake(8),T.happytime();const t=this.progression.unlockNextBiome(this.save,e);this.generator.updateOptions({unlockedBiomeIndex:this.save.unlockedBiomeIndex});const i=this.skins.checkAndUnlockEligibleSkins(this.save).map(a=>{const n=this.skins.getEquippedSkin({...this.save,equippedSkin:a});return f.t(n.nameKey)});t&&(this.pendingBiomeUnlock={biomeIndex:this.save.unlockedBiomeIndex,unlockedSkinNames:i},this.hud.showToast(f.t("biome_unlocked_title"))),this.persistSave()}})}resetShaft(){this.entities=[],this.orbs.length=0;for(let e=0;e<Ce;e++)this.coins[e].alive=!1;this.cameraY=0,this.particles.clear(),this.floatingText.clear(),this.juice.clear(),this.generator.reset({baseRowOffset:this.progression.getBaseRowOffset(this.save),luckLevel:this.save.upgrades.luck,bossGateHpByBiome:this.save.bossGateHpByBiome,unlockedBiomeIndex:this.save.unlockedBiomeIndex,ascensionTier:this.save.ascensionTier}),this.generator.ensureChunksUpToRow(24,this.entities)}launchVolley(e){this.audio.playLaunch(),this.aimFeedback=null,this.aimAngleRad=null,this.trajectoryDots=[],this.trajectoryImpact=null,this.trajectorySecondImpact=null,this.stateMachine.transition("RUNNING"),this.loop.setSpeedMultiplier(1),this.runCoins=0,this.runStartBestDepthM=this.save.maxDepthMeters;const t=this.progression.getSelectedBiome(this.save).startDepthM;this.runMaxDepthM=t,this.runElapsedS=0,this.isFullShaftRun=t===0,this.runBlocksSmashed=0,this.runMaxCombo=0,this.runTntCount=0,this.clearedBiome6ThisRun=!1,this.victorySlowMoTimer=0,this.pendingVictoryTier=null,this.save.overdrivePasses>0?(this.save.overdrivePasses-=1,this.isOverdriveRun=!0):this.isOverdriveRun=!1;const s=this.economy.getEffectiveMultiOrbCount(this.save);this.volleyAngleRad=e,this.pendingVolleyOrbs=s-1,this.volleyTimerS=0,this.spawnLauncherOrb(e)}spawnLauncherOrb(e){this.turretRecoil=1;const t=this.economy.getEffectiveOrbRadius(this.save),s=this.isOverdriveRun?t*1.4:t,i=this.economy.getEffectiveMaxBounces(this.save),a=this.economy.getEffectiveDrillDamage(this.save)*(this.isOverdriveRun?1.5:1),n=Be(g.SHAFT_WIDTH*.5,g.LAUNCHER_Y,e);this.particles.emitBurst(n.x,n.y,7,"#fde047",100,260,3.6,.22);const c=this.physics.createOrb(n.x,n.y,e,s,i,a,!1,this.isOverdriveRun);this.orbs.push(c)}fixedUpdate(e){this.monetization.updateSessionTime(e),this.timeS+=e,this.turretRecoil>0&&(this.turretRecoil=Math.max(0,this.turretRecoil-e*8));const s=this.progression.getSelectedBiome(this.save).startDepthM+this.cameraY/g.TILE_SIZE*g.METERS_PER_ROW,i=Ie.getBiomeAtDepth(s);if(this.audio.updateMusicState(i.index,this.stateMachine.state,this.bossActiveForAudio),this.stateMachine.state!=="RUNNING")return;if(this.runElapsedS+=e,this.juice.consumeHitStop(e)){this.juice.update(e);return}let a=e;this.victorySlowMoTimer>0&&(this.victorySlowMoTimer=Math.max(0,this.victorySlowMoTimer-e),a=e*.3),this.pendingVolleyOrbs>0&&(this.volleyTimerS+=a,this.volleyTimerS>=g.MULTI_ORB_INTERVAL_S&&(this.volleyTimerS-=g.MULTI_ORB_INTERVAL_S,this.pendingVolleyOrbs--,this.spawnLauncherOrb(this.volleyAngleRad))),this.physics.step(a,this.orbs,this.entities,this.save.upgrades.orevalue,this.save.upgrades.orbsize,this.save.prestigeLevel,this.save.ascensionTier);let n=0,c=!1;for(const r of this.orbs)r.alive&&(c=!0,r.y>n&&(n=r.y));if(c){const r=Math.max(0,n-g.CAMERA_LOOKAHEAD_Y);this.cameraY+=(r-this.cameraY)*Math.min(1,e*6);const h=Math.ceil((this.cameraY+1200)/g.TILE_SIZE);this.generator.ensureChunksUpToRow(h,this.entities);const p=this.progression.getSelectedBiome(this.save).startDepthM+n/g.TILE_SIZE*g.METERS_PER_ROW;p>this.runMaxDepthM&&(this.runMaxDepthM=p),p>this.save.maxDepthMeters&&(this.save.maxDepthMeters=p)}const o=56,l=this.cameraY+26;for(let r=0;r<this.coins.length;r++){const h=this.coins[r];if(h.alive){if(h.life-=e,h.life<=0){h.alive=!1;continue}if(h.magnetized&&h.life<=.48){const y=o-h.x,p=l-h.y,u=Math.hypot(y,p);if(u<22){h.alive=!1,this.particles.emitBurst(h.x,h.y,2,"#fde047",20,60,2.5,.16);continue}const _=Math.min(1,e*16),b=y/u*1150,v=p/u*1150;h.vx+=(b-h.vx)*_,h.vy+=(v-h.vy)*_}else h.vy+=520*e;h.x+=h.vx*e,h.y+=h.vy*e}}this.particles.update(a),this.floatingText.update(a),this.juice.update(a),(this.pendingVictoryTier!==null&&this.victorySlowMoTimer<=0||!c&&this.pendingVolleyOrbs<=0&&this.victorySlowMoTimer<=0)&&this.finishRun()}finishRun(){this.loop.setSpeedMultiplier(1),T.gameplayStop(),this.save.runsCompleted+=1,this.save.stats.runsCompleted+=1,this.retention.recordQuestProgress(this.save,"runsCompleted",1),this.save.recentRunEarnings.push(this.runCoins),this.save.recentRunEarnings.length>3&&this.save.recentRunEarnings.shift();const e=Math.max(.25,this.runElapsedS/60);if(this.save.recentRunCoinsPerMin=Math.max(40,Math.round(this.runCoins/e)),this.save.lastActiveTimestamp=T.getServerTimeMs(),this.progression.checkMasteryFeats(this.save,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,tntChainMax:this.runTntCount,maxDepthMeters:this.runMaxDepthM,isFullShaftRun:this.isFullShaftRun}),this.skins.checkAndUnlockEligibleSkins(this.save),this.persistSave(),this.pendingVictoryTier!==null){const c=this.pendingVictoryTier;this.pendingVictoryTier=null,this.stateMachine.transition("ASCENSION_VICTORY"),this.victoryModal.show({newTier:c,blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,coinsEarned:this.runCoins,onDescendNextTier:()=>{this.progression.selectBiome(this.save,0),this.persistSave(),this.resetShaft(),this.resumeToAiming()},onOpenUpgrades:()=>{this.openShop("upgrades",!1)},onDoubleVictoryCoins:async()=>{const o=await this.monetization.showRewarded("rv_double_run");return o.rewarded?(this.save.coins+=this.runCoins,this.save.totalCoinsEarned+=this.runCoins,this.persistSave(),!0):(this.showAdFailureToast(o.reason),!1)}});return}this.stateMachine.transition("RUN_SUMMARY");const t=this.entities.some(c=>c.alive&&(c.kind==="vault"||c.kind==="boss_core")&&c.hp/c.maxHp<=j.RV_EXTRA_LAUNCH_HP_THRESHOLD),s=this.monetization.canOfferDoubleRun(this.save,this.runCoins);s&&this.monetization.markDoubleRunOffered(this.save.runsCompleted);const i=te.filter(c=>this.economy.canAfford(this.save,c.id)).length,a=()=>{this.summary.show({coinsEarned:this.runCoins,maxDepthMeters:this.runMaxDepthM,isNewBest:this.runMaxDepthM>this.runStartBestDepthM&&this.runMaxDepthM>5,affordableUpgradeCount:i,showDoubleAd:s,showExtraLaunchAd:t,clearedBiome6ViaElevator:this.clearedBiome6ThisRun&&!this.isFullShaftRun,currentAscensionTier:this.save.ascensionTier,onRelaunch:()=>this.prepareNextRun(),onOpenShop:()=>this.openShop(),onStartZeroMeterRun:()=>{this.progression.selectBiome(this.save,0),this.persistSave(),this.resetShaft(),this.resumeToAiming()},onDoubleAd:async()=>{const c=await this.monetization.showRewarded("rv_double_run");c.rewarded?(this.save.coins+=this.runCoins,this.save.totalCoinsEarned+=this.runCoins,this.persistSave(),this.summary.hide(),this.prepareNextRun()):this.showAdFailureToast(c.reason)},onExtraLaunchAd:async()=>{const c=await this.monetization.showRewarded("rv_extra_launch");c.rewarded?(this.summary.hide(),this.cameraY=0,this.resumeToAiming()):this.showAdFailureToast(c.reason)}})},n=this.pendingBiomeUnlock;if(this.pendingBiomeUnlock=null,n){const c=I[n.biomeIndex];if(c){this.retentionModals.showBiomeUnlockModal(f.t(c.nameKey),c.coinMultiplier,n.unlockedSkinNames,a);return}}a()}async prepareNextRun(){this.monetization.canShowMidgameAd()&&(this.hud.showToast(f.t("short_break"),500),await new Promise(e=>setTimeout(e,j.PRE_AD_CUE_S*1e3)),await this.monetization.tryShowMidgameAd()),this.resetShaft(),this.resumeToAiming()}openShop(e="upgrades",t=!1){T.gameplayStop(),this.stateMachine.transition("SHOP");const s=this.monetization.canOfferFreeUpgrade(this.save.runsCompleted)?this.economy.getCheapestNearlyAffordableUpgrade(this.save,j.RV_FREE_UPGRADE_MIN_GAP,j.RV_FREE_UPGRADE_MAX_GAP):null,i=()=>{this.shop.render(this.save,this.economy,this.skins,this.progression,s,a)},a={onBuyUpgrade:n=>{this.economy.buyUpgrade(this.save,n)&&(this.audio.playUpgrade(),this.persistSave(),i())},onFreeUpgradeAd:async n=>{const c=await this.monetization.showRewarded("rv_free_upgrade");c.rewarded?(this.monetization.markFreeUpgradeOffered(this.save.runsCompleted),this.economy.grantFreeUpgrade(this.save,n),this.audio.playUpgrade(),this.persistSave(),i()):this.showAdFailureToast(c.reason)},onEquipSkin:n=>{this.skins.equipSkin(this.save,n)&&(this.audio.playClick(),this.persistSave(),i())},onUnlockSkinCoins:n=>{this.skins.unlockWithCoins(this.save,n)&&(this.audio.playUpgrade(),this.persistSave(),i())},onUnlockSkinAd:async n=>{const c=await this.monetization.showRewarded("rv_skin_progress");c.rewarded?(this.skins.addRvProgress(this.save,n),this.audio.playUpgrade(),this.persistSave(),i()):this.showAdFailureToast(c.reason)},onPrestige:()=>{this.progression.triggerPrestige(this.save)&&(this.audio.playUpgrade(),this.persistSave(),this.shop.close(),this.resetShaft(),this.stateMachine.transition("AIMING"))},onClose:()=>{this.resetShaft(),t?(this.stateMachine.transition("TITLE"),this.showTitleScreen()):this.resumeToAiming()}};this.shop.open(this.save,this.economy,this.skins,this.progression,s,a,e)}openAchievements(e){e||T.gameplayStop(),this.stateMachine.transition("SHOP"),this.achievementsModal.open(this.save,t=>{this.progression.claimMasteryFeat(this.save,t)>0&&(this.audio.playUpgrade(),this.persistSave())},()=>{e?(this.stateMachine.transition("TITLE"),this.showTitleScreen()):this.resumeToAiming()})}simulateFinalGateClear(e){this.titleOverlay.hideImmediate(),this.shop.close(),this.summary.hide(),this.victoryModal.hide(),this.achievementsModal.hide(),this.retentionModals.hide(),this.save.unlockedBiomeIndex=U.FINAL_BIOME_INDEX,this.progression.selectBiome(this.save,e?0:U.FINAL_BIOME_INDEX),this.isFullShaftRun=e,this.runMaxDepthM=U.FINAL_GATE_DEPTH_M,this.save.maxDepthMeters=Math.max(this.save.maxDepthMeters,this.runMaxDepthM),this.runBlocksSmashed=Math.max(this.runBlocksSmashed,145),this.runMaxCombo=Math.max(this.runMaxCombo,28),this.save.stats.maxBounceCombo=Math.max(this.save.stats.maxBounceCombo,this.runMaxCombo),this.runTntCount=Math.max(this.runTntCount,4);const t=Math.max(this.runCoins,2500);this.runCoins=t,this.save.coins+=t,this.save.totalCoinsEarned+=t;const{ascended:s,newTier:i}=this.progression.completeFinalGateClear(this.save,e,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,timestamp:T.getServerTimeMs()});this.clearedBiome6ThisRun=!0,this.victorySlowMoTimer=0,this.pendingVictoryTier=s?i:null,s&&(this.audio.playVictoryFanfare(),T.happytime()),this.orbs.length=0,this.pendingVolleyOrbs=0,this.finishRun()}showTitleScreen(){this.ftue.setVisible(!1),this.titleOverlay.show({logoUrl:this.renderer.getLogoEmblemUrl(),bestDepthMeters:this.save.maxDepthMeters,ascensionTier:this.save.ascensionTier,hasUnclaimedFeats:this.progression.hasUnclaimedFeats(this.save),muted:this.audio.isMuted(),callbacks:{onUserGesture:()=>{this.audio.unlock()},onPlay:()=>{this.audio.unlock(),this.stateMachine.transition("AIMING"),this.ftue.setVisible(!this.save.ftueDone),this.hasStartedGameplayOnce||(this.hasStartedGameplayOnce=!0),T.gameplayStart()},onToggleMute:()=>{this.audio.unlock(),this.save.settings.muted=this.audio.toggleMute(),this.persistSave(),this.showTitleScreen()},onOpenSettings:()=>{this.openSettings(!0)},onOpenSkins:()=>{this.titleOverlay.hideImmediate(),this.openShop("skins",!0)},onOpenAchievements:()=>{this.titleOverlay.hideImmediate(),this.openAchievements(!0)}}})}openSettings(e){this.settingsModal.open(this.save,f.getLocale(),{onToggleSfx:()=>{this.save.settings.sfxMuted=!this.save.settings.sfxMuted,this.audio.setSfxMuted(this.save.settings.sfxMuted),this.persistSave()},onToggleMusic:()=>{this.audio.unlock(),this.save.settings.musicMuted=!this.save.settings.musicMuted,this.audio.setMusicMuted(this.save.settings.musicMuted),this.save.settings.musicVolume=this.audio.getMusicVolume(),this.persistSave()},onSetMusicVolume:t=>{this.audio.unlock(),this.save.settings.musicVolume=t,this.save.settings.musicMuted=t==="off",this.audio.setMusicVolume(t),this.persistSave()},onToggleAimMode:()=>{this.save.settings.aimMode=this.save.settings.aimMode==="slingshot"?"direct":"slingshot",this.save.settings.aimModeUserSet=!0,this.persistSave()},onSelectLocale:t=>{this.save.settings.localeOverride=t,f.setLocale(t),this.hud.refreshLabels(),this.ftue.refreshText(),this.persistSave()},onConfirmReset:()=>{this.save=this.saveManager.resetProgress(T.getServerTimeMs());const t=JSON.stringify(this.save);T.saveCloudData(t),this.audio.setUserMuted(!1),this.audio.setSfxMuted(!1),this.audio.setMusicVolume("high"),this.save.settings.aimMode=this.getDefaultAimModeForDevice(),this.save.settings.aimModeUserSet=!1,f.setLocale(T.getLocale()),this.hud.refreshLabels(),this.ftue.refreshText(),this.returnToHome()},onClose:()=>{e?this.showTitleScreen():this.resumeToAiming()}})}returnToHome(){T.gameplayStop(),this.pausedFromState=null,this.orbs=[],this.pendingVolleyOrbs=0,this.resetShaft(),this.stateMachine.transition("TITLE"),this.showTitleScreen()}render(e){const t=this.progression.getSelectedBiome(this.save),s=t.startDepthM+this.cameraY/g.TILE_SIZE*g.METERS_PER_ROW,i=Ie.getBiomeAtDepth(s),a=this.orbs.reduce((C,R)=>R.alive?C+R.bouncesLeft:C,0),n=te.filter(C=>this.economy.canAfford(this.save,C.id)).length,c=this.save.dailyQuests.quests.some(C=>!C.claimed&&C.progress>=C.target),o=this.stateMachine.state==="RUNNING"?this.runMaxDepthM:t.startDepthM,l=t.startDepthM,r=Number.isFinite(t.endDepthM)?t.endDepthM:U.FINAL_GATE_DEPTH_M,h=Math.max(1,r-l),y=(o-l)/h*100,p=r-o<=15,u=Math.min(6,t.index+2),_=t.index>=U.FINAL_BIOME_INDEX?`${Math.floor(o)}m / ${U.FINAL_GATE_DEPTH_M}m (${f.t("boss_gate")})`:`${Math.floor(o)}m / ${Math.floor(r)}m to Biome ${u} Boss`,b=this.viewport.getLayout().cssHeight/this.viewport.getLayout().scale;let v=-1,k=0,S=0,w=0;for(let C=0;C<this.entities.length;C++){const R=this.entities[C];R.kind==="boss_core"&&R.biomeIndex===t.index&&(v===-1&&(v=R.row),R.row===v&&(w+=R.maxHp,R.alive&&(k++,S+=R.hp)))}const A=v*g.TILE_SIZE,$=v>=0&&k>0&&(S<w-.5||A>=this.cameraY-40&&A<=this.cameraY+b+60);this.bossActiveForAudio=p||$,this.hud.update({coins:this.save.coins,depthMeters:o,biomeName:f.t(i.nameKey),bouncesLeft:a,isTitle:this.stateMachine.state==="TITLE",isRunning:this.stateMachine.state==="RUNNING",isAiming:this.stateMachine.state==="AIMING",muted:this.audio.isMuted(),speedMult:this.loop.getSpeedMultiplier(),hasElevator:this.save.unlockedBiomeIndex>0,showOverdriveOffer:this.save.overdrivePasses===0&&this.monetization.canOfferOverdriveTrial(this.save.runsCompleted),hasClaimableLogin:!this.save.loginStreak.claimedToday,hasClaimableQuest:c,hasUnclaimedFeats:this.progression.hasUnclaimedFeats(this.save),affordableUpgradeCount:n,bossProgressText:_,bossProgressPct:y,bossNear:p,isFullShaftRun:(this.stateMachine.state==="RUNNING"?this.isFullShaftRun:t.startDepthM===0)&&this.stateMachine.state!=="TITLE",ascensionTier:this.save.ascensionTier,activeGate:$?{coresAlive:k,hp:S,maxHp:w}:null}),this.renderer.render(this.viewport.getLayout(),{cameraY:this.cameraY,baseDepthMeters:t.startDepthM,launcherX:g.SHAFT_WIDTH*.5,launcherY:g.LAUNCHER_Y,aimAngleRad:this.stateMachine.state==="AIMING"?this.aimAngleRad:null,isAimingState:this.stateMachine.state==="AIMING",loadedOrbRadius:this.economy.getEffectiveOrbRadius(this.save),turretRecoil:this.turretRecoil,trajectoryDots:this.trajectoryDots,trajectoryImpact:this.trajectoryImpact,trajectorySecondImpact:this.trajectorySecondImpact,trajectoryBounceIdx:this.trajectoryBounceIdx,aimFeedback:this.aimFeedback,orbs:this.orbs,entities:this.entities,coins:this.coins,skin:this.skins.getEquippedSkin(this.save),particles:this.particles,floatingText:this.floatingText,juice:this.juice,timeS:this.timeS+e})}getDefaultAimModeForDevice(){const e=T.getDeviceType();return e==="mobile"||e==="tablet"||typeof window<"u"&&typeof navigator<"u"&&navigator.maxTouchPoints>0&&window.innerWidth<900?"slingshot":"direct"}resumeToAiming(){this.stateMachine.transition("AIMING"),this.hasStartedGameplayOnce&&T.gameplayStart()}togglePause(){const e=this.stateMachine.state;if(e==="PAUSED"){this.retentionModals.hide();const t=this.pausedFromState??"AIMING";this.pausedFromState=null,this.stateMachine.transition(t),this.hasStartedGameplayOnce&&T.gameplayStart();return}e!=="AIMING"&&e!=="RUNNING"||(this.pausedFromState=e,this.stateMachine.transition("PAUSED"),T.gameplayStop(),this.retentionModals.showPauseModal(()=>this.togglePause(),()=>{this.pausedFromState=null,this.resetShaft(),this.resumeToAiming()},()=>{this.pausedFromState=null,this.openSettings(!1)},()=>this.returnToHome()))}showAdFailureToast(e){this.hud.showToast(e==="skipped"?f.t("ad_incomplete"):f.t("ad_unavailable"))}persistSave(){const e=this.saveManager.saveLocal(this.save);T.saveCloudData(e)}}const Mi=new Ti;Mi.boot();
