var xt=Object.defineProperty;var wt=(f,e,t)=>e in f?xt(f,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):f[e]=t;var c=(f,e,t)=>wt(f,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))s(i);new MutationObserver(i=>{for(const a of i)if(a.type==="childList")for(const n of a.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(i){const a={};return i.integrity&&(a.integrity=i.integrity),i.referrerPolicy&&(a.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?a.credentials="include":i.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function s(i){if(i.ep)return;i.ep=!0;const a=t(i);fetch(i.href,a)}})();function xe(f){return 440*Math.pow(2,(f-69)/12)}const St=typeof import.meta<"u"&&typeof import.meta.glob=="function"?Object.assign({}):{},Mt=25,Tt=.1,pe=[{name:"Sunlit Quarry",bpm:114,swingRatio:.12,timbre:"kalimba",cutoffChill:1900,cutoffAim:3e3,cutoffRun:4600,chords:[[60,64,67,72],[59,62,67,71],[57,60,64,67],[53,57,60,64]],bass:[36,null,null,36,48,null,43,null,36,null,40,null,43,null,40,null,43,null,null,43,50,null,47,null,43,null,38,null,43,null,47,null,45,null,null,45,52,null,48,null,45,null,40,null,45,null,48,null,41,null,null,41,48,null,45,null,43,null,null,43,47,null,43,null],lead:[72,null,76,null,79,null,76,null,74,null,72,null,67,null,null,null,71,null,74,null,79,null,74,null,76,null,74,null,71,null,null,null,72,null,76,null,81,null,79,null,76,null,72,null,69,null,null,null,77,null,76,null,74,null,72,null,74,null,76,null,74,null,null,null],ostinato:[48,55,60,55,48,55,64,55],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,0,1,0,1,0,1,1,1,0,1,0,1,0,1,1]},{name:"Crystal Cavern",bpm:118,swingRatio:.06,timbre:"crystal",cutoffChill:2100,cutoffAim:3300,cutoffRun:5e3,chords:[[59,64,67,71],[60,64,67,71],[59,62,67,71],[57,62,66,69]],bass:[40,null,null,40,47,null,40,null,40,null,43,null,47,null,40,null,36,null,null,36,43,null,36,null,36,null,40,null,43,null,36,null,43,null,null,43,50,null,43,null,43,null,47,null,50,null,43,null,38,null,null,38,45,null,38,null,38,null,42,null,45,null,47,null],lead:[76,null,79,null,83,null,79,null,78,null,76,null,71,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,71,null,null,null,74,null,79,null,83,null,79,null,78,null,74,null,71,null,null,null,74,null,78,null,81,null,78,null,76,null,74,null,71,null,null,null],ostinato:[52,59,64,59,52,59,67,59],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0]},{name:"Magma Core",bpm:122,swingRatio:.08,timbre:"analog",cutoffChill:1700,cutoffAim:2700,cutoffRun:4200,chords:[[57,62,65,69],[58,62,65,70],[60,64,67,72],[57,61,64,69]],bass:[38,38,null,38,45,null,38,null,38,38,null,38,41,null,45,null,34,34,null,34,41,null,34,null,34,34,null,34,38,null,41,null,36,36,null,36,43,null,36,null,36,36,null,36,40,null,43,null,33,33,null,33,40,null,33,null,33,null,40,null,45,null,40,null],lead:[74,null,74,76,77,null,74,null,72,null,69,null,74,null,null,null,70,null,74,null,77,null,74,null,72,null,70,null,69,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,67,null,null,null,69,null,73,null,76,null,73,null,76,null,74,null,73,null,null,null],ostinato:[50,57,62,57,50,57,65,57],kickMask:[1,0,0,1,0,0,1,0,1,0,0,0,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,1],hatMask:[1,0,1,1,1,0,1,0,1,0,1,1,1,0,1,0]},{name:"Frost Depths",bpm:108,swingRatio:.05,timbre:"felt",cutoffChill:1850,cutoffAim:2900,cutoffRun:4500,chords:[[57,60,64,69],[58,62,65,69],[55,58,62,65],[57,60,64,67]],bass:[38,null,null,45,50,null,null,null,38,null,null,45,48,null,null,null,34,null,null,41,46,null,null,null,34,null,null,41,45,null,null,null,43,null,null,50,46,null,null,null,43,null,null,46,50,null,null,null,36,null,null,43,48,null,null,null,36,null,null,40,43,null,null,null],lead:[74,null,76,null,77,null,81,null,79,null,77,null,76,null,null,null,74,null,70,null,74,null,77,null,76,null,74,null,72,null,null,null,70,null,74,null,79,null,77,null,74,null,70,null,67,null,null,null,72,null,76,null,79,null,76,null,74,null,72,null,69,null,null,null],ostinato:[50,57,62,57,50,57,64,57],kickMask:[1,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[0,0,1,0,0,0,1,0,0,0,1,0,1,0,1,0]},{name:"Warp Abyss",bpm:124,swingRatio:0,timbre:"synthwave",cutoffChill:1800,cutoffAim:3e3,cutoffRun:4800,chords:[[57,60,64,69],[53,57,60,65],[60,64,67,72],[59,62,67,71]],bass:[45,45,57,45,45,57,45,45,45,45,57,45,48,45,43,45,41,41,53,41,41,53,41,41,41,41,53,41,45,41,43,41,36,36,48,36,36,48,36,36,36,36,48,36,40,36,43,36,43,43,55,43,43,55,43,43,43,43,50,43,47,43,40,43],lead:[76,null,72,null,69,null,72,null,76,null,79,null,76,null,null,null,77,null,76,null,72,null,69,null,72,null,76,null,74,null,null,null,79,null,76,null,72,null,74,null,76,null,79,null,84,null,null,null,83,null,79,null,74,null,76,null,79,null,76,null,74,null,null,null],ostinato:[57,64,69,64,57,64,72,64],kickMask:[1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0],hatMask:[1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1]},{name:"Quantum Core",bpm:128,swingRatio:.04,timbre:"arcade",cutoffChill:1950,cutoffAim:3200,cutoffRun:5100,chords:[[55,58,62,67],[55,58,63,67],[58,62,65,70],[57,60,65,69]],bass:[43,null,43,55,43,null,50,null,43,null,43,55,46,null,50,null,39,null,39,51,39,null,46,null,39,null,39,51,43,null,46,null,46,null,46,58,46,null,53,null,46,null,46,58,50,null,53,null,41,null,41,53,41,null,48,null,41,null,45,null,48,null,45,null],lead:[79,null,74,null,70,null,74,null,79,null,82,null,79,null,null,null,79,null,75,null,70,null,75,null,79,null,82,null,84,null,null,null,82,null,79,null,77,null,74,null,77,null,79,null,82,null,null,null,81,null,79,null,77,null,74,null,77,null,76,null,74,null,null,null],ostinato:[55,62,67,62,55,62,70,62],kickMask:[1,0,0,1,0,0,1,0,1,0,0,1,0,0,1,0],snareMask:[0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,1],hatMask:[1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,1]}];function At(f){return f==="RUNNING"?"running":f==="AIMING"?"aiming":"chill"}class Et{constructor(){c(this,"ctx",null);c(this,"outputBus",null);c(this,"noiseBuffer",null);c(this,"rhythmDryBus",null);c(this,"harmonyBus",null);c(this,"melodyBus",null);c(this,"melodyFilter",null);c(this,"delayNode",null);c(this,"delayFeedback",null);c(this,"delayWet",null);c(this,"schedulerId",null);c(this,"running",!1);c(this,"pausedForAd",!1);c(this,"pausedByHidden",!1);c(this,"nextStepTime",0);c(this,"stepIndex",0);c(this,"activeBiomeIndex",0);c(this,"pendingBiomeIndex",0);c(this,"activeIntensity","chill");c(this,"pendingIntensity","chill");c(this,"bossActive",!1);c(this,"customBuffer",null);c(this,"customSource",null);c(this,"customLoadStarted",!1);c(this,"customTrackUrl",null);const e=Object.values(St);e.length>0&&(this.customTrackUrl=e[0])}attach(e,t,s){this.ctx===e&&this.outputBus===t||(this.ctx=e,this.outputBus=t,this.noiseBuffer=s,this.buildInternalRouting(),this.customTrackUrl&&!this.customLoadStarted&&!this.customBuffer&&(this.customLoadStarted=!0,this.loadCustomTrack(this.customTrackUrl)))}buildInternalRouting(){if(!this.ctx||!this.outputBus)return;const e=this.ctx.currentTime,t=this.ctx.createGain();t.gain.setValueAtTime(1,e),t.connect(this.outputBus);const s=this.ctx.createGain();s.gain.setValueAtTime(.85,e);const i=this.ctx.createBiquadFilter();i.type="lowpass",i.frequency.setValueAtTime(1250,e),i.Q.setValueAtTime(.5,e),s.connect(i).connect(this.outputBus);const a=this.ctx.createGain();a.gain.setValueAtTime(1,e);const n=this.ctx.createBiquadFilter();if(n.type="lowpass",n.frequency.setValueAtTime(pe[this.activeBiomeIndex].cutoffChill,e),n.Q.setValueAtTime(.6,e),a.connect(n),n.connect(this.outputBus),typeof this.ctx.createDelay=="function"){const r=this.ctx.createDelay(1),d=60/pe[this.activeBiomeIndex].bpm*.75;r.delayTime.setValueAtTime(d,e);const l=this.ctx.createGain();l.gain.setValueAtTime(.18,e);const o=this.ctx.createBiquadFilter();o.type="lowpass",o.frequency.setValueAtTime(1350,e);const h=this.ctx.createGain();h.gain.setValueAtTime(.14,e),n.connect(r),r.connect(o),o.connect(l),l.connect(r),o.connect(h),h.connect(this.outputBus),this.delayNode=r,this.delayFeedback=l,this.delayWet=h}this.rhythmDryBus=t,this.harmonyBus=s,this.melodyBus=a,this.melodyFilter=n}async loadCustomTrack(e){if(!this.ctx||typeof fetch!="function")return!1;try{const t=await fetch(e);if(!t.ok)return!1;const s=await t.arrayBuffer(),i=await this.ctx.decodeAudioData(s);return this.setCustomTrackBuffer(i),!0}catch{return!1}}setCustomTrackBuffer(e){this.customBuffer=e,this.stopCustomSource(),this.running&&!this.pausedForAd&&!this.pausedByHidden&&this.customBuffer&&this.startCustomSource()}setBiome(e){const t=Math.max(0,Math.min(pe.length-1,Math.floor(e)));t!==this.pendingBiomeIndex&&(this.pendingBiomeIndex=t,this.running||(this.activeBiomeIndex=t))}setGameState(e,t=!1){this.bossActive=t,this.setIntensity(At(e))}setIntensity(e){e===this.pendingIntensity&&e===this.activeIntensity||(this.pendingIntensity=e,this.running||(this.activeIntensity=e,this.syncMasterFilterCutoff()))}setBossActive(e){this.bossActive=e}getActiveBiomeIndex(){return this.activeBiomeIndex}getActiveIntensity(){return this.activeIntensity}isRunning(){return this.running&&this.schedulerId!==null}start(){if(!(!this.ctx||!this.outputBus)&&!(this.pausedForAd||this.pausedByHidden)){if(this.activeBiomeIndex=this.pendingBiomeIndex,this.activeIntensity=this.pendingIntensity,this.syncMasterFilterCutoff(),this.customBuffer){this.running=!0,this.startCustomSource();return}this.schedulerId===null&&(this.running=!0,this.nextStepTime=Math.max(this.ctx.currentTime+.04,this.nextStepTime),this.scheduler(),this.schedulerId=setInterval(()=>this.scheduler(),Mt))}}stop(){this.running=!1,this.schedulerId!==null&&(clearInterval(this.schedulerId),this.schedulerId=null),this.stopCustomSource(),this.nextStepTime=0,this.stepIndex=0}pauseForAd(){this.pausedForAd=!0,this.clearSchedulerOnly(),this.stopCustomSource()}resumeFromAd(e){this.pausedForAd=!1,e&&!this.pausedByHidden&&(this.nextStepTime=0,this.start())}setHiddenPaused(e,t){this.pausedByHidden=e,e?(this.clearSchedulerOnly(),this.stopCustomSource()):t&&!this.pausedForAd&&(this.nextStepTime=0,this.start())}clearSchedulerOnly(){this.running=!1,this.schedulerId!==null&&(clearInterval(this.schedulerId),this.schedulerId=null)}startCustomSource(){if(!this.ctx||!this.outputBus||!this.customBuffer||this.customSource)return;const e=this.ctx.createBufferSource();e.buffer=this.customBuffer,e.loop=!0,e.connect(this.outputBus),e.start(this.ctx.currentTime),this.customSource=e}stopCustomSource(){if(this.customSource){try{this.customSource.stop(),this.customSource.disconnect()}catch{}this.customSource=null}}syncMasterFilterCutoff(){if(!this.ctx||!this.melodyFilter)return;const e=pe[this.activeBiomeIndex],t=this.activeIntensity==="running"?e.cutoffRun:this.activeIntensity==="aiming"?e.cutoffAim:e.cutoffChill;if(this.melodyFilter.frequency.setTargetAtTime(t,this.ctx.currentTime,.2),this.delayWet&&this.delayFeedback&&this.delayWet.gain.setTargetAtTime(this.activeIntensity==="chill"?.16:.12,this.ctx.currentTime,.2),this.delayNode){const s=60/e.bpm*.75;this.delayNode.delayTime.setTargetAtTime(s,this.ctx.currentTime,.25)}}scheduler(){if(!this.ctx||!this.running||this.pausedForAd||this.pausedByHidden)return;const e=this.ctx.currentTime;this.nextStepTime<e-.15&&(this.nextStepTime=e+.03);let t=0;for(;this.nextStepTime<e+Tt&&t<8;){const s=pe[this.activeBiomeIndex],i=60/s.bpm/4,a=this.stepIndex%2===1?i*s.swingRatio:0;this.scheduleStep(this.stepIndex,this.nextStepTime+a),this.nextStepTime+=i,this.stepIndex=(this.stepIndex+1)%64,t++}}scheduleStep(e,t){if(!this.ctx||!this.rhythmDryBus||!this.harmonyBus||!this.melodyBus)return;e%16===0&&this.pendingIntensity!==this.activeIntensity&&(this.activeIntensity=this.pendingIntensity,this.syncMasterFilterCutoff()),e%8===0&&this.pendingBiomeIndex!==this.activeBiomeIndex&&(this.activeBiomeIndex=this.pendingBiomeIndex,this.syncMasterFilterCutoff());const s=pe[this.activeBiomeIndex],i=60/s.bpm/4,a=this.activeIntensity,n=e%16;if(n===0||n===6){const l=Math.floor(e/16)%s.chords.length,o=n===0?i*5.5:i*7.5,h=(n===0?1:.65)*(a==="chill"?.14:a==="aiming"?.12:.1);this.triggerRhodesChord(s.chords[l],t,o,h)}const r=s.bass[e];if(r!==null){const l=a==="chill"?.26:a==="aiming"?.3:.34;this.triggerBass(xe(r),t,i*1.65,l)}const d=s.lead[e];if(d!==null){const l=a==="chill"?.18:a==="aiming"?.22:.26,o=i*1.85;this.triggerLead(xe(d),s.timbre,t,o,l)}if(a==="aiming"?((n===0||n===8)&&this.triggerKick(t,.2),s.hatMask[n]&&this.triggerHat(t,n%2===0?.032:.018)):a==="running"&&(s.kickMask[n]&&this.triggerKick(t,.36),s.snareMask[n]&&this.triggerSnare(t,.13),s.hatMask[n]&&this.triggerHat(t,n%2===0?.042:.022)),this.bossActive&&a!=="chill"){const l=s.ostinato[e%s.ostinato.length];this.triggerOstinatoPulse(xe(l),t,i*.65,.09)}}triggerBass(e,t,s,i){if(!this.ctx||!this.rhythmDryBus)return;const a=this.ctx.createOscillator(),n=this.ctx.createOscillator(),r=this.ctx.createBiquadFilter(),d=this.ctx.createGain(),l=this.ctx.createGain();a.type="triangle",a.frequency.setValueAtTime(e,t),n.type="sine",n.frequency.setValueAtTime(e,t),l.gain.setValueAtTime(.5,t),r.type="lowpass",r.frequency.setValueAtTime(Math.min(720,e*4.5),t),r.frequency.exponentialRampToValueAtTime(Math.max(110,e*2.1),t+s),r.Q.setValueAtTime(.8,t),d.gain.setValueAtTime(1e-4,t),d.gain.linearRampToValueAtTime(i,t+.008),d.gain.exponentialRampToValueAtTime(8e-4,t+s),a.connect(r),n.connect(l).connect(r),r.connect(d).connect(this.rhythmDryBus),a.start(t),n.start(t),a.stop(t+s+.02),n.stop(t+s+.02)}triggerRhodesChord(e,t,s,i){if(!this.ctx||!this.harmonyBus)return;const a=this.ctx,n=a.createGain();n.gain.setValueAtTime(1e-4,t),n.gain.linearRampToValueAtTime(i,t+.018),n.gain.exponentialRampToValueAtTime(8e-4,t+s),n.connect(this.harmonyBus);const r=1/Math.max(1,e.length);for(let d=0;d<e.length;d++){const l=xe(e[d]),o=a.createOscillator(),h=a.createGain();o.type="sine",o.frequency.setValueAtTime(l*(d%2===0?1.001:.999),t),h.gain.setValueAtTime(r*.85,t),o.connect(h).connect(n),o.start(t),o.stop(t+s+.02);const m=a.createOscillator(),p=a.createGain();m.type="triangle",m.frequency.setValueAtTime(l*2,t),p.gain.setValueAtTime(r*.16,t),p.gain.exponentialRampToValueAtTime(8e-4,t+Math.min(.09,s*.4)),m.connect(p).connect(n),m.start(t),m.stop(t+Math.min(.1,s*.45))}}triggerLead(e,t,s,i,a){if(!this.ctx||!this.melodyBus)return;const n=this.ctx,r=this.melodyBus;if(t==="kalimba"||t==="felt"){const p=n.createOscillator(),u=n.createOscillator(),b=n.createGain(),_=n.createGain();p.type="sine",p.frequency.setValueAtTime(e,s),u.type="triangle",u.frequency.setValueAtTime(t==="kalimba"?e*2:e*.5,s),b.gain.setValueAtTime(t==="kalimba"?.16:.22,s),b.gain.exponentialRampToValueAtTime(.001,s+Math.min(.11,i*.6)),_.gain.setValueAtTime(1e-4,s),_.gain.linearRampToValueAtTime(a,s+.01),_.gain.exponentialRampToValueAtTime(8e-4,s+i),p.connect(_),u.connect(b).connect(_),_.connect(r),p.start(s),u.start(s),p.stop(s+i+.02),u.stop(s+i+.02);return}if(t==="crystal"){const p=n.createOscillator(),u=n.createOscillator(),b=n.createGain(),_=n.createGain();p.type="sine",p.frequency.setValueAtTime(e,s),u.type="sine",u.frequency.setValueAtTime(e*2,s),b.gain.setValueAtTime(.18,s),b.gain.exponentialRampToValueAtTime(.001,s+i*.65),_.gain.setValueAtTime(1e-4,s),_.gain.linearRampToValueAtTime(a*.9,s+.009),_.gain.exponentialRampToValueAtTime(8e-4,s+i*1.15),p.connect(_),u.connect(b).connect(_),_.connect(r),p.start(s),u.start(s),p.stop(s+i*1.2),u.stop(s+i*1.2);return}const d=n.createOscillator(),l=n.createOscillator(),o=n.createGain(),h=n.createBiquadFilter(),m=n.createGain();d.type="triangle",l.type="sawtooth",d.frequency.setValueAtTime(e,s),l.frequency.setValueAtTime(e*1.003,s),o.gain.setValueAtTime(t==="arcade"?.22:.28,s),h.type="lowpass",h.frequency.setValueAtTime(Math.min(2600,e*3.2),s),h.frequency.exponentialRampToValueAtTime(Math.max(420,e*1.35),s+i),h.Q.setValueAtTime(.75,s),m.gain.setValueAtTime(1e-4,s),m.gain.linearRampToValueAtTime(a*.92,s+.011),m.gain.exponentialRampToValueAtTime(8e-4,s+i),d.connect(h),l.connect(o).connect(h),h.connect(m).connect(r),d.start(s),l.start(s),d.stop(s+i+.02),l.stop(s+i+.02)}triggerKick(e,t){if(!this.ctx||!this.rhythmDryBus)return;const s=this.ctx.createOscillator(),i=this.ctx.createGain();s.type="sine",s.frequency.setValueAtTime(122,e),s.frequency.exponentialRampToValueAtTime(45,e+.06),i.gain.setValueAtTime(t,e),i.gain.exponentialRampToValueAtTime(.001,e+.13),s.connect(i).connect(this.rhythmDryBus),s.start(e),s.stop(e+.14)}triggerSnare(e,t){if(!this.ctx||!this.rhythmDryBus)return;if(this.noiseBuffer){const a=this.ctx.createBufferSource();a.buffer=this.noiseBuffer;const n=this.ctx.createBiquadFilter();n.type="bandpass",n.frequency.setValueAtTime(1650,e),n.Q.setValueAtTime(1.2,e);const r=this.ctx.createGain();r.gain.setValueAtTime(t*.75,e),r.gain.exponentialRampToValueAtTime(.001,e+.075),a.connect(n).connect(r).connect(this.rhythmDryBus),a.start(e),a.stop(e+.085)}const s=this.ctx.createOscillator(),i=this.ctx.createGain();s.type="triangle",s.frequency.setValueAtTime(195,e),s.frequency.exponentialRampToValueAtTime(115,e+.055),i.gain.setValueAtTime(t*.75,e),i.gain.exponentialRampToValueAtTime(.001,e+.065),s.connect(i).connect(this.rhythmDryBus),s.start(e),s.stop(e+.075)}triggerHat(e,t){if(!this.ctx||!this.rhythmDryBus||!this.noiseBuffer)return;const s=this.ctx.createBufferSource();s.buffer=this.noiseBuffer;const i=this.ctx.createBiquadFilter();i.type="bandpass",i.frequency.setValueAtTime(7600,e),i.Q.setValueAtTime(2,e);const a=this.ctx.createGain();a.gain.setValueAtTime(t,e),a.gain.exponentialRampToValueAtTime(.001,e+.024),s.connect(i).connect(a).connect(this.rhythmDryBus),s.start(e),s.stop(e+.03)}triggerOstinatoPulse(e,t,s,i){if(!this.ctx||!this.rhythmDryBus)return;const a=this.ctx.createOscillator(),n=this.ctx.createBiquadFilter(),r=this.ctx.createGain();a.type="triangle",a.frequency.setValueAtTime(e,t),n.type="lowpass",n.frequency.setValueAtTime(1200,t),r.gain.setValueAtTime(1e-4,t),r.gain.linearRampToValueAtTime(i,t+.005),r.gain.exponentialRampToValueAtTime(8e-4,t+s),a.connect(n).connect(r).connect(this.rhythmDryBus),a.start(t),a.stop(t+s+.015)}}const we=[523.25,587.33,659.25,783.99,880,1046.5,1174.66,1318.51,1567.98,1760],Ne=.75,Ct=.28,Rt=16,Bt=55;class It{constructor(e=!1,t=!1,s=!1,i){c(this,"ctx",null);c(this,"sfxGain",null);c(this,"musicDuckGain",null);c(this,"musicGain",null);c(this,"musicCompressor",null);c(this,"noiseBuffer",null);c(this,"music",new Et);c(this,"musicVolume","high");c(this,"lastNonOffVolume","high");c(this,"musicStartedOnce",!1);c(this,"userMuted",!1);c(this,"sfxMuted",!1);c(this,"musicMuted",!1);c(this,"systemMuted",!1);c(this,"adPaused",!1);c(this,"gestureUnlocked",!1);c(this,"resumeArmed",!1);c(this,"boundResumeHandler",null);c(this,"lastSoundTimes",new Map);c(this,"activeVoices",[]);this.userMuted=e,this.sfxMuted=t,this.musicMuted=s,this.musicVolume=i??(s?"off":"high"),this.musicVolume!=="off"?this.lastNonOffVolume=this.musicVolume:this.musicMuted=!0,typeof document<"u"&&document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"?(this.music.setHiddenPaused(!0,!1),this.setSystemMuted(!0)):(this.setSystemMuted(!1),this.music.setHiddenPaused(!1,this.canPlayMusic()),this.armIosResume())}),typeof window<"u"&&(window.addEventListener("focus",()=>{!this.userMuted&&!this.systemMuted&&!this.adPaused&&this.armIosResume()}),this.armIosResume())}getTargetMusicGain(){if(this.userMuted||this.musicMuted||this.systemMuted||this.adPaused||this.musicVolume==="off")return 0;const e=this.musicVolume==="low"?.5:1;return Ct*e}canPlayMusic(){return this.gestureUnlocked&&!this.userMuted&&!this.musicMuted&&!this.systemMuted&&!this.adPaused&&this.musicVolume!=="off"}unlock(){this.gestureUnlocked=!0;const e=this.getOrCreateContextFromGesture();e&&(e.state==="suspended"&&!this.userMuted&&!this.systemMuted&&!this.adPaused&&e.resume().catch(()=>{}),this.syncMusicPlayback(!0))}armIosResume(){if(typeof window>"u"||this.resumeArmed)return;this.resumeArmed=!0;const e=()=>{this.resumeArmed=!1,this.gestureUnlocked=!0;const t=this.getOrCreateContextFromGesture();t&&t.state==="suspended"&&!this.userMuted&&!this.systemMuted&&!this.adPaused&&t.resume().catch(()=>{}),this.syncMusicPlayback(!0),this.boundResumeHandler&&(window.removeEventListener("pointerdown",this.boundResumeHandler),window.removeEventListener("touchend",this.boundResumeHandler),window.removeEventListener("keydown",this.boundResumeHandler),this.boundResumeHandler=null)};this.boundResumeHandler=e,window.addEventListener("pointerdown",e),window.addEventListener("touchend",e),window.addEventListener("keydown",e)}getOrCreateContextFromGesture(){if(typeof window>"u")return null;if(!this.ctx){const e=window.AudioContext||window.webkitAudioContext;if(!e)return null;const t=new e;this.ctx=t;const s=t.createGain();s.gain.setValueAtTime(!this.userMuted&&!this.sfxMuted&&!this.systemMuted?Ne:0,t.currentTime),s.connect(t.destination),this.sfxGain=s;const i=t.createGain();i.gain.setValueAtTime(1,t.currentTime);const a=t.createGain();if(a.gain.setValueAtTime(0,t.currentTime),i.connect(a),typeof t.createDynamicsCompressor=="function"){const n=t.createDynamicsCompressor();n.threshold.setValueAtTime(-14,t.currentTime),n.knee.setValueAtTime(18,t.currentTime),n.ratio.setValueAtTime(3,t.currentTime),n.attack.setValueAtTime(.008,t.currentTime),n.release.setValueAtTime(.15,t.currentTime),a.connect(n),n.connect(t.destination),this.musicCompressor=n}else a.connect(t.destination);this.musicDuckGain=i,this.musicGain=a,this.noiseBuffer=this.createNoiseBuffer(t),this.music.attach(t,i,this.noiseBuffer),this.syncGainLevels(!1)}return this.ctx}createNoiseBuffer(e){const t=e.sampleRate,s=t,i=e.createBuffer(1,s,t),a=i.getChannelData(0);let n=0;for(let r=0;r<s;r++){const d=Math.random()*2-1;n=(n+.08*d)/1.08,a[r]=n*2.6+d*.4}return i}ensureSfxContext(){return this.userMuted||this.sfxMuted||this.systemMuted||this.adPaused||!this.gestureUnlocked||!this.ctx||!this.sfxGain?null:(this.ctx.state==="suspended"&&this.ctx.resume().catch(()=>{}),{ctx:this.ctx,out:this.sfxGain})}getNowMs(){return typeof performance<"u"&&typeof performance.now=="function"?performance.now():Date.now()}playSoundThrottled(e,t=Bt){const s=this.getNowMs(),i=this.lastSoundTimes.get(e)??-1/0;return s-i<t?!1:(this.lastSoundTimes.set(e,s),!0)}getActiveVoiceCount(){return this.activeVoices.length}createPannedDest(e,t,s){if(typeof s!="number"||typeof e.createStereoPanner!="function")return t;const i=Math.max(-.65,Math.min(.65,(s/540*2-1)*.65)),a=e.createStereoPanner();return a.pan.setValueAtTime(i,e.currentTime),a.connect(t),a}registerVoice(e,t,s,i=[]){for(;this.activeVoices.length>=Rt;){const r=this.activeVoices.shift();if(r)try{const d=e.currentTime;r.gainNode.gain.cancelScheduledValues(d),r.gainNode.gain.setValueAtTime(r.gainNode.gain.value,d),r.gainNode.gain.linearRampToValueAtTime(1e-4,d+.015),r.stopNode.stop(d+.02)}catch{}}const a={stopNode:t,gainNode:s,startedAt:e.currentTime};this.activeVoices.push(a);const n=t.onended;t.onended=()=>{n?.();const r=this.activeVoices.indexOf(a);r!==-1&&this.activeVoices.splice(r,1);try{t.disconnect(),s.disconnect();for(const d of i)d.disconnect()}catch{}}}pitchJitter(e=.06){return 1+(Math.random()*2-1)*e}syncGainLevels(e=!1){if(!this.ctx)return;const t=this.ctx.currentTime,s=!this.userMuted&&!this.systemMuted&&!this.adPaused;if(this.sfxGain){const i=s&&!this.sfxMuted?Ne:0;this.sfxGain.gain.setTargetAtTime(i,t,.02)}if(this.musicGain){const i=this.getTargetMusicGain();if(i<=0)this.musicGain.gain.setTargetAtTime(0,t,.015);else if(e){const a=this.musicGain.gain.value;this.musicGain.gain.cancelScheduledValues(t),this.musicGain.gain.setValueAtTime(Math.min(a,i),t),this.musicGain.gain.linearRampToValueAtTime(i,t+.6)}else this.musicGain.gain.setTargetAtTime(i,t,.08)}}syncMusicPlayback(e=!1){if(!this.ctx||!this.musicDuckGain){this.syncGainLevels(!1);return}if(this.music.attach(this.ctx,this.musicDuckGain,this.noiseBuffer),this.canPlayMusic()){const t=this.music.isRunning();t||this.music.start();const s=e||!this.musicStartedOnce||!t;this.musicStartedOnce=!0,this.syncGainLevels(s)}else this.syncGainLevels(!1),(this.userMuted||this.musicMuted||this.musicVolume==="off")&&this.music.stop()}duck(e=550){if(!this.ctx||!this.musicDuckGain||!this.canPlayMusic())return;const t=this.ctx.currentTime,s=Math.max(.05,e/1e3),i=this.musicDuckGain.gain;i.cancelScheduledValues(t),i.setValueAtTime(i.value,t),i.linearRampToValueAtTime(.45,t+.035),i.setValueAtTime(.45,t+s),i.linearRampToValueAtTime(1,t+s+.4)}updateMusicState(e,t,s=!1){this.music.setBiome(e),this.music.setGameState(t,s),this.canPlayMusic()&&!this.music.isRunning()&&this.syncMusicPlayback(!0)}updateAmbience(e,t,s){const i=s?"RUNNING":"TITLE";this.updateMusicState(t,i,!1)}pauseForAd(){if(this.adPaused=!0,this.music.pauseForAd(),this.ctx&&this.musicGain){const e=this.ctx.currentTime;this.musicGain.gain.cancelScheduledValues(e),this.musicGain.gain.setValueAtTime(this.musicGain.gain.value,e),this.musicGain.gain.linearRampToValueAtTime(0,e+.05)}this.setSystemMuted(!0)}resumeFromAd(){this.adPaused=!1,this.setSystemMuted(!1),this.music.resumeFromAd(this.canPlayMusic()),this.canPlayMusic()&&this.syncGainLevels(!0)}isMuted(){return this.userMuted}isSfxMuted(){return this.sfxMuted}isMusicMuted(){return this.musicMuted||this.musicVolume==="off"}getMusicVolume(){return this.musicVolume}getMusicIntensity(){return this.music.getActiveIntensity()}getMusicBiomeIndex(){return this.music.getActiveBiomeIndex()}isMusicPlaying(){return this.canPlayMusic()&&this.music.isRunning()}hasAudioRouting(){return!!(this.sfxGain&&this.musicGain&&this.musicDuckGain&&this.musicCompressor)}getMusicEngine(){return this.music}setSfxMuted(e){this.sfxMuted=e,this.syncGainLevels(!1)}setMusicVolume(e){this.musicVolume=e,e==="off"?this.musicMuted=!0:(this.lastNonOffVolume=e,this.musicMuted=!1),this.syncMusicPlayback(e!=="off")}setMusicMuted(e){this.musicMuted=e,e?this.musicVolume="off":this.musicVolume==="off"&&(this.musicVolume=this.lastNonOffVolume),this.syncMusicPlayback(!e)}setUserMuted(e){this.userMuted=e,this.syncSuspendState(),this.syncMusicPlayback(!e)}toggleMute(){return this.setUserMuted(!this.userMuted),this.userMuted}setSystemMuted(e){this.systemMuted=e,this.syncSuspendState(),this.syncGainLevels(!1),e||this.armIosResume()}syncSuspendState(){this.ctx&&(this.userMuted||this.systemMuted||this.adPaused?(this.music.setHiddenPaused(!0,!1),this.ctx.state==="running"&&this.ctx.suspend().catch(()=>{})):(this.ctx.state==="suspended"&&this.gestureUnlocked&&this.ctx.resume().catch(()=>{}),this.music.setHiddenPaused(!1,this.canPlayMusic())))}playLaunch(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();if(a.type="triangle",a.frequency.setValueAtTime(180,i),a.frequency.exponentialRampToValueAtTime(620,i+.13),n.gain.setValueAtTime(.18,i),n.gain.exponentialRampToValueAtTime(.001,i+.15),a.connect(n).connect(s),a.start(i),a.stop(i+.16),this.noiseBuffer){const r=t.createBufferSource();r.buffer=this.noiseBuffer;const d=t.createBiquadFilter();d.type="bandpass",d.frequency.setValueAtTime(1200,i);const l=t.createGain();l.gain.setValueAtTime(.08,i),l.gain.exponentialRampToValueAtTime(.001,i+.08),r.connect(d).connect(l).connect(s),r.start(i),r.stop(i+.09)}}playWallHit(e=900,t){const s=this.ensureSfxContext();if(!s||!this.playSoundThrottled("wallHit",50))return;const{ctx:i,out:a}=s,n=this.createPannedDest(i,a,t),r=i.currentTime,d=Math.max(.5,Math.min(1.5,e/900)),l=this.pitchJitter(.06),o=i.createOscillator(),h=i.createGain();o.type="triangle",o.frequency.setValueAtTime(1450*d*l,r),o.frequency.exponentialRampToValueAtTime(780*d*l,r+.045),h.gain.setValueAtTime(.055*d,r),h.gain.exponentialRampToValueAtTime(.001,r+.05),o.connect(h).connect(n),this.registerVoice(i,o,h,n!==a?[n]:[]),o.start(r),o.stop(r+.055)}playHit(e,t,s=!1,i=900,a){const n=this.ensureSfxContext();if(!n||!this.playSoundThrottled("blockHit",55))return;const{ctx:r,out:d}=n,l=this.createPannedDest(r,d,a),o=r.currentTime,h=Math.min(we.length-1,Math.max(0,e%we.length)),m=e>=we.length?1.5:1,p=we[h]*m*this.pitchJitter(.035),u=Math.max(.75,Math.min(1.3,i/900)),b=r.createOscillator(),_=r.createGain();if(b.type=t?"sawtooth":s?"square":"sine",b.frequency.setValueAtTime(t?p*1.25:p,o),b.frequency.exponentialRampToValueAtTime(p*.88,o+.085),_.gain.setValueAtTime((t?.14:.11)*u,o),_.gain.exponentialRampToValueAtTime(.001,o+.095),b.connect(_).connect(l),this.registerVoice(r,b,_,l!==d?[l]:[]),b.start(o),b.stop(o+.1),t){const v=r.createOscillator(),k=r.createGain();v.type="triangle",v.frequency.setValueAtTime(p*1.5,o),k.gain.setValueAtTime(.09,o),k.gain.exponentialRampToValueAtTime(.001,o+.11),v.connect(k).connect(l),this.registerVoice(r,v,k),v.start(o),v.stop(o+.12)}else if(s&&this.noiseBuffer){const v=r.createBufferSource();v.buffer=this.noiseBuffer;const k=r.createBiquadFilter();k.type="bandpass",k.frequency.setValueAtTime(620*this.pitchJitter(.06),o),k.Q.setValueAtTime(2.4,o);const R=r.createGain();R.gain.setValueAtTime(.14,o),R.gain.exponentialRampToValueAtTime(.001,o+.075),v.connect(k).connect(R).connect(l),this.registerVoice(r,v,R,[k]),v.start(o),v.stop(o+.08)}}playCrunch(e=!1,t){const s=this.ensureSfxContext();if(!s||!this.noiseBuffer||!this.playSoundThrottled("crunch",55))return;const{ctx:i,out:a}=s,n=this.createPannedDest(i,a,t),r=i.currentTime,d=i.createBufferSource();d.buffer=this.noiseBuffer;const l=i.createBiquadFilter();l.type="bandpass",l.frequency.setValueAtTime((e?850:520)*this.pitchJitter(.08),r),l.Q.setValueAtTime(e?2.8:1.4,r);const o=i.createGain();o.gain.setValueAtTime(e?.18:.11,r),o.gain.exponentialRampToValueAtTime(.001,r+.11),d.connect(l).connect(o).connect(n),this.registerVoice(i,d,o,n!==a?[l,n]:[l]),d.start(r),d.stop(r+.12)}playBumper(e=0,t){const s=this.ensureSfxContext();if(!s||!this.playSoundThrottled("bumper",50))return;const{ctx:i,out:a}=s,n=this.createPannedDest(i,a,t),r=i.currentTime,d=(1+Math.min(8,e)*.03)*this.pitchJitter(.04),l=i.createOscillator(),o=i.createGain();l.type="sine",l.frequency.setValueAtTime(740*d,r),l.frequency.exponentialRampToValueAtTime(1320*d,r+.11),o.gain.setValueAtTime(.16,r),o.gain.exponentialRampToValueAtTime(.001,r+.14),l.connect(o).connect(n),this.registerVoice(i,l,o,n!==a?[n]:[]),l.start(r),l.stop(r+.15);const h=i.createOscillator(),m=i.createGain();h.type="triangle",h.frequency.setValueAtTime(1480*d,r),m.gain.setValueAtTime(.08,r),m.gain.exponentialRampToValueAtTime(.001,r+.08),h.connect(m).connect(n),this.registerVoice(i,h,m),h.start(r),h.stop(r+.09)}playExplosion(e){const t=this.ensureSfxContext();if(!t||!this.playSoundThrottled("explosion",75))return;const{ctx:s,out:i}=t,a=this.createPannedDest(s,i,e),n=s.currentTime,r=s.createOscillator(),d=s.createGain();if(r.type="sine",r.frequency.setValueAtTime(115*this.pitchJitter(.06),n),r.frequency.exponentialRampToValueAtTime(26,n+.34),d.gain.setValueAtTime(.32,n),d.gain.exponentialRampToValueAtTime(.001,n+.36),r.connect(d).connect(a),this.registerVoice(s,r,d,a!==i?[a]:[]),r.start(n),r.stop(n+.37),this.noiseBuffer){const l=s.createBufferSource();l.buffer=this.noiseBuffer;const o=s.createBiquadFilter();o.type="lowpass",o.frequency.setValueAtTime(1150,n),o.frequency.exponentialRampToValueAtTime(110,n+.35);const h=s.createGain();h.gain.setValueAtTime(.28,n),h.gain.exponentialRampToValueAtTime(.001,n+.38),l.connect(o).connect(h).connect(a),this.registerVoice(s,l,h,[o]),l.start(n),l.stop(n+.39)}}playCoin(e){const t=this.ensureSfxContext();if(!t||!this.playSoundThrottled("coin",55))return;const{ctx:s,out:i}=t,a=this.createPannedDest(s,i,e),n=s.currentTime,r=this.pitchJitter(.04),d=s.createOscillator(),l=s.createGain();d.type="sine",d.frequency.setValueAtTime(1174.66*r,n),d.frequency.setValueAtTime(1567.98*r,n+.045),l.gain.setValueAtTime(.085,n),l.gain.exponentialRampToValueAtTime(.001,n+.13),d.connect(l).connect(a),this.registerVoice(s,d,l,a!==i?[a]:[]),d.start(n),d.stop(n+.14)}playUpgrade(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;[523.25,659.25,783.99,1046.5].forEach((n,r)=>{const d=i+r*.045,l=t.createOscillator(),o=t.createGain();l.type="triangle",l.frequency.setValueAtTime(n,d),o.gain.setValueAtTime(.12,d),o.gain.exponentialRampToValueAtTime(.001,d+.16),l.connect(o).connect(s),l.start(d),l.stop(d+.17)})}playFanfare(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;this.duck(550),[523.25,659.25,783.99,1046.5,1318.51].forEach((n,r)=>{const d=i+r*.06,l=t.createOscillator(),o=t.createGain();l.type=r>=3?"sine":"triangle",l.frequency.setValueAtTime(n,d),o.gain.setValueAtTime(.11,d),o.gain.exponentialRampToValueAtTime(.001,d+.36),l.connect(o).connect(s),l.start(d),l.stop(d+.38)})}playVictoryFanfare(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime;this.duck(1100);const a=[392,523.25,659.25,783.99];a.forEach((n,r)=>{const d=i+r*.11,l=r===a.length-1?.65:.24,o=t.createOscillator(),h=t.createBiquadFilter(),m=t.createGain();o.type="sawtooth",o.frequency.setValueAtTime(n,d),h.type="lowpass",h.frequency.setValueAtTime(1100,d),h.frequency.exponentialRampToValueAtTime(2200,d+.08),m.gain.setValueAtTime(.11,d),m.gain.exponentialRampToValueAtTime(.001,d+l),o.connect(h).connect(m).connect(s),o.start(d),o.stop(d+l+.02);const p=t.createOscillator(),u=t.createGain();p.type="sine",p.frequency.setValueAtTime(n*2,d+.02),u.gain.setValueAtTime(.09,d+.02),u.gain.exponentialRampToValueAtTime(.001,d+l+.18),p.connect(u).connect(s),p.start(d+.02),p.stop(d+l+.2)})}playClick(){const e=this.ensureSfxContext();if(!e)return;const{ctx:t,out:s}=e,i=t.currentTime,a=t.createOscillator(),n=t.createGain();a.type="sine",a.frequency.setValueAtTime(760,i),n.gain.setValueAtTime(.06,i),n.gain.exponentialRampToValueAtTime(.001,i+.04),a.connect(n).connect(s),a.start(i),a.stop(i+.045)}}const Q={MIDGAME_GRACE_PERIOD_S:180,MIDGAME_COOLDOWN_S:150,PRE_AD_CUE_S:.4,RV_DOUBLE_RUN_RATIO:1.2,RV_DOUBLE_RUN_COOLDOWN_RUNS:2,RV_EXTRA_LAUNCH_HP_THRESHOLD:.2,RV_FREE_UPGRADE_MIN_GAP:.1,RV_FREE_UPGRADE_MAX_GAP:.35,RV_FREE_UPGRADE_COOLDOWN_RUNS:4,RV_OVERDRIVE_COOLDOWN_RUNS:6},y={FIXED_DT:1/120,MAX_FRAME_DT:.05,SHAFT_WIDTH:540,GRID_COLS:9,TILE_SIZE:60,CHUNK_ROWS:12,METERS_PER_ROW:2.5,LAUNCHER_Y:72,MUZZLE_PIVOT_OFFSET_Y:-22,MUZZLE_LENGTH:58,LAUNCH_SPEED:920,GRAVITY:480,MIN_AIM_DEG:12,MAX_AIM_DEG:168,RESTITUTION_BLOCK:.96,RESTITUTION_BUMPER:1.25,MAX_ORB_SPEED:1450,MIN_ORB_SPEED:420,WALL_BOUNCE_COST:.5,BLOCK_BOUNCE_COST:1,CLEAVE_RATIO:2,BUMPER_MAX_HITS:5,BUMPER_BOUNCE_BONUS:2,MAX_ACTIVE_ORBS:24,TRAJECTORY_DOTS:14,CANCEL_DEADZONE_PX:16,HORIZONTAL_TRAP_WALL_HITS:4,HORIZONTAL_TRAP_DEFLECT_DEG:8,OVERHEAT_STALL_SECONDS:25,CAMERA_LOOKAHEAD_Y:160,MULTI_ORB_INTERVAL_S:.12,PORTAL_COOLDOWN_S:.4,PORTAL_BONUS_BOUNCES:2,PORTAL_SPEED_BOOST:1.3,BOSS_ARMOR_SPLASH_RATIO:.2},at={strata:{hpMult:1,coinMult:1},granite:{hpMult:3.2,coinMult:2},ore:{hpMult:1.5,coinMult:3},tnt:{hpMult:.5,coinMult:1.4},bumper:{hpMult:Number.POSITIVE_INFINITY,coinMult:.5},splitter:{hpMult:.5,coinMult:1},laser:{hpMult:1.1,coinMult:1.5},vault:{hpMult:5.5,coinMult:10},boss_core:{hpMult:18,coinMult:20},boss_armor:{hpMult:Number.POSITIVE_INFINITY,coinMult:.2},frost:{hpMult:1.4,coinMult:1.4},portal_entry:{hpMult:Number.POSITIVE_INFINITY,coinMult:0},portal_exit:{hpMult:Number.POSITIVE_INFINITY,coinMult:0}},Dt=2.5,Lt=3.5,Ot=2.5,Fe=50,Pt=1300,nt=.5,V={FINAL_BIOME_INDEX:5,FINAL_GATE_DEPTH_M:1550,HP_BASE:2,COIN_BASE:1.65,CAP_BONUS_PER_TIER:10,DAMAGE_BONUS_PER_TIER:.15},Be=[{tier:1,titleKey:"asc_tier_1_title",quoteKey:"asc_tier_1_quote"},{tier:2,titleKey:"asc_tier_2_title",quoteKey:"asc_tier_2_quote"},{tier:3,titleKey:"asc_tier_3_title",quoteKey:"asc_tier_3_quote"},{tier:4,titleKey:"asc_tier_4_title",quoteKey:"asc_tier_4_quote"}],rt=[{id:"chain_detonator",nameKey:"feat_chain_title",descKey:"feat_chain_desc",rewardCoins:1500},{id:"combo_master",nameKey:"feat_combo_title",descKey:"feat_combo_desc",rewardCoins:2500},{id:"heavy_investor",nameKey:"feat_investor_title",descKey:"feat_investor_desc",rewardCoins:5e3},{id:"zero_skip_purist",nameKey:"feat_zeroskip_title",descKey:"feat_zeroskip_desc",rewardCoins:1e4}];function ot(f){return Math.pow(V.HP_BASE,Math.max(0,f))}function lt(f){return Math.pow(V.COIN_BASE,Math.max(0,f))}function ct(f){return Math.max(0,f)*V.CAP_BONUS_PER_TIER}function dt(f){return 1+Math.max(0,f)*V.DAMAGE_BONUS_PER_TIER}function ht(f){const e=Math.max(0,Math.min(Be.length-1,f-1));return Be[e]}function re(f){const e=Math.max(1,Math.floor(f)),t=[[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];let s=e,i="";for(const[a,n]of t)for(;s>=a;)i+=n,s-=a;return i}const O=[{id:"quarry",index:0,nameKey:"biome_quarry",startDepthM:0,endDepthM:150,coinMultiplier:1,palette:{bgTop:"#161b2e",bgBottom:"#231c24",wall:"#3a2d28",strataFill:"#c96f44",strataStroke:"#f4a261",accent:"#38bdf8",glow:"#fbbf24"}},{id:"crystal",index:1,nameKey:"biome_crystal",startDepthM:150,endDepthM:350,coinMultiplier:2.7,palette:{bgTop:"#13112c",bgBottom:"#1e1642",wall:"#2b2459",strataFill:"#4338ca",strataStroke:"#22d3ee",accent:"#e879f9",glow:"#22d3ee"}},{id:"magma",index:2,nameKey:"biome_magma",startDepthM:350,endDepthM:600,coinMultiplier:7.2,palette:{bgTop:"#181214",bgBottom:"#2b130e",wall:"#331c17",strataFill:"#451a14",strataStroke:"#fb923c",accent:"#f97316",glow:"#fbbf24"}},{id:"subzero",index:3,nameKey:"biome_subzero",startDepthM:600,endDepthM:900,coinMultiplier:20,palette:{bgTop:"#0b192c",bgBottom:"#102a43",wall:"#1e3a5f",strataFill:"#1d4ed8",strataStroke:"#bae6fd",accent:"#7dd3fc",glow:"#e0f2fe"}},{id:"cyber",index:4,nameKey:"biome_cyber",startDepthM:900,endDepthM:1300,coinMultiplier:48,palette:{bgTop:"#120a21",bgBottom:"#1b0f30",wall:"#2a1647",strataFill:"#3b0764",strataStroke:"#a3e635",accent:"#f43f5e",glow:"#a3e635"}},{id:"quantum",index:5,nameKey:"biome_quantum",startDepthM:1300,endDepthM:Number.POSITIVE_INFINITY,coinMultiplier:100,palette:{bgTop:"#05070e",bgBottom:"#111827",wall:"#1f2937",strataFill:"#1e293b",strataStroke:"#fde047",accent:"#f8fafc",glow:"#fde047"}}],ne=[{id:"damage",nameKey:"upg_damage",descKey:"upg_damage_desc",baseCost:25,growthRate:1.54,maxLevel:38,icon:"pickaxe"},{id:"bounces",nameKey:"upg_bounces",descKey:"upg_bounces_desc",baseCost:35,growthRate:1.52,maxLevel:28,icon:"lightning"},{id:"multiorb",nameKey:"upg_multiorb",descKey:"upg_multiorb_desc",baseCost:480,growthRate:2.08,maxLevel:8,icon:"orb"},{id:"orbsize",nameKey:"upg_orbsize",descKey:"upg_orbsize_desc",baseCost:55,growthRate:1.54,maxLevel:20,icon:"blast"},{id:"luck",nameKey:"upg_luck",descKey:"upg_luck_desc",baseCost:65,growthRate:1.52,maxLevel:20,icon:"clover"},{id:"orevalue",nameKey:"upg_orevalue",descKey:"upg_orevalue_desc",baseCost:45,growthRate:1.55,maxLevel:34,icon:"coin"}],fe=[{id:"steel_sawblade",nameKey:"skin_steel_sawblade",category:"default",unlockDescKey:"skin_unlock_default",primaryColor:"#e2e8f0",secondaryColor:"#d97706",trailColor:"#ffb732",bladeTeeth:10},{id:"copper_gear",nameKey:"skin_copper_gear",category:"coin_or_ad",unlockDescKey:"skin_unlock_copper",primaryColor:"#d97706",secondaryColor:"#78350f",trailColor:"#f59e0b",bladeTeeth:12,coinCost:450},{id:"emerald_buzzsaw",nameKey:"skin_emerald_buzzsaw",category:"milestone",unlockDescKey:"skin_unlock_biome_1",primaryColor:"#34d399",secondaryColor:"#065f46",trailColor:"#10b981",bladeTeeth:14,unlockBiomeIndex:1,coinCost:1200},{id:"magma_cutter",nameKey:"skin_magma_cutter",category:"milestone",unlockDescKey:"skin_unlock_biome_2",primaryColor:"#fb7185",secondaryColor:"#991b1b",trailColor:"#f97316",bladeTeeth:12,unlockBiomeIndex:2,coinCost:4500},{id:"frost_star",nameKey:"skin_frost_star",category:"milestone",unlockDescKey:"skin_unlock_biome_3",primaryColor:"#7dd3fc",secondaryColor:"#0369a1",trailColor:"#38bdf8",bladeTeeth:12,unlockBiomeIndex:3,coinCost:15e3},{id:"gold_chakram",nameKey:"skin_gold_chakram",category:"coin_or_ad",unlockDescKey:"skin_unlock_day7",primaryColor:"#fde047",secondaryColor:"#dc2626",trailColor:"#fbbf24",bladeTeeth:8,coinCost:45e3},{id:"tesla_rotor",nameKey:"skin_tesla_rotor",category:"mastery",unlockDescKey:"skin_unlock_combo",primaryColor:"#2dd4bf",secondaryColor:"#1e293b",trailColor:"#22d3ee",bladeTeeth:8,masteryStat:"maxBounceCombo",masteryTarget:40,coinCost:12e4},{id:"toxic_drill",nameKey:"skin_toxic_drill",category:"coin_or_ad",unlockDescKey:"skin_unlock_toxic",primaryColor:"#a3e635",secondaryColor:"#3f6212",trailColor:"#bef264",bladeTeeth:14,coinCost:35e4,rvCost:3},{id:"void_reaper",nameKey:"skin_void_reaper",category:"milestone",unlockDescKey:"skin_unlock_biome_4",primaryColor:"#818cf8",secondaryColor:"#0f172a",trailColor:"#e0f2fe",bladeTeeth:6,unlockBiomeIndex:5,coinCost:1e6}],G={OFFLINE_UNLOCK_RUNS:3,OFFLINE_RATE_FRACTION:.15,OFFLINE_MAX_HOURS:4,OFFLINE_MIN_MINUTES:15,LOGIN_REWARDS:[{day:1,type:"coins",amount:300,labelKey:"reward_300_coins"},{day:2,type:"free_damage",amount:1,labelKey:"reward_free_damage"},{day:3,type:"shards",amount:5,labelKey:"reward_5_shards"},{day:4,type:"coins",amount:1500,labelKey:"reward_1500_coins"},{day:5,type:"overdrive_pass",amount:3,labelKey:"reward_overdrive_pass"},{day:6,type:"shards",amount:10,labelKey:"reward_10_shards"},{day:7,type:"skin",skinId:"gold_chakram",labelKey:"reward_golden_skin"}],DAILY_QUEST_POOL:[{id:"q_tnt",metric:"tntDetonated",target:20,labelKey:"quest_tnt",rewardCoins:250},{id:"q_bumpers",metric:"bumpersHit",target:35,labelKey:"quest_bumpers",rewardCoins:250},{id:"q_blocks",metric:"blocksDestroyed",target:120,labelKey:"quest_blocks",rewardCoins:300},{id:"q_runs",metric:"runsCompleted",target:8,labelKey:"quest_runs",rewardCoins:200},{id:"q_vaults",metric:"vaultsBroken",target:3,labelKey:"quest_vaults",rewardCoins:400}],DAILY_MEGA_CHEST_COINS:1e3,DAILY_MEGA_CHEST_SHARDS:5};function Ie(f,e,t){const s=e+y.MUZZLE_PIVOT_OFFSET_Y;return{x:f+Math.cos(t)*y.MUZZLE_LENGTH,y:s+Math.sin(t)*y.MUZZLE_LENGTH}}function ut(f){for(let e=O.length-1;e>=0;e--)if(f>=O[e].startDepthM)return O[e];return O[0]}function Ut(f){const e=ut(f);if(e.id!=="quantum")return e.coinMultiplier;const t=Math.max(0,Math.floor((f-1300)/250));return e.coinMultiplier*Math.pow(1.15,t)}function Ve(f,e,t=0){const s=at[e].hpMult;if(!Number.isFinite(s))return Number.POSITIVE_INFINITY;const i=ot(t);return Math.max(1,Math.floor(13*Math.pow(1+.0155*Math.max(0,f),1.38)*s*i))}function $e(f,e,t,s=0,i=0){const a=at[e].coinMult;if(a<=0)return 0;const n=Ut(f),r=pt(t),d=1+s*nt,l=lt(i);return Math.max(1,Math.floor(2*(1+.005*Math.max(0,f))*n*a*r*d*l))}function Nt(f,e){return Math.floor(f.baseCost*Math.pow(f.growthRate,Math.max(0,e-1)))}function Ft(f,e=0,t=0){const s=Math.max(1,f)-1;return(10+8*s+1.5*s*s)*(1+e*nt)*dt(t)}function Vt(f){return 8+2*(Math.max(1,f)-1)}function $t(f){return Math.max(1,Math.min(18,Math.floor(f)))}function Ht(f){return 14+.75*(Math.max(1,f)-1)}function Gt(f){const e=1+.03*Math.max(0,f-1);return Dt*y.TILE_SIZE*e}function qt(f){const e=.015*Math.max(0,f-1);return{tntChance:.08+e,bumperChance:.06+e}}function pt(f){return 1+.16*(Math.max(1,f)-1)}const zt=.25;class Wt{constructor(e){c(this,"rafId",null);c(this,"lastTimeMs",0);c(this,"accumulator",0);c(this,"running",!1);c(this,"pausedByVisibility",!1);c(this,"speedMultiplier",1);c(this,"callbacks");c(this,"visibilityListener",null);this.callbacks=e,typeof document<"u"&&(this.visibilityListener=()=>{document.visibilityState==="hidden"?(this.pausedByVisibility=!0,this.accumulator=0,this.callbacks.onVisibilityBlur?.()):(this.pausedByVisibility=!1,this.resetAccumulator())},document.addEventListener("visibilitychange",this.visibilityListener))}setSpeedMultiplier(e){this.speedMultiplier=Math.max(1,Math.min(4,e))}getSpeedMultiplier(){return this.speedMultiplier}start(){if(this.running)return;this.running=!0,this.lastTimeMs=performance.now();const e=t=>{if(!this.running)return;if(this.pausedByVisibility){this.lastTimeMs=t,this.accumulator=0,this.rafId=requestAnimationFrame(e);return}const s=Math.max(0,(t-this.lastTimeMs)/1e3);this.lastTimeMs=t,s>zt&&(this.accumulator=0);const i=Math.min(y.MAX_FRAME_DT,s);this.accumulator+=i*this.speedMultiplier;const a=y.FIXED_DT,n=Math.max(16,Math.ceil(y.MAX_FRAME_DT*this.speedMultiplier/a)+2);let r=0;for(;this.accumulator>=a&&r<n;)this.callbacks.onFixedUpdate(a),this.accumulator-=a,r++;r>=n&&this.accumulator>a&&(this.accumulator=0);const d=this.accumulator/a;this.callbacks.onRender(d,i),this.rafId=requestAnimationFrame(e)};this.rafId=requestAnimationFrame(e)}stop(){this.running=!1,this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null),this.visibilityListener&&typeof document<"u"&&(document.removeEventListener("visibilitychange",this.visibilityListener),this.visibilityListener=null)}resetAccumulator(){this.accumulator=0,this.lastTimeMs=performance.now()}}function F(f,e,t){return f<e?e:f>t?t:f}function X(f){return f*Math.PI/180}class He{constructor(e){c(this,"state");this.state=e>>>0,this.state===0&&(this.state=2654435769)}next(){let e=this.state+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}range(e,t){return e+this.next()*(t-e)}int(e,t){return Math.floor(this.range(e,t+1))}pick(e){return e[Math.floor(this.next()*e.length)]}}class Kt{constructor(e,t){c(this,"canvas");c(this,"callbacks");c(this,"activePointerId",null);c(this,"dragStartCss",{x:0,y:0});c(this,"currentAngleRad",Math.PI/2);c(this,"isDragging",!1);c(this,"isCanceled",!1);c(this,"locked",!1);c(this,"onContextMenu",e=>{e.preventDefault()});c(this,"onWheel",e=>{const t=e.target;(!t||!t.closest(".rm-scroll-area"))&&e.preventDefault()});c(this,"onWindowBlur",()=>{this.isDragging&&(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,null))});c(this,"onPointerDown",e=>{if(!(this.locked||!this.callbacks.canAim())&&!(e.button!==0&&e.pointerType==="mouse")&&!(this.isDragging||this.activePointerId!==null)){this.activePointerId=e.pointerId,this.dragStartCss={x:e.clientX,y:e.clientY},this.isDragging=!0,this.isCanceled=!0;try{this.canvas.setPointerCapture?.(e.pointerId)}catch{}this.callbacks.onAimStart(),this.updateAimFromPointer(e.clientX,e.clientY)}});c(this,"onPointerMove",e=>{if(!this.locked){if(this.isDragging){if(e.pointerId!==this.activePointerId)return;this.updateAimFromPointer(e.clientX,e.clientY);return}e.pointerType==="mouse"&&this.callbacks.getAimMode()==="direct"&&this.callbacks.canAim()&&e.target===this.canvas&&this.updateHoverDirectAim(e.clientX,e.clientY)}});c(this,"onPointerUp",e=>{if(!this.isDragging||e.pointerId!==this.activePointerId)return;if(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.locked||this.isCanceled){this.callbacks.onAimUpdate(null,!0,null);return}const t=this.currentAngleRad;this.callbacks.onAimUpdate(null,!1,null),this.callbacks.onLaunch(t)});c(this,"onPointerCancel",e=>{!this.isDragging||e.pointerId!==this.activePointerId||(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,null))});c(this,"onKeyDown",e=>{if((e.key===" "||e.code==="Space"||e.key==="ArrowUp"||e.key==="ArrowDown"||e.code==="ArrowLeft"||e.code==="ArrowRight"||e.code==="ArrowUp"||e.code==="ArrowDown")&&e.preventDefault(),this.locked)return;if(e.code==="KeyM"){this.callbacks.onToggleMute();return}if(e.code==="KeyP"){this.callbacks.onTogglePause();return}if(e.code==="KeyR"){this.callbacks.onQuickRelaunch();return}if(e.code>="Digit1"&&e.code<="Digit6"){const a=Number(e.code.slice(5))-1;this.callbacks.onBuyUpgradeSlot(a);return}if(!this.callbacks.canAim())return;const t=X(y.MIN_AIM_DEG),s=X(y.MAX_AIM_DEG),i=X(4);e.code==="ArrowLeft"||e.code==="KeyA"||e.code==="KeyQ"?(this.currentAngleRad=F(this.currentAngleRad+i,t,s),this.callbacks.onAimStart(),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)):e.code==="ArrowRight"||e.code==="KeyD"?(this.currentAngleRad=F(this.currentAngleRad-i,t,s),this.callbacks.onAimStart(),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)):(e.code==="Space"||e.code==="Enter")&&(this.callbacks.onAimUpdate(null,!1,null),this.callbacks.onLaunch(this.currentAngleRad))});this.canvas=e,this.callbacks=t,this.bind()}setLocked(e){this.locked=e,e&&this.isDragging&&(this.releasePointerCaptureSafe(this.activePointerId),this.isDragging=!1,this.activePointerId=null,this.callbacks.onAimUpdate(null,!0,null))}getCurrentAngleRad(){return this.currentAngleRad}getIsDragging(){return this.isDragging}bind(){this.canvas.addEventListener("pointerdown",this.onPointerDown),window.addEventListener("pointermove",this.onPointerMove),window.addEventListener("pointerup",this.onPointerUp),window.addEventListener("pointercancel",this.onPointerCancel),window.addEventListener("blur",this.onWindowBlur),this.canvas.addEventListener("contextmenu",this.onContextMenu),window.addEventListener("wheel",this.onWheel,{passive:!1}),window.addEventListener("keydown",this.onKeyDown)}releasePointerCaptureSafe(e){if(e!==null)try{this.canvas.hasPointerCapture?.(e)&&this.canvas.releasePointerCapture(e)}catch{}}computeWorldDeadzoneRadius(){const e=this.callbacks.clientToWorld(0,0),t=this.callbacks.clientToWorld(Math.max(y.CANCEL_DEADZONE_PX,18),0);return Math.max(18,Math.abs(t.x-e.x))}updateHoverDirectAim(e,t){const s=this.callbacks.clientToWorld(e,t),i=this.callbacks.getLauncherPos();if(s.y<=i.y-6)return;const a=s.x-i.x,n=Math.max(20,s.y-i.y),r=Math.atan2(n,a),d=X(y.MIN_AIM_DEG),l=X(y.MAX_AIM_DEG);this.currentAngleRad=F(r,d,l),this.callbacks.onAimUpdate(this.currentAngleRad,!1,null)}updateAimFromPointer(e,t){const s=this.callbacks.getAimMode(),i=e-this.dragStartCss.x,a=t-this.dragStartCss.y,n=Math.hypot(i,a),r=this.callbacks.clientToWorld(this.dragStartCss.x,this.dragStartCss.y),d=this.callbacks.clientToWorld(e,t),l=this.computeWorldDeadzoneRadius();if(s==="slingshot"){const v=Math.max(y.CANCEL_DEADZONE_PX,18);if(n<v||a>22){this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,{mode:s,dragging:!0,canceled:!0,originWorld:r,currentWorld:d,deadzoneWorldRadius:l});return}const k=-i,R=Math.max(24,28-a);this.isCanceled=!1;const M=Math.atan2(R,k),A=X(y.MIN_AIM_DEG),E=X(y.MAX_AIM_DEG);this.currentAngleRad=F(M,A,E),this.callbacks.onAimUpdate(this.currentAngleRad,!1,{mode:s,dragging:!0,canceled:!1,originWorld:r,currentWorld:d,deadzoneWorldRadius:l});return}const o=this.callbacks.getLauncherPos(),h=Math.hypot(d.x-o.x,d.y-o.y);if(d.y<o.y-12||n<6&&h<18){this.isCanceled=!0,this.callbacks.onAimUpdate(null,!0,{mode:s,dragging:!0,canceled:!0,originWorld:o,currentWorld:d,deadzoneWorldRadius:22});return}this.isCanceled=!1;const m=d.x-o.x,p=Math.max(20,d.y-o.y),u=Math.atan2(p,m),b=X(y.MIN_AIM_DEG),_=X(y.MAX_AIM_DEG);this.currentAngleRad=F(u,b,_),this.callbacks.onAimUpdate(this.currentAngleRad,!1,{mode:s,dragging:!0,canceled:!1,originWorld:o,currentWorld:d,deadzoneWorldRadius:22})}destroy(){this.canvas.removeEventListener("pointerdown",this.onPointerDown),window.removeEventListener("pointermove",this.onPointerMove),window.removeEventListener("pointerup",this.onPointerUp),window.removeEventListener("pointercancel",this.onPointerCancel),window.removeEventListener("blur",this.onWindowBlur),this.canvas.removeEventListener("contextmenu",this.onContextMenu),window.removeEventListener("wheel",this.onWheel),window.removeEventListener("keydown",this.onKeyDown)}}class jt{constructor(){c(this,"current","BOOT");c(this,"pausedFrom",null);c(this,"listeners",[])}get state(){return this.current}onChange(e){return this.listeners.push(e),()=>{this.listeners=this.listeners.filter(t=>t!==e)}}transition(e){if(e===this.current)return;const t=this.current;this.current=e;for(const s of this.listeners)s(e,t)}pauseForAd(){this.current!=="AD_PAUSED"&&(this.pausedFrom=this.current,this.transition("AD_PAUSED"))}resumeFromAd(){if(this.current!=="AD_PAUSED")return;const e=this.pausedFrom??"AIMING";this.pausedFrom=null,this.transition(e)}}const Yt=24;class Xt{constructor(e){c(this,"canvas");c(this,"layout");c(this,"onResizeCb",null);c(this,"handleResize",()=>{this.layout=this.computeLayout(),this.applyCanvasSize(),this.onResizeCb?.(this.layout)});this.canvas=e,this.layout=this.computeLayout(),this.applyCanvasSize(),window.addEventListener("resize",this.handleResize)}onResize(e){this.onResizeCb=e}getLayout(){return this.layout}computeLayout(){const e=Math.max(320,window.innerWidth),t=Math.max(400,window.innerHeight),s=Math.min(3,Math.max(1,window.devicePixelRatio||1)),i=t>e*1.05,a=y.SHAFT_WIDTH+Yt*2,n=e<1100?.44:.48,r=i?e/a:Math.min(e*n,560)/y.SHAFT_WIDTH,d=y.SHAFT_WIDTH*r,l=(e-d)*.5,o=i?Math.round(Math.min(106,Math.max(86,t*.105))):0;return{cssWidth:e,cssHeight:t,dpr:s,scale:r,shaftX:l,shaftWidthPx:d,topOffsetPx:o,isPortrait:i}}applyCanvasSize(){const{cssWidth:e,cssHeight:t,dpr:s,shaftX:i,shaftWidthPx:a,topOffsetPx:n}=this.layout;if(this.canvas.width=Math.round(e*s),this.canvas.height=Math.round(t*s),this.canvas.style.width=`${e}px`,this.canvas.style.height=`${t}px`,typeof document<"u"){const r=document.documentElement.style;r.setProperty("--rm-shaft-x",`${Math.round(i)}px`),r.setProperty("--rm-shaft-w",`${Math.round(a)}px`),r.setProperty("--rm-top-offset",`${Math.round(n)}px`)}}clientToWorld(e,t,s){const i=this.canvas.getBoundingClientRect(),a=e-i.left,n=t-i.top,{shaftX:r,scale:d,topOffsetPx:l}=this.layout;return{x:(a-r)/d,y:(n-l)/d+s}}destroy(){window.removeEventListener("resize",this.handleResize)}}const Z={biome_quarry:"Sunlit Quarry",biome_crystal:"Crystal Caverns",biome_magma:"Magma Foundry",biome_subzero:"Subzero Abyss",biome_cyber:"Cyber Neon Vault",biome_quantum:"Quantum Core",upg_damage:"Drill Damage",upg_damage_desc:"Smash harder & cleave weak blocks",upg_bounces:"Max Bounces",upg_bounces_desc:"More stamina per orb launch",upg_multiorb:"Multi-Orb Volley",upg_multiorb_desc:"Fire extra sawblades per shot",upg_orbsize:"Orb Size & Blast",upg_orbsize_desc:"Bigger blades & wider TNT blasts",upg_luck:"TNT & Bumper Luck",upg_luck_desc:"More explosives & bumpers in shaft",upg_orevalue:"Ore Value",upg_orevalue_desc:"Boosts all coin drops",depth:"DEPTH",coins:"COINS",bounces:"BOUNCES",shards:"SHARDS",recall:"Recall",fast_forward:"2x Speed",drag_to_shoot:"DRAG TO AIM & RELEASE",click_to_shoot:"AIM & CLICK TO LAUNCH",upgrades:"Upgrades",skins:"Skins",quests:"Quests",daily_login:"Daily Streak",settings:"Settings",elevator:"Elevator",prestige:"Core Overclock",prestige_desc:"Reset upgrades for +50% permanent Damage & Coins per level",prestige_btn:"OVERCLOCK NOW",launch_again:"Launch Again",continue_btn:"Continue",double_run_cta:"2x Coins (Ad)",extra_launch_cta:"+1 Bonus Launch (Ad)",free_upgrade_cta:"Free Level (Ad)",overdrive_cta:"Super-Orb Trial (Ad)",welcome_back:"Welcome Back!",offline_earned:"Auto-Drill mined while you were away:",collect:"Collect",collect_2x:"Collect 2x (Ad)",claim:"Claim",claimed:"Claimed",equip:"Equip",select_btn:"SELECT",equipped:"EQUIPPED",new_best_badge:"NEW BEST!",unlock_ad:"Watch Ad (+1/3)",unlock_shards:"Unlock (10 Shards)",daily_mega_chest:"Daily Mega Chest",run_complete:"Run Complete",earned_coins:"Coins Earned",max_depth:"Max Depth",ad_unavailable:"Ad unavailable right now",ad_incomplete:"Watch full video to claim reward",short_break:"Short Break...",aim_slingshot:"Slingshot Pull",aim_direct:"Direct Aim",boss_gate:"BEDROCK GATE",biome_unlocked_title:"BIOME UNLOCKED!",biome_unlocked_desc:"Elevator Checkpoint Active",descend_now:"Descend Now",coin_mult_badge:"Coin Multiplier",skin_unlocked_badge:"Skin Unlocked",overheat_recall:"OVERHEAT RECALL",maxed:"MAX",paused:"Paused",resume:"Resume",restart_run:"Restart Run",home_btn:"Home",play_btn:"PLAY",best_depth:"Best Depth",language_label:"Language",sfx_label:"Sound FX",music_label:"Music",aim_mode_label:"Aim Mode",reset_progress:"Reset Progress",reset_confirm_desc:"Reset all coins, upgrades, depth, quests, and skins back to Run 1? This cannot be undone.",cancel_btn:"Cancel",confirm_reset_btn:"Confirm Reset",super_orb_label:"Super-Orb",free_ad_sub:"FREE (AD)",streak_short:"Streak",skin_steel_sawblade:"Steel Sawblade",skin_copper_gear:"Copper Gear Grinder",skin_emerald_buzzsaw:"Emerald Buzzsaw",skin_magma_cutter:"Molten Magma Cutter",skin_frost_star:"Glacial Frost Star",skin_gold_chakram:"Royal Gold Chakram",skin_tesla_rotor:"Tesla Plasma Rotor",skin_toxic_drill:"Toxic Bio-Drill",skin_void_reaper:"Obsidian Void Reaper",skin_unlock_default:"Starter Blade",skin_unlock_copper:"Buy with Coins",skin_unlock_biome_1:"Break Quarry Boss Gate",skin_unlock_biome_2:"Break Crystal Boss Gate",skin_unlock_biome_3:"Break Magma Boss Gate",skin_unlock_biome_4:"Reach Quantum Core",skin_unlock_combo:"Reach 40-Bounce Combo",skin_unlock_toxic:"Coins or 3 Rewarded Ads",skin_unlock_day7:"Day 7 Streak or Coins",quest_tnt:"Detonate 20 TNT Crates",quest_bumpers:"Hit 35 Pinball Bumpers",quest_blocks:"Destroy 120 Ore Blocks",quest_runs:"Complete 8 Runs",quest_vaults:"Break 3 Vault Chests",reward_300_coins:"300 Coins",reward_free_damage:"+1 Damage Level",reward_5_shards:"5 Skin Shards",reward_1500_coins:"1,500 Coins",reward_overdrive_pass:"3x Super-Orb Passes",reward_10_shards:"10 Skin Shards",reward_golden_skin:"Royal Gold Chakram",achievements:"Achievements",hall_of_ascension:"Hall of Ascension",ascension_milestones:"Ascension Milestones",mastery_feats:"Mastery Feats",full_shaft_run:"FULL-SHAFT RUN",tier_label:"Tier",no_ascension_yet:"Tier 0 (Unascended)",one_shot_victory:"ONE-SHOT VICTORY!",blocks_smashed:"Blocks Smashed",max_combo_label:"Max Combo",next_tier_label:"Next Tier",next_tier_preview:"2x Enemy HP • 1.65x Coins • +10 Max Lvls • +15% DMG",descend_to_tier:"DESCEND TO TIER {tier} (2x HARDER)",double_victory_coins:"2x VICTORY COINS (AD)",elevator_clear_title:"BIOME 6 CLEARED!",elevator_clear_desc:"Now clear all biomes in ONE shot from 0m to unlock Tier {tier} (2x Harder)!",start_0m_run:"Start 0m Run",asc_req_hint:"Clear 0m to 1550m in one launch for Tier {tier}",asc_tier_1_title:"Quarry Legend",asc_tier_1_quote:"One launch. Six biomes. Zero mercy. The bedrock remembers your blade.",asc_tier_2_title:"Tectonic Breaker",asc_tier_2_quote:"Double the stone, twice the glory. You tore straight through the planet's crust.",asc_tier_3_title:"Core Annihilator",asc_tier_3_quote:"Not even magma and steel could slow your ricochet. Pure precision.",asc_tier_4_title:"Abyssal God",asc_tier_4_quote:"You have conquered the impossible depth in a single breath. The mine bows to you.",feat_chain_title:"Chain Detonator",feat_chain_desc:"Trigger 5+ TNT explosions in a single launch",feat_combo_title:"Combo Master",feat_combo_desc:"Reach a 50+ hit combo in one shot",feat_investor_title:"Heavy Investor",feat_investor_desc:"Upgrade any stat to Level 20+",feat_zeroskip_title:"Zero-Skip Purist",feat_zeroskip_desc:"Reach Biome 4 in one shot from 0m",vol_off:"OFF",vol_low:"LOW",vol_high:"HIGH"},Qt={...Z,vol_off:"ВЫКЛ",vol_low:"ТИХО",vol_high:"ГРОМКО",biome_quarry:"Солнечный Карьер",biome_crystal:"Кристальные Пещеры",biome_magma:"Магмовая Кузня",biome_subzero:"Ледяная Бездна",biome_cyber:"Кибер-Неон",biome_quantum:"Квантовое Ядро",upg_damage:"Урон Бура",upg_damage_desc:"Мощнее удар и пробитие блоков",upg_bounces:"Макс. Отскоков",upg_bounces_desc:"Больше энергии на запуск",upg_multiorb:"Мульти-Залп",upg_multiorb_desc:"Дополнительные пилы за выстрел",upg_orbsize:"Размер и Взрыв",upg_orbsize_desc:"Крупнее пилы и радиус TNT",upg_luck:"Удача TNT",upg_luck_desc:"Больше TNT и бамперов",upg_orevalue:"Ценность Руды",upg_orevalue_desc:"Больше монет из блоков",depth:"ГЛУБИНА",coins:"МОНЕТЫ",bounces:"ОТСКОКИ",shards:"ОСКОЛКИ",recall:"Возврат",fast_forward:"2x Скорость",drag_to_shoot:"ТЯНИТЕ И ОТПУСТИТЕ",click_to_shoot:"НАВЕДИТЕ И НАЖМИТЕ ДЛЯ ЗАПУСКА",upgrades:"Улучшения",skins:"Скины",quests:"Квесты",daily_login:"Награды",settings:"Настройки",elevator:"Лифт",prestige:"Разгон Ядра",prestige_btn:"РАЗГОН ЯДРА",launch_again:"Запуск Снова",continue_btn:"Продолжить",double_run_cta:"2x Монеты (Реклама)",extra_launch_cta:"+1 Запуск (Реклама)",free_upgrade_cta:"Бесплатно (Реклама)",overdrive_cta:"Супер-Шар (Реклама)",welcome_back:"С возвращением!",offline_earned:"Авто-Бур добыл в ваше отсутствие:",collect:"Забрать",collect_2x:"Забрать 2x",claim:"Получить",claimed:"Получено",equip:"Выбрать",select_btn:"ВЫБРАТЬ",equipped:"ВЫБРАНО",new_best_badge:"НОВЫЙ РЕКОРД!",run_complete:"Забег Завершён",earned_coins:"Заработано",max_depth:"Макс. Глубина",paused:"Пауза",resume:"Продолжить",restart_run:"Перезапуск",home_btn:"Домой",play_btn:"ИГРАТЬ",best_depth:"Рекорд",language_label:"Язык",sfx_label:"Звуки",music_label:"Музыка",aim_mode_label:"Прицел",reset_progress:"Сбросить прогресс",reset_confirm_desc:"Сбросить все монеты, улучшения, глубину, квесты и скины? Это действие необратимо.",cancel_btn:"Отмена",confirm_reset_btn:"Сбросить",super_orb_label:"Супер-Шар",free_ad_sub:"БЕСПЛАТНО (АД)",streak_short:"Серия",skin_steel_sawblade:"Стальная Пила",skin_copper_gear:"Медная Шестерня",skin_emerald_buzzsaw:"Изумрудная Пила",skin_magma_cutter:"Магма-Резак",skin_frost_star:"Ледяная Звезда",skin_gold_chakram:"Золотая Чакра",skin_tesla_rotor:"Тесла-Ротор",skin_toxic_drill:"Токсик-Бур",skin_void_reaper:"Жнец Бездны",achievements:"Достижения",hall_of_ascension:"Зал Вознесения",ascension_milestones:"Вехи Вознесения",mastery_feats:"Подвиги Мастерства",full_shaft_run:"ПОЛНЫЙ СПУСК 0м",tier_label:"Ранг",no_ascension_yet:"Ранг 0 (Обычный)",one_shot_victory:"ПОБЕДА С ОДНОГО ЗАПУСКА!",blocks_smashed:"Разбито блоков",max_combo_label:"Макс. комбо",next_tier_label:"След. ранг",next_tier_preview:"2x HP • 1.65x Монеты • +10 Макс. Ур. • +15% Урон",descend_to_tier:"СПУСК НА РАНГ {tier} (В 2x СЛОЖНЕЕ)",double_victory_coins:"2x МОНЕТЫ ПОБЕДЫ (АД)",elevator_clear_title:"БИОМ 6 ПРОЙДЕН!",elevator_clear_desc:"Пройдите все биомы за ОДИН запуск с 0м, чтобы открыть Ранг {tier} (в 2x сложнее)!",start_0m_run:"Забег с 0м",asc_tier_1_title:"Легенда Карьера",asc_tier_2_title:"Тектонический Крушитель",asc_tier_3_title:"Истребитель Ядра",asc_tier_4_title:"Бог Бездны",feat_chain_title:"Цепной Подрывник",feat_combo_title:"Мастер Комбо",feat_investor_title:"Крупный Инвестор",feat_zeroskip_title:"Пурист Без Лифта"},Zt={...Z,vol_off:"NO",vol_low:"BAJO",vol_high:"ALTO",biome_quarry:"Cantera Soleada",biome_crystal:"Cavernas de Cristal",biome_magma:"Forja de Magma",biome_subzero:"Abismo Glacial",biome_cyber:"Bóveda Ciber Neón",biome_quantum:"Núcleo Cuántico",upg_damage:"Daño de Taladro",upg_bounces:"Rebotes Máx.",upg_multiorb:"Salva Múltiple",upg_orbsize:"Tamaño y Explosión",upg_luck:"Suerte TNT",upg_orevalue:"Valor de Mineral",drag_to_shoot:"ARRASTRA Y SUELTA",click_to_shoot:"APUNTA Y HAZ CLIC PARA LANZAR",select_btn:"ELEGIR",new_best_badge:"¡NUEVO RÉCORD!",upgrades:"Mejoras",skins:"Aspectos",quests:"Misiones",daily_login:"Racha",settings:"Ajustes",elevator:"Ascensor",launch_again:"Lanzar de Nuevo",continue_btn:"Continuar",paused:"Pausa",resume:"Reanudar",restart_run:"Reiniciar",home_btn:"Inicio",play_btn:"JUGAR",best_depth:"Mejor Prof.",language_label:"Idioma",sfx_label:"Efectos",music_label:"Música",aim_mode_label:"Apuntado",reset_progress:"Reiniciar Progreso",reset_confirm_desc:"¿Reiniciar monedas, mejoras, profundidad, misiones y aspectos al inicio?",cancel_btn:"Cancelar",confirm_reset_btn:"Confirmar",super_orb_label:"Súper-Orbe",free_ad_sub:"GRATIS (ANUNCIO)",streak_short:"Racha",achievements:"Logros",hall_of_ascension:"Salón de Ascensión",ascension_milestones:"Hitos de Ascensión",mastery_feats:"Hazañas de Maestría",full_shaft_run:"DESCENSO 0m",tier_label:"Nivel",one_shot_victory:"¡VICTORIA DE UN TIRO!",blocks_smashed:"Bloques Rotos",max_combo_label:"Combo Máx.",descend_to_tier:"DESCENDER AL NIVEL {tier} (2x MÁS DIFÍCIL)",double_victory_coins:"2x MONEDAS (ANUNCIO)",elevator_clear_title:"¡BIOMA 6 SUPERADO!",elevator_clear_desc:"¡Supera todos los biomas de UN tiro desde 0m para desbloquear el Nivel {tier}!",start_0m_run:"Iniciar desde 0m"},Jt={...Z,vol_off:"DESL",vol_low:"BAIXO",vol_high:"ALTO",biome_quarry:"Pedreira Solar",biome_crystal:"Cavernas de Cristal",biome_magma:"Forja de Magma",biome_subzero:"Abismo Glacial",biome_cyber:"Cofre Cyber Neon",biome_quantum:"Núcleo Quântico",upg_damage:"Dano da Broca",upg_bounces:"Ricochetes Máx.",upg_multiorb:"Disparo Múltiplo",upg_orbsize:"Tamanho e Explosão",upg_luck:"Sorte TNT",upg_orevalue:"Valor do Minério",drag_to_shoot:"ARRASTE E SOLTE",click_to_shoot:"MIRE E CLIQUE PARA LANÇAR",select_btn:"SELECIONAR",new_best_badge:"NOVO RECORDE!",upgrades:"Melhorias",skins:"Visuais",quests:"Missões",daily_login:"Diário",settings:"Opções",elevator:"Elevador",launch_again:"Lançar Novamente",continue_btn:"Continuar",paused:"Pausado",resume:"Continuar",restart_run:"Reiniciar",home_btn:"Início",play_btn:"JOGAR",best_depth:"Recorde",language_label:"Idioma",sfx_label:"Efeitos",music_label:"Música",aim_mode_label:"Mira",reset_progress:"Resetar Progresso",reset_confirm_desc:"Resetar todas as moedas, melhorias, profundidade e visuais para o início?",cancel_btn:"Cancelar",confirm_reset_btn:"Confirmar",super_orb_label:"Super-Orbe",free_ad_sub:"GRÁTIS (ANÚNCIO)",streak_short:"Diário",achievements:"Conquistas",hall_of_ascension:"Salão da Ascensão",full_shaft_run:"DESCIDA 0m",tier_label:"Nível",one_shot_victory:"VITÓRIA EM UM TIRO!",blocks_smashed:"Blocos Quebrados",max_combo_label:"Combo Máx.",descend_to_tier:"DESCER AO NÍVEL {tier} (2x MAIS DIFÍCIL)",double_victory_coins:"2x MOEDAS (ANÚNCIO)",elevator_clear_title:"BIOMA 6 CONCLUÍDO!",elevator_clear_desc:"Limpe todos os biomas em UM tiro a partir de 0m para desbloquear o Nível {tier}!",start_0m_run:"Iniciar de 0m"},es={...Z,vol_off:"NON",vol_low:"BAS",vol_high:"HAUT",biome_quarry:"Carrière Ensoleillée",biome_crystal:"Cavernes de Cristal",biome_magma:"Forge de Magma",biome_subzero:"Abysse Glaciaire",biome_cyber:"Coffre Cyber Néon",biome_quantum:"Cœur Quantique",upg_damage:"Dégâts Foreuse",upg_bounces:"Rebonds Max",upg_multiorb:"Salve Multiple",upg_orbsize:"Taille & Explosion",upg_luck:"Chance TNT",upg_orevalue:"Valeur Minerai",drag_to_shoot:"GLISSER ET RELÂCHER",click_to_shoot:"VISEZ ET CLIQUEZ POUR LANCER",select_btn:"CHOISIR",new_best_badge:"NOUVEAU RECORD !",upgrades:"Améliorations",skins:"Apparences",quests:"Quêtes",daily_login:"Série",settings:"Paramètres",elevator:"Ascenseur",launch_again:"Relancer",continue_btn:"Continuer",paused:"Pause",resume:"Reprendre",restart_run:"Recommencer",home_btn:"Accueil",play_btn:"JOUER",best_depth:"Record",language_label:"Langue",sfx_label:"Effets",music_label:"Musique",aim_mode_label:"Visée",reset_progress:"Réinitialiser",reset_confirm_desc:"Réinitialiser pièces, améliorations, profondeur, quêtes et apparences ?",cancel_btn:"Annuler",confirm_reset_btn:"Confirmer",super_orb_label:"Super-Orbe",free_ad_sub:"GRATUIT (PUB)",streak_short:"Série",achievements:"Succès",hall_of_ascension:"Hall de l'Ascension",full_shaft_run:"DESCENTE 0m",tier_label:"Palier",one_shot_victory:"VICTOIRE EN UN COUP !",blocks_smashed:"Blocs Détruits",max_combo_label:"Combo Max",descend_to_tier:"DESCENDRE AU PALIER {tier} (2x PLUS DUR)",double_victory_coins:"2x PIÈCES (PUB)",elevator_clear_title:"BIOME 6 TERMINÉ !",elevator_clear_desc:"Terminez tous les biomes en UN coup depuis 0m pour débloquer le Palier {tier} !",start_0m_run:"Lancer à 0m"},ts={...Z,vol_off:"AUS",vol_low:"LEISE",vol_high:"LAUT",biome_quarry:"Sonnensteinbruch",biome_crystal:"Kristallhöhlen",biome_magma:"Magmaschmiede",biome_subzero:"Eis-Abgrund",biome_cyber:"Cyber-Neon-Tresor",biome_quantum:"Quantenkern",upg_damage:"Bohrschaden",upg_bounces:"Max. Abpraller",upg_multiorb:"Mehrfach-Salve",upg_orbsize:"Größe & Sprengung",upg_luck:"TNT-Glück",upg_orevalue:"Erzwert",drag_to_shoot:"ZIEHEN & LOSLASSEN",click_to_shoot:"ZIELEN & KLICKEN ZUM START",select_btn:"WÄHLEN",new_best_badge:"NEUER REKORD!",upgrades:"Upgrades",skins:"Skins",quests:"Quests",daily_login:"Serie",settings:"Optionen",elevator:"Aufzug",launch_again:"Erneut Feuern",continue_btn:"Weiter",paused:"Pausiert",resume:"Fortsetzen",restart_run:"Neu starten",home_btn:"Startseite",play_btn:"SPIELEN",best_depth:"Rekord",language_label:"Sprache",sfx_label:"Sound-FX",music_label:"Musik",aim_mode_label:"Zielmodus",reset_progress:"Fortschritt zurücksetzen",reset_confirm_desc:"Alle Münzen, Upgrades, Tiefe, Quests und Skins zurücksetzen?",cancel_btn:"Abbrechen",confirm_reset_btn:"Zurücksetzen",super_orb_label:"Super-Orb",free_ad_sub:"GRATIS (WERBUNG)",streak_short:"Serie",achievements:"Erfolge",hall_of_ascension:"Halle des Aufstiegs",full_shaft_run:"VOLLSCHACHT 0m",tier_label:"Stufe",one_shot_victory:"ONE-SHOT-SIEG!",blocks_smashed:"Blöcke Zerstört",max_combo_label:"Max. Kombo",descend_to_tier:"ABSTIEG ZU STUFE {tier} (2x SCHWERER)",double_victory_coins:"2x SIEGMÜNZEN (WERBUNG)",elevator_clear_title:"BIOM 6 GESCHAFFT!",elevator_clear_desc:"Schaffe alle Biome in EINEM Schuss ab 0m für Stufe {tier} (2x schwerer)!",start_0m_run:"0m-Lauf Starten"},ss={...Z,vol_off:"KAPALI",vol_low:"KISIK",vol_high:"YÜKSEK",biome_quarry:"Güneşli Ocak",biome_crystal:"Kristal Mağaralar",biome_magma:"Magma Ocağı",biome_subzero:"Buzul Uçurum",biome_cyber:"Siber Neon Kasa",biome_quantum:"Kuantum Çekirdek",upg_damage:"Matkap Hasarı",upg_bounces:"Maks. Sekme",upg_multiorb:"Çoklu Atış",upg_orbsize:"Boyut ve Patlama",upg_luck:"TNT Şansı",upg_orevalue:"Maden Değeri",drag_to_shoot:"ÇEK VE BIRAK",click_to_shoot:"NİŞAN AL VE FIRLATMAK İÇİN TIKLA",select_btn:"SEÇ",new_best_badge:"YENİ REKOR!",upgrades:"Geliştirmeler",skins:"Görünümler",quests:"Görevler",daily_login:"Günlük",settings:"Ayarlar",elevator:"Asansör",launch_again:"Tekrar Fırlat",continue_btn:"Devam Et",paused:"Duraklatıldı",resume:"Devam Et",restart_run:"Yeniden Başlat",home_btn:"Ana Sayfa",play_btn:"OYNA",best_depth:"En Derin",language_label:"Dil",sfx_label:"Ses Efektleri",music_label:"Müzik",aim_mode_label:"Nişan Modu",reset_progress:"İlerlemeyi Sıfırla",reset_confirm_desc:"Tüm altınlar, geliştirmeler, derinlik ve görünümler sıfırlansın mı?",cancel_btn:"İptal",confirm_reset_btn:"Sıfırla",super_orb_label:"Süper Küre",free_ad_sub:"ÜCRETSİZ (REKLAM)",streak_short:"Seri",achievements:"Başarılar",hall_of_ascension:"Yükseliş Salonu",full_shaft_run:"TAM İNİŞ 0m",tier_label:"Kademe",one_shot_victory:"TEK ATIŞ ZAFERİ!",blocks_smashed:"Kırılan Bloklar",max_combo_label:"Maks. Kombo",descend_to_tier:"KADEME {tier} İNİŞİ (2x ZOR)",double_victory_coins:"2x ZAFER ALTINI (REKLAM)",elevator_clear_title:"BİYOM 6 TEMİZLENDİ!",elevator_clear_desc:"Kademe {tier} kilidini açmak için 0m noktasından TEK atışla tüm biyomları geç!",start_0m_run:"0m İnişi Başlat"},is={...Z,vol_off:"OFF",vol_low:"小",vol_high:"大",biome_quarry:"陽光採石場",biome_crystal:"クリスタル洞窟",biome_magma:"マグマ溶鉱炉",biome_subzero:"氷結の深淵",biome_cyber:"サイバーネオン金庫",biome_quantum:"クォンタムコア",upg_damage:"ドリル攻撃力",upg_bounces:"最大バウンド",upg_multiorb:"マルチショット",upg_orbsize:"サイズ＆爆発",upg_luck:"TNT＆バンパー運",upg_orevalue:"鉱石価値",drag_to_shoot:"ドラッグして発射",click_to_shoot:"狙ってクリックで発射",select_btn:"選択",new_best_badge:"新記録！",upgrades:"強化",skins:"スキン",quests:"クエスト",daily_login:"ログイン",settings:"設定",elevator:"エレベーター",launch_again:"もう一度発射",continue_btn:"続ける",paused:"一時停止",resume:"再開",restart_run:"リスタート",home_btn:"ホーム",play_btn:"プレイ",best_depth:"最高深度",language_label:"言語",sfx_label:"効果音",music_label:"BGM",aim_mode_label:"照準モード",reset_progress:"データ初期化",reset_confirm_desc:"コイン、強化、深度、クエスト、スキンをすべて初期化しますか？",cancel_btn:"キャンセル",confirm_reset_btn:"初期化する",super_orb_label:"スーパーオーブ",free_ad_sub:"無料 (広告)",streak_short:"連続",achievements:"実績",hall_of_ascension:"昇天の殿堂",full_shaft_run:"0m一発踏破",tier_label:"ティア",one_shot_victory:"一発完全勝利！",blocks_smashed:"破壊ブロック",max_combo_label:"最大コンボ",descend_to_tier:"ティア {tier} へ降下 (難易度2倍)",double_victory_coins:"2倍勝利コイン (広告)",elevator_clear_title:"バイオーム6制覇！",elevator_clear_desc:"0mから一発で全バイオームを突破してティア {tier} を解放しよう！",start_0m_run:"0mから挑戦"},as={...Z,vol_off:"끔",vol_low:"약함",vol_high:"큼",biome_quarry:"햇빛 채석장",biome_crystal:"수정 동굴",biome_magma:"마그마 용광로",biome_subzero:"빙하 심연",biome_cyber:"사이버 네온 금고",biome_quantum:"퀀텀 코어",upg_damage:"드릴 공격력",upg_bounces:"최대 바운스",upg_multiorb:"멀티 발사",upg_orbsize:"크기 및 폭발",upg_luck:"TNT 및 범퍼 운",upg_orevalue:"광물 가치",drag_to_shoot:"드래그하여 발사",click_to_shoot:"조준 후 클릭하여 발사",select_btn:"선택",new_best_badge:"신기록!",upgrades:"업그레이드",skins:"스킨",quests:"퀘스트",daily_login:"출석",settings:"설정",elevator:"엘리베이터",launch_again:"다시 발사",continue_btn:"계속하기",paused:"일시정지",resume:"계속하기",restart_run:"다시 시작",home_btn:"홈",play_btn:"플레이",best_depth:"최고 깊이",language_label:"언어",sfx_label:"효과음",music_label:"배경음",aim_mode_label:"조준 모드",reset_progress:"진행 초기화",reset_confirm_desc:"모든 코인, 업그레이드, 깊이, 퀘스트 및 스킨을 초기화할까요?",cancel_btn:"취소",confirm_reset_btn:"초기화",super_orb_label:"슈퍼 오브",free_ad_sub:"무료 (광고)",streak_short:"연속",achievements:"업적",hall_of_ascension:"승천의 전당",full_shaft_run:"0m 원샷 도전",tier_label:"티어",one_shot_victory:"원샷 완전 승리!",blocks_smashed:"파괴한 블록",max_combo_label:"최대 콤보",descend_to_tier:"티어 {tier} 강하 (2배 어려움)",double_victory_coins:"2배 승리 코인 (광고)",elevator_clear_title:"바이옴 6 클리어!",elevator_clear_desc:"0m부터 원샷으로 모든 바이옴을 돌파해 티어 {tier}를 해금하세요!",start_0m_run:"0m 도전 시작"},Ge={en:Z,ru:Qt,es:Zt,pt:Jt,fr:es,de:ts,tr:ss,ja:is,ko:as};class ns{constructor(){c(this,"locale","en")}setLocale(e){if(!e){this.locale="en";return}const t=e.toLowerCase().slice(0,2);this.locale=t in Ge?t:"en"}getLocale(){return this.locale}t(e){return Ge[this.locale]?.[e]??Z[e]}}const g=new ns,qe=.15,ze=14,rs=4.5;class W{static onWallBounce(e){e.consecutiveWallHits++,e.y<=e.maxProgressY+12?e.nonProgressBounces++:e.maxProgressY=e.y;const t=W.computeHeightStdDev(e),s=e.heightSampleCount>=6&&t<ze&&(e.consecutiveWallHits>=2||e.nonProgressBounces>=4);(e.consecutiveWallHits>=y.HORIZONTAL_TRAP_WALL_HITS||s)&&(e.consecutiveWallHits=0,e.nonProgressBounces=0,W.deflectDownward(e,s?14:y.HORIZONTAL_TRAP_DEFLECT_DEG))}static onIndestructibleHit(e){e.y<=e.maxProgressY+12?e.nonProgressBounces++:e.maxProgressY=e.y;const t=W.computeHeightStdDev(e);(e.nonProgressBounces>=5||e.heightSampleCount>=6&&t<ze&&e.nonProgressBounces>=3)&&(e.nonProgressBounces=0,W.deflectDownward(e,14))}static onBlockHit(e){e.consecutiveWallHits=0,e.nonProgressBounces=0,e.timeSinceProgress=0,e.overheatDraining=!1,e.stallBoostApplied=!1,e.y>e.maxProgressY&&(e.maxProgressY=e.y)}static updateStallWatchdog(e,t){if(e.y>e.maxProgressY+24&&(e.maxProgressY=e.y,e.nonProgressBounces=0),e.heightSampleTimer+=t,e.heightSampleTimer>=qe){e.heightSampleTimer-=qe;const s=e.heightSamples.length;e.heightSamples[e.heightSampleCursor]=e.y,e.heightSampleCursor=(e.heightSampleCursor+1)%s,e.heightSampleCount<s&&e.heightSampleCount++}if(e.timeSinceProgress+=t,e.timeSinceProgress>=rs){if(e.overheatDraining=!0,!e.stallBoostApplied){e.stallBoostApplied=!0;const i=Math.hypot(e.vx,e.vy);if(i>1e-4){const n=Math.min(y.MAX_ORB_SPEED,i*2)/i;e.vx*=n,e.vy*=n}}const s=e.timeSinceProgress>=y.OVERHEAT_STALL_SECONDS?14:4.5;if(e.bouncesLeft=Math.max(0,e.bouncesLeft-t*s),e.bouncesLeft<=0)return e.alive=!1,!0}return!1}static computeHeightStdDev(e){const t=e.heightSampleCount;if(t<2)return Number.POSITIVE_INFINITY;let s=0;for(let n=0;n<t;n++)s+=e.heightSamples[n];const i=s/t;let a=0;for(let n=0;n<t;n++){const r=e.heightSamples[n]-i;a+=r*r}return Math.sqrt(a/t)}static deflectDownward(e,t){const s=X(t),i=Math.hypot(e.vx,e.vy),a=e.vx>=0?1:-1,n=Math.atan2(Math.abs(e.vy),Math.abs(e.vx)),r=Math.min(Math.PI/2-.08,n+s);e.vx=a*Math.cos(r)*i,e.vy=Math.sin(r)*i,e.y+=2}}class os{constructor(){c(this,"buckets",new Map);c(this,"activeKeys",[]);c(this,"queryResult",[]);c(this,"visitedStamp",new Map);c(this,"querySeq",0)}rebuild(e){for(let t=0;t<this.activeKeys.length;t++){const s=this.buckets.get(this.activeKeys[t]);s&&(s.length=0)}this.activeKeys.length=0;for(let t=0;t<e.length;t++){const s=e[t];if(s.alive)for(let i=0;i<s.colSpan;i++){const a=this.key(s.col+i,s.row);let n=this.buckets.get(a);n||(n=[],this.buckets.set(a,n)),n.length===0&&this.activeKeys.push(a),n.push(s)}}}queryCircle(e,t,s){const i=y.TILE_SIZE,a=Math.max(0,Math.floor((e-s)/i)),n=Math.min(y.GRID_COLS-1,Math.floor((e+s)/i)),r=Math.max(0,Math.floor((t-s)/i)),d=Math.floor((t+s)/i);this.queryResult.length=0,this.querySeq++,this.querySeq>=2147483647&&(this.visitedStamp.clear(),this.querySeq=1);const l=this.querySeq;for(let o=r;o<=d;o++)for(let h=a;h<=n;h++){const m=this.buckets.get(this.key(h,o));if(!(!m||m.length===0))for(let p=0;p<m.length;p++){const u=m[p];u.alive&&this.visitedStamp.get(u.id)!==l&&(this.visitedStamp.set(u.id,l),this.queryResult.push(u))}}return this.queryResult}isCellOccupied(e,t,s){if(e<0||e>=y.GRID_COLS||t<0)return!0;const i=this.buckets.get(this.key(e,t));if(i){for(let a=0;a<i.length;a++)if(i[a].alive)return!0}for(let a=0;a<s.length;a++){const n=s[a];if(n.alive&&n.row===t&&e>=n.col&&e<n.col+n.colSpan)return!0}return!1}key(e,t){return t*32+e}}const We=14,ls=16;class cs{constructor(e={}){c(this,"grid",new os);c(this,"nextOrbId",1);c(this,"events");c(this,"cloneBuffer",[]);this.events=e}setEvents(e){this.events=e}createOrb(e,t,s,i,a,n,r=!1,d=!1){const l=y.LAUNCH_SPEED*(d?1.08:1),o=[];for(let m=0;m<We;m++)o.push({x:e,y:t});const h=new Array(ls).fill(t);return{id:this.nextOrbId++,x:e,y:t,prevX:e,prevY:t,vx:Math.cos(s)*l,vy:Math.sin(s)*l,radius:i,bouncesLeft:a,maxBounces:a,damage:n,rotation:0,comboCount:0,consecutiveWallHits:0,nonProgressBounces:0,maxProgressY:t,timeSinceProgress:0,heightSamples:h,heightSampleCursor:0,heightSampleCount:1,heightSampleTimer:0,overheatDraining:!1,stallBoostApplied:!1,portalCooldown:0,isClone:r,isOverdrive:d,trail:[o[0]],trailPool:o,alive:!0}}step(e,t,s,i,a,n,r=0){this.grid.rebuild(s);for(let l=0;l<s.length;l++){const o=s[l];o.hitFlashTimer>0&&(o.hitFlashTimer=Math.max(0,o.hitFlashTimer-e))}this.cloneBuffer.length=0;let d=0;for(let l=0;l<t.length;l++)t[l].alive&&d++;for(let l=0;l<t.length;l++){const o=t[l];if(!o.alive)continue;o.prevX=o.x,o.prevY=o.y,o.portalCooldown>0&&(o.portalCooldown=Math.max(0,o.portalCooldown-e)),o.vy+=y.GRAVITY*e,this.normalizeOrbSpeed(o);const h=o.vx*e,m=o.vy*e,p=Math.hypot(h,m),u=Math.max(2,o.radius*.35),b=Math.max(1,Math.ceil(p/u)),_=e/b;for(let v=0;v<b&&o.alive;v++){const k=o.x,R=o.y;if(o.x+=o.vx*_,o.y+=o.vy*_,this.resolveWallCollisions(o),!o.alive)break;this.resolveEntityCollisions(o,k,R,d,this.cloneBuffer,s,i,a,n,r),o.alive&&this.enforceWallBounds(o)}o.rotation+=Math.hypot(o.vx,o.vy)/Math.max(8,o.radius)*e*1.4,this.pushTrailPoint(o),o.alive&&W.updateStallWatchdog(o,e)&&this.events.onOrbExpired?.(o)}for(let l=0;l<this.cloneBuffer.length&&!(d>=y.MAX_ACTIVE_ORBS);l++)t.push(this.cloneBuffer[l]),d++}pushTrailPoint(e){if(e.trail.length<We){const t=e.trailPool[e.trail.length];t.x=e.x,t.y=e.y,e.trail.push(t)}else{const t=e.trail.shift();t.x=e.x,t.y=e.y,e.trail.push(t)}}normalizeOrbSpeed(e){const t=this.clampVelocity(e.vx,e.vy);e.vx=t.vx,e.vy=t.vy}clampVelocity(e,t){const s=Math.hypot(e,t);if(s<1e-5)return{vx:0,vy:y.MIN_ORB_SPEED};if(s<y.MIN_ORB_SPEED){const i=y.MIN_ORB_SPEED/s;return{vx:e*i,vy:t*i}}if(s>y.MAX_ORB_SPEED){const i=y.MAX_ORB_SPEED/s;return{vx:e*i,vy:t*i}}return{vx:e,vy:t}}enforceWallBounds(e){e.x-e.radius<0?(e.x=e.radius,e.vx<0&&(e.vx=Math.abs(e.vx))):e.x+e.radius>y.SHAFT_WIDTH&&(e.x=y.SHAFT_WIDTH-e.radius,e.vx>0&&(e.vx=-Math.abs(e.vx))),e.y-e.radius<0&&(e.y=e.radius,e.vy<0&&(e.vy=Math.abs(e.vy)))}resolveWallCollisions(e){let t=!1;e.x-e.radius<0?(e.x=e.radius,e.vx=Math.abs(e.vx)*y.RESTITUTION_BLOCK,t=!0):e.x+e.radius>y.SHAFT_WIDTH&&(e.x=y.SHAFT_WIDTH-e.radius,e.vx=-Math.abs(e.vx)*y.RESTITUTION_BLOCK,t=!0),e.y-e.radius<0&&(e.y=e.radius,e.vy=Math.abs(e.vy)*y.RESTITUTION_BLOCK,t=!0),t&&(this.normalizeOrbSpeed(e),W.onWallBounce(e),e.bouncesLeft-=y.WALL_BOUNCE_COST,this.events.onWallHit?.(e,e.x,e.y),e.bouncesLeft<=0&&(e.bouncesLeft=0,e.alive=!1,this.events.onOrbExpired?.(e)))}resolveEntityCollisions(e,t,s,i,a,n,r,d,l,o){const h=e.radius+Math.hypot(e.x-t,e.y-s)+6,m=this.grid.queryCircle(e.x,e.y,h);for(let p=0;p<m.length;p++){const u=m[p];if(!u.alive||!e.alive||u.kind==="portal_exit")continue;if(u.kind==="bumper"||u.kind==="portal_entry"){const C=u.x+u.width*.5,B=u.y+u.height*.5,P=e.radius+u.radius,U=this.segmentCircleHit(t,s,e.x,e.y,C,B,P),w=e.x-C,T=e.y-B,L=w*w+T*T;if(L<P*P||U){if(u.kind==="portal_entry"){this.handlePortalEntry(e,u,n);continue}const K=Math.max(.001,Math.sqrt(L)),j=L>1e-6?w/K:0,z=L>1e-6?T/K:-1;e.x=C+j*(P+.5),e.y=B+z*(P+.5);const oe=e.vx*j+e.vy*z;oe<0&&(e.vx-=2*oe*j,e.vy-=2*oe*z),e.vx*=y.RESTITUTION_BUMPER,e.vy*=y.RESTITUTION_BUMPER,this.normalizeOrbSpeed(e),e.bouncesLeft=Math.min(e.maxBounces+6,e.bouncesLeft+y.BUMPER_BOUNCE_BONUS),e.comboCount++,W.onBlockHit(e);const ke=$e(u.depthMeters,"bumper",r,l,o);u.hitFlashTimer=.08,typeof u.hitsRemaining=="number"&&(u.hitsRemaining--,u.hitsRemaining<=0&&(u.alive=!1)),this.events.onBumperHit?.(e,u,ke);continue}continue}let b=F(e.x,u.x,u.x+u.width),_=F(e.y,u.y,u.y+u.height),v=e.x-b,k=e.y-_,R=v*v+k*k;if(R>=e.radius*e.radius){const C=(t+e.x)*.5,B=(s+e.y)*.5,P=F(C,u.x,u.x+u.width),U=F(B,u.y,u.y+u.height),w=C-P,T=B-U,L=w*w+T*T;if(L>=e.radius*e.radius)continue;e.x=C,e.y=B,b=P,_=U,v=w,k=T,R=L}let M=0,A=0;if(R>1e-6){const C=Math.sqrt(R);M=v/C,A=k/C}else{const C=e.x-u.x,B=u.x+u.width-e.x,P=e.y-u.y,U=u.y+u.height-e.y,w=Math.min(C,B,P,U);w===C?M=-1:w===B?M=1:w===P?A=-1:A=1}const E=Number.isFinite(u.hp)&&e.damage>=y.CLEAVE_RATIO*u.hp;if(!E){const C=e.radius-Math.sqrt(Math.max(0,R));e.x+=M*(C+.6),e.y+=A*(C+.6);const B=e.vx*M+e.vy*A;B<0&&(e.vx=(e.vx-2*B*M)*y.RESTITUTION_BLOCK,e.vy=(e.vy-2*B*A)*y.RESTITUTION_BLOCK,this.normalizeOrbSpeed(e)),e.bouncesLeft-=y.BLOCK_BOUNCE_COST}e.comboCount++,u.kind==="boss_armor"?W.onIndestructibleHit(e):W.onBlockHit(e),this.applyHitToBlock(e,u,M,i,a,n,r,d,l,o,E),!E&&e.bouncesLeft<=0&&(e.bouncesLeft=0,e.alive=!1,this.events.onOrbExpired?.(e))}}segmentCircleHit(e,t,s,i,a,n,r){const d=s-e,l=i-t,o=d*d+l*l;if(o<=1e-6)return!1;const h=F(((a-e)*d+(n-t)*l)/o,0,1),m=e+d*h,p=t+l*h,u=m-a,b=p-n;return u*u+b*b<r*r}handlePortalEntry(e,t,s){if(e.portalCooldown>0)return;let i;for(let r=0;r<s.length;r++){const d=s[r];if(d.id===t.portalTargetId&&d.alive){i=d;break}}if(!i)return;e.x=i.x+i.width*.5,e.y=i.y+i.height*.5+e.radius+6,this.grid.isCellOccupied(i.col,i.row+1,s)&&(e.y=i.y+i.height*.5),e.portalCooldown=y.PORTAL_COOLDOWN_S,e.bouncesLeft=Math.min(e.maxBounces+6,e.bouncesLeft+y.PORTAL_BONUS_BOUNCES);const a=Math.min(y.MAX_ORB_SPEED,Math.hypot(e.vx,e.vy)*y.PORTAL_SPEED_BOOST),n=F(Math.atan2(Math.abs(e.vy)+120,e.vx),.35,Math.PI-.35);e.vx=Math.cos(n)*a,e.vy=Math.sin(n)*a,e.trail.length=0,e.trailPool[0].x=e.x,e.trailPool[0].y=e.y,e.trail.push(e.trailPool[0]),W.onBlockHit(e),this.events.onPortalWarp?.(e,t,i)}applyHitToBlock(e,t,s,i,a,n,r,d,l,o,h){if(t.hitFlashTimer=.045,t.kind==="boss_armor"){let u=null,b=Number.POSITIVE_INFINITY;for(let _=0;_<n.length;_++){const v=n[_];if(v.alive&&v.kind==="boss_core"&&v.row===t.row){const k=Math.abs(v.col-t.col);k<b&&(b=k,u=v)}}if(u){const _=e.damage*y.BOSS_ARMOR_SPLASH_RATIO;this.damageBlockDirect(u,_,n,r,d,l,o,e.damage)}this.events.onBlockHit?.(e,t,0,!1);return}if(t.kind==="frost"&&t.hp>e.damage){const u=s>=0?-1:1,b=t.col+u;this.grid.isCellOccupied(b,t.row,n)||(t.renderX=t.renderX??t.x,t.col=b,t.x=b*y.TILE_SIZE+2,this.grid.rebuild(n))}if(t.kind==="splitter"&&i+a.length<y.MAX_ACTIVE_ORBS&&e.bouncesLeft>=2){const b=Math.atan2(e.vy,-e.vx),_=this.createOrb(e.x,e.y,b,e.radius*.9,Math.max(2,Math.floor(e.bouncesLeft*.5)),e.damage*.85,!0,e.isOverdrive);a.push(_)}this.events.onBlockHit?.(e,t,e.damage,h);const m=t.biomeIndex>=1?.38:.5,p=t.kind==="granite"&&!h?e.damage*m:e.damage;this.damageBlockDirect(t,p,n,r,d,l,o,e.damage)}damageBlockDirect(e,t,s,i,a,n,r,d){if(!e.alive||!Number.isFinite(e.hp)||(e.hp-=t,e.hitFlashTimer=.045,e.kind==="boss_core"&&this.events.onBossCoreDamaged?.(e.biomeIndex,e.bossCoreIndex??0,Math.max(0,e.hp),e.maxHp),e.hp>0))return;e.hp=0,e.alive=!1;const l=$e(e.depthMeters,e.kind,i,n,r),o=e.kind==="tnt",h=e.kind==="vault";if(this.events.onBlockDestroyed?.(e,l,o,h),o){const m=e.x+e.width*.5,p=e.y+e.height*.5,u=Gt(a);this.events.onTntExplode?.(m,p,u);const b=d*Lt;for(let _=0;_<s.length;_++){const v=s[_];if(!v.alive||v.id===e.id||!Number.isFinite(v.hp))continue;const k=v.x+v.width*.5,R=v.y+v.height*.5;if(Math.hypot(k-m,R-p)<=u+v.width*.4){const M=v.kind==="granite"?b*1.25:b;this.damageBlockDirect(v,M,s,i,a,n,r,d)}}}else if(e.kind==="laser"){const m=e.y+e.height*.5;this.events.onLaserFire?.(m,e.biomeIndex);const p=d*Ot;for(let u=0;u<s.length;u++){const b=s[u];!b.alive||b.id===e.id||b.row!==e.row||Number.isFinite(b.hp)&&this.damageBlockDirect(b,p,s,i,a,n,r,d)}}else if(e.kind==="boss_core"){let m=!1;for(let p=0;p<s.length;p++){const u=s[p];if(u.alive&&u.kind==="boss_core"&&u.row===e.row){m=!0;break}}if(!m){for(let p=0;p<s.length;p++){const u=s[p];u.alive&&u.kind==="boss_armor"&&u.row===e.row&&(u.alive=!1)}this.events.onBossGateBroken?.(e.biomeIndex,e.row)}}}computeTrajectoryPreview(e,t,s,i,a,n=2){let r=null,d=null,l=null,o=null,h=e,m=t,p=Math.cos(s)*y.LAUNCH_SPEED,u=Math.sin(s)*y.LAUNCH_SPEED,b=0;const _=[{x:h,y:m,segment:0}];let v=-1;const k=1/120,R=96,M=(w,T,L=null)=>{b===0?(r={x:w,y:T},l=L,v=Math.max(0,_.length-1)):b===1&&(d={x:w,y:T},o=L),b++};for(let w=0;w<R&&b<n;w++){u+=y.GRAVITY*k;const T=this.clampVelocity(p,u);p=T.vx,u=T.vy;const L=p*k,K=u*k,j=Math.hypot(L,K),z=Math.max(1,Math.ceil(j/Math.max(2,i*.35))),oe=k/z;for(let ke=0;ke<z&&b<n;ke++){const _t=h,vt=m;h+=p*oe,m+=u*oe;let Ae=!1;if(h-i<0){h=i,p=Math.abs(p)*y.RESTITUTION_BLOCK;const H=this.clampVelocity(p,u);p=H.vx,u=H.vy,_.push({x:h,y:m,segment:b}),M(0,m),Ae=!0}else if(h+i>y.SHAFT_WIDTH){h=y.SHAFT_WIDTH-i,p=-Math.abs(p)*y.RESTITUTION_BLOCK;const H=this.clampVelocity(p,u);p=H.vx,u=H.vy,_.push({x:h,y:m,segment:b}),M(y.SHAFT_WIDTH,m),Ae=!0}if(Ae){if(b>=n)break;continue}let $=null,se=0,ie=0,le=h,ce=m;for(let H=0;H<a.length;H++){const I=a[H];if(!(!I.alive||I.kind==="portal_exit"))if(I.kind==="bumper"||I.kind==="portal_entry"){const J=I.x+I.width*.5,te=I.y+I.height*.5,Y=i+I.radius,q=h-J,ge=m-te;if(q*q+ge*ge<Y*Y||this.segmentCircleHit(_t,vt,h,m,J,te,Y)){const de=Math.max(.001,Math.hypot(q,ge));$=I,se=q/de,ie=ge/de,le=J+se*I.radius,ce=te+ie*I.radius;break}}else{const J=F(h,I.x,I.x+I.width),te=F(m,I.y,I.y+I.height),Y=h-J,q=m-te;if(Y*Y+q*q<i*i){const de=Math.hypot(Y,q);let he=0,ue=-1;if(de>1e-4)he=Y/de,ue=q/de;else{const Oe=Math.abs(h-I.x),Pe=Math.abs(I.x+I.width-h),Ue=Math.abs(m-I.y),kt=Math.abs(I.y+I.height-m),Ee=Math.min(Oe,Pe,Ue,kt);Ee===Oe?(he=-1,ue=0):Ee===Pe?(he=1,ue=0):Ee===Ue?(he=0,ue=-1):(he=0,ue=1)}$=I,se=he,ie=ue,le=J,ce=te;break}}}if($){if($.kind==="portal_entry"){_.push({x:le,y:ce,segment:b}),M(le,ce,$.id),b=n;break}if($.kind==="bumper"){const te=$.x+$.width*.5,Y=$.y+$.height*.5,q=i+$.radius+.5;h=te+se*q,m=Y+ie*q}else h=le+se*(i+.5),m=ce+ie*(i+.5);const H=p*se+u*ie,I=$.kind==="bumper"?y.RESTITUTION_BUMPER:y.RESTITUTION_BLOCK;H<0&&(p=(p-2*H*se)*I,u=(u-2*H*ie)*I);const J=this.clampVelocity(p,u);if(p=J.vx,u=J.vy,_.push({x:h,y:m,segment:b}),M(le,ce,$.id),b>=n)break}}b<n&&_.push({x:h,y:m,segment:b})}const A=y.TRAJECTORY_DOTS,E=[0];for(let w=1;w<_.length;w++)E.push(E[w-1]+Math.hypot(_[w].x-_[w-1].x,_[w].y-_[w-1].y));const C=E[E.length-1],B=[],P=v>0&&v<E.length?E[v]:C+1;let U=A;if(C<1)for(let w=0;w<A;w++)B.push({x:e,y:t});else{let w=1;for(let T=1;T<=A;T++){const L=C*T/A;for(;w<_.length-1&&E[w]<L;)w++;const K=E[w-1],j=E[w],z=j>K?F((L-K)/(j-K),0,1):1;B.push({x:_[w-1].x+(_[w].x-_[w-1].x)*z,y:_[w-1].y+(_[w].y-_[w-1].y)*z}),U===A&&L>P&&(U=T-1)}}return{dots:B,impactPoint:r,secondImpactPoint:d,impactBlockId:l,secondImpactBlockId:o,bounceStartIdx:U}}}const ye=48;class ds{constructor(){c(this,"pool",[]);c(this,"cursor",0);for(let e=0;e<ye;e++)this.pool.push({active:!1,x:0,y:0,vy:-55,text:"",color:"#fbbf24",scale:1,life:0,maxLife:.7})}spawn(e,t,s,i="#fbbf24",a=1){const n=this.pool[this.cursor];this.cursor=(this.cursor+1)%ye,n.active=!0,n.x=e+(Math.random()-.5)*14,n.y=t,n.vy=-65,n.text=s,n.color=i,n.scale=a,n.life=.75,n.maxLife=.75}update(e){for(let t=0;t<ye;t++){const s=this.pool[t];if(s.active){if(s.life-=e,s.life<=0){s.active=!1;continue}s.y+=s.vy*e,s.vy*=.96}}}render(e){e.textAlign="center",e.textBaseline="middle";for(let t=0;t<ye;t++){const s=this.pool[t];if(!s.active)continue;const i=1-s.life/s.maxLife,a=i<.16?.85+i/.16*.3:1.15-(i-.16)*.18,n=Math.min(1,s.life/s.maxLife*1.45);e.globalAlpha=n;const r=Math.round(16*s.scale*a);e.font=`700 ${r}px 'Lilita One', 'Fredoka', system-ui, sans-serif`,e.lineWidth=3.5,e.strokeStyle="rgba(24, 18, 16, 0.92)",e.strokeText(s.text,s.x,s.y),e.fillStyle=s.color,e.fillText(s.text,s.x,s.y)}e.globalAlpha=1}clear(){for(let e=0;e<ye;e++)this.pool[e].active=!1}}const be=16,_e=8;class hs{constructor(){c(this,"hitStopTimer",0);c(this,"shakeX",0);c(this,"shakeY",0);c(this,"shakeMagnitude",0);c(this,"vignetteAlpha",0);c(this,"zoomPulse",0);c(this,"shockwaves",[]);c(this,"shockwaveCursor",0);c(this,"laserBeams",[]);c(this,"laserCursor",0);c(this,"shakeOffset",{x:0,y:0});for(let e=0;e<be;e++)this.shockwaves.push({active:!1,x:0,y:0,maxRadius:60,life:0,maxLife:.28,color:"#fb923c"});for(let e=0;e<_e;e++)this.laserBeams.push({active:!1,y:0,life:0,maxLife:.22,color:"#facc15"})}triggerHitStop(e){this.hitStopTimer=Math.max(this.hitStopTimer,Math.min(.055,e))}triggerShake(e){this.shakeMagnitude=Math.min(9,Math.max(this.shakeMagnitude,e))}triggerVignette(e=.35){this.vignetteAlpha=Math.max(this.vignetteAlpha,Math.min(.6,e)),this.zoomPulse=Math.max(this.zoomPulse,Math.min(.018,e*.04))}addShockwave(e,t,s,i="#fb923c"){const a=this.shockwaves[this.shockwaveCursor];this.shockwaveCursor=(this.shockwaveCursor+1)%be,a.active=!0,a.x=e,a.y=t,a.maxRadius=s,a.life=.28,a.maxLife=.28,a.color=i}addLaserBeam(e,t="#facc15"){const s=this.laserBeams[this.laserCursor];this.laserCursor=(this.laserCursor+1)%_e,s.active=!0,s.y=e,s.life=.22,s.maxLife=.22,s.color=t}consumeHitStop(e){return this.hitStopTimer>0?(this.hitStopTimer=Math.max(0,this.hitStopTimer-e),!0):!1}update(e){if(this.shakeMagnitude>.1){const t=Math.random()*Math.PI*2;this.shakeX=Math.cos(t)*this.shakeMagnitude,this.shakeY=Math.sin(t)*this.shakeMagnitude,this.shakeMagnitude*=Math.pow(.001,e)}else this.shakeMagnitude=0,this.shakeX=0,this.shakeY=0;this.vignetteAlpha>0&&(this.vignetteAlpha=Math.max(0,this.vignetteAlpha-e*1.45)),this.zoomPulse>0&&(this.zoomPulse=Math.max(0,this.zoomPulse-e*.08));for(let t=0;t<be;t++){const s=this.shockwaves[t];s.active&&(s.life-=e,s.life<=0&&(s.active=!1))}for(let t=0;t<_e;t++){const s=this.laserBeams[t];s.active&&(s.life-=e,s.life<=0&&(s.active=!1))}}getShakeOffset(){return this.shakeOffset.x=this.shakeX,this.shakeOffset.y=this.shakeY,this.shakeOffset}getVignetteAlpha(){return this.vignetteAlpha}getZoomScale(){return 1+this.zoomPulse}renderWorldEffects(e,t){e.save(),e.globalCompositeOperation="lighter";for(let s=0;s<be;s++){const i=this.shockwaves[s];if(!i.active)continue;const a=1-i.life/i.maxLife,n=i.maxRadius*a;e.globalAlpha=(1-a)*.85,e.strokeStyle=i.color,e.lineWidth=4.5*(1-a)+1.5,e.beginPath(),e.arc(i.x,i.y,n,0,Math.PI*2),e.stroke()}for(let s=0;s<_e;s++){const i=this.laserBeams[s];if(!i.active)continue;const a=i.life/i.maxLife;e.globalAlpha=a*.92,e.fillStyle=i.color,e.fillRect(0,i.y-12*a,t,24*a),e.fillStyle="#ffffff",e.fillRect(0,i.y-3.5*a,t,7*a)}e.restore()}clear(){this.hitStopTimer=0,this.shakeMagnitude=0,this.shakeX=0,this.shakeY=0,this.vignetteAlpha=0,this.zoomPulse=0;for(let e=0;e<be;e++)this.shockwaves[e].active=!1;for(let e=0;e<_e;e++)this.laserBeams[e].active=!1}}const ae=480;class us{constructor(){c(this,"pool",[]);c(this,"cursor",0);for(let e=0;e<ae;e++)this.pool.push({active:!1,kind:"shard",additive:!1,x:0,y:0,vx:0,vy:0,size:3,rotation:0,vr:0,drag:.985,color:"#ffffff",alpha:1,life:0,maxLife:.4,gravity:300})}emitBurst(e,t,s,i,a=80,n=280,r=4,d=.45,l="shard",o=!1){for(let h=0;h<s;h++){const m=this.pool[this.cursor];this.cursor=(this.cursor+1)%ae;const p=Math.PI*2*h/Math.max(1,s)+(Math.random()-.5)*.6,u=a+Math.random()*(n-a);m.active=!0,m.kind=l,m.additive=o,m.x=e,m.y=t,m.vx=Math.cos(p)*u,m.vy=Math.sin(p)*u-(l==="smoke"?25:48),m.size=r*(.7+Math.random()*.65),m.rotation=Math.random()*Math.PI*2,m.vr=(Math.random()-.5)*14,m.drag=l==="smoke"?.92:l==="spark"?.96:.985,m.color=i,m.alpha=1,m.life=d*(.75+Math.random()*.45),m.maxLife=m.life,m.gravity=l==="smoke"?-45:l==="spark"?210:420}}emitSparks(e,t,s,i="#fde047"){this.emitBurst(e,t,s,i,140,420,3.2,.28,"spark",!0)}emitDirectionalBurst(e,t,s,i,a,n="#fde047",r=140,d=320,l=3.5,o=.24,h="spark",m=!0){for(let p=0;p<a;p++){const u=this.pool[this.cursor];this.cursor=(this.cursor+1)%ae;const b=a>1?p/(a-1)-.5:0,_=s+b*i+(Math.random()-.5)*.2,v=r+Math.random()*(d-r);u.active=!0,u.kind=h,u.additive=m,u.x=e,u.y=t,u.vx=Math.cos(_)*v,u.vy=Math.sin(_)*v,u.size=l*(.75+Math.random()*.5),u.rotation=_,u.vr=(Math.random()-.5)*10,u.drag=.95,u.color=n,u.alpha=1,u.life=o*(.8+Math.random()*.4),u.maxLife=u.life,u.gravity=180}}emitRockShards(e,t,s,i){this.emitBurst(e,t,s,i,80,290,5.2,.48,"shard",!1)}emitSmokePuff(e,t,s,i="#475569"){this.emitBurst(e,t,s,i,30,110,9.5,.55,"smoke",!1)}update(e){for(let t=0;t<ae;t++){const s=this.pool[t];if(!s.active)continue;if(s.life-=e,s.life<=0){s.active=!1;continue}const i=Math.pow(s.drag,e*60);s.vx*=i,s.vy=s.vy*i+s.gravity*e,s.x+=s.vx*e,s.y+=s.vy*e,s.rotation+=s.vr*e,s.alpha=Math.max(0,s.life/s.maxLife)}}render(e){e.save();for(let t=0;t<ae;t++){const s=this.pool[t];if(!(!s.active||s.additive))if(e.globalAlpha=s.kind==="smoke"?s.alpha*.45:s.alpha,e.fillStyle=s.color,s.kind==="smoke"){const i=1+(1-s.alpha)*1.1;e.beginPath(),e.arc(s.x,s.y,s.size*i,0,Math.PI*2),e.fill()}else{e.save(),e.translate(s.x,s.y),e.rotate(s.rotation);const i=s.size*.5;e.beginPath(),e.moveTo(-i,-i*.6),e.lineTo(i*.8,-i),e.lineTo(i,i*.7),e.lineTo(-i*.7,i),e.closePath(),e.fill(),e.strokeStyle="rgba(24, 18, 16, 0.6)",e.lineWidth=1,e.stroke(),e.restore()}}e.globalCompositeOperation="lighter";for(let t=0;t<ae;t++){const s=this.pool[t];if(!s.active||!s.additive)continue;e.globalAlpha=Math.min(1,s.alpha*1.15),e.strokeStyle=s.color,e.lineWidth=Math.max(1.5,s.size*.65),e.lineCap="round";const i=s.x-s.vx*.032,a=s.y-s.vy*.032;e.beginPath(),e.moveTo(i,a),e.lineTo(s.x,s.y),e.stroke()}e.restore()}clear(){for(let e=0;e<ae;e++)this.pool[e].active=!1}}const Ke=["","K","M","B","T","Qa","Qi"];function N(f){if(!Number.isFinite(f)||f<0)return"0";if(f<1e3)return Math.floor(f).toString();const e=Math.min(Math.floor(Math.log10(f)/3),Ke.length-1),t=f/Math.pow(1e3,e),s=t>=100?0:t>=10?1:2;return`${t.toFixed(s).replace(/\.0+$/,"").replace(/(\.\d*[1-9])0+$/,"$1")}${Ke[e]}`}function Le(f){return`${Math.floor(Math.max(0,f)).toLocaleString("en-US")}m`}function Se(f=Date.now()){return new Date(f).toISOString().slice(0,10)}class De{static getBiomeAtDepth(e){return ut(e)}static getBiomeByIndex(e){return O[Math.max(0,Math.min(O.length-1,e))]}}const ps=""+new URL("block_bedrock_core-CbaULw6l.webp",import.meta.url).href,ms=""+new URL("block_boss_armor-Kk-UaoIH.webp",import.meta.url).href,fs=""+new URL("block_frost-BKbLY_G6.webp",import.meta.url).href,gs=""+new URL("block_laser-CLXggfNW.webp",import.meta.url).href,ys=""+new URL("block_ore_gold-DJSEgpA0.webp",import.meta.url).href,bs=""+new URL("block_ore_molten-CxGFAYPT.webp",import.meta.url).href,_s=""+new URL("block_ore_nuggets-t3KjcRJB.webp",import.meta.url).href,vs=""+new URL("block_splitter-CqNqyxEP.webp",import.meta.url).href,ks=""+new URL("block_stone_granite-C0ZNjkiB.webp",import.meta.url).href,xs=""+new URL("block_stone_sand-DH9-xNal.webp",import.meta.url).href,ws=""+new URL("block_stone_slate-BjwV-_iw.webp",import.meta.url).href,Ss=""+new URL("block_tnt-C35s_eKg.webp",import.meta.url).href,Ms=""+new URL("block_vault-1HTuoLTG.webp",import.meta.url).href,Ts=""+new URL("env_rock_flank-DCmYRrMT.webp",import.meta.url).href,As=""+new URL("env_timber_beam-CdIXLAIa.webp",import.meta.url).href,je=""+new URL("logo_emblem-GMo4QHvg.webp",import.meta.url).href,Es=""+new URL("pickup_magnet_coil-6WbHYvGO.webp",import.meta.url).href,Cs=""+new URL("pickup_overclock_battery-BhVChCKb.webp",import.meta.url).href,Rs=""+new URL("pickup_split_gem-B0O352k4.webp",import.meta.url).href,Bs=""+new URL("prop_bumper_amber-BrMf-UkK.webp",import.meta.url).href,Is=""+new URL("prop_bumper_cyan-SBGwHDL4.webp",import.meta.url).href,Ds=""+new URL("prop_lantern-7HwfbphH.webp",import.meta.url).href,Ls=""+new URL("prop_portal-BGRqxIbi.webp",import.meta.url).href,Os=""+new URL("prop_portal_entry-BXqxT2lU.webp",import.meta.url).href,Ps=""+new URL("prop_portal_exit-oOhFZP_P.webp",import.meta.url).href,Us=""+new URL("prop_turret-Deh7Haz0.webp",import.meta.url).href,Ns=""+new URL("skin_copper_gear-ONekgUKm.webp",import.meta.url).href,Fs=""+new URL("skin_emerald_buzzsaw-FR8qhDFn.webp",import.meta.url).href,Vs=""+new URL("skin_frost_star-CQYvQZ_9.webp",import.meta.url).href,$s=""+new URL("skin_gold_chakram-BD4eInXc.webp",import.meta.url).href,Hs=""+new URL("skin_magma_cutter-CCjdGM0R.webp",import.meta.url).href,mt=""+new URL("skin_steel_sawblade-B7zZhMTD.webp",import.meta.url).href,Gs=""+new URL("skin_tesla_rotor-C_EGx_C_.webp",import.meta.url).href,qs=""+new URL("skin_toxic_drill-nq0XhCic.webp",import.meta.url).href,zs=""+new URL("skin_void_reaper-L4SDcbZ3.webp",import.meta.url).href,Ye={steel_sawblade:mt,copper_gear:Ns,emerald_buzzsaw:Fs,magma_cutter:Hs,frost_star:Vs,gold_chakram:$s,tesla_rotor:Gs,toxic_drill:qs,void_reaper:zs},Xe={0:{multiplyHex:"#ffffff",multiplyAlpha:0,glowAlpha:0},1:{multiplyHex:"#4f6ef7",multiplyAlpha:.42,glowAlpha:.08},2:{multiplyHex:"#9a3412",multiplyAlpha:.36,glowAlpha:.08},3:{multiplyHex:"#38bdf8",multiplyAlpha:.48,glowAlpha:.1},4:{multiplyHex:"#7e22ce",multiplyAlpha:.46,glowAlpha:.09},5:{multiplyHex:"#334155",multiplyAlpha:.5,glowAlpha:.07}};class Ws{constructor(){c(this,"images",new Map);c(this,"tintedCache",new Map);c(this,"loaded",!1)}getLogoEmblemUrl(){return je}getSkinThumbnailUrl(e){return Ye[e]??mt}async loadAll(){if(this.loaded||typeof Image>"u")return;const e=[["stone_slate",ws],["stone_sand",xs],["stone_granite",ks],["ore_nuggets",_s],["ore_gold",ys],["ore_molten",bs],["tnt",Ss],["frost",fs],["bedrock_core",ps],["vault",Ms],["splitter",vs],["laser",gs],["boss_armor",ms],["bumper_amber",Bs],["bumper_cyan",Is],["turret",Us],["lantern",Ds],["portal",Ls],["portal_entry",Os],["portal_exit",Ps],["pickup_split_gem",Rs],["pickup_magnet_coil",Es],["pickup_overclock_battery",Cs],["timber_beam",As],["rock_flank",Ts],["logo_emblem",je],...Object.entries(Ye).map(([t,s])=>[`skin:${t}`,s])];await Promise.all(e.map(([t,s])=>new Promise(i=>{const a=new Image;a.onload=()=>{this.images.set(t,a),i()},a.onerror=()=>i(),a.src=s}))),this.loaded=!0}getEnvTimberBeam(e){const t=this.images.get("timber_beam");return t?!e||e.index===0?t:this.getGraded(`beam:${e.index}`,t,e,.42,.04):null}getEnvRockFlank(e){const t=this.images.get("rock_flank");return t?e.index===0?t:this.getGraded(`flank:${e.index}`,t,e):null}getPropTurret(){return this.images.get("turret")??null}getPropLantern(){return this.images.get("lantern")??null}getPropPortal(e){return e===!0?this.images.get("portal_entry")??this.images.get("portal")??null:e===!1?this.images.get("portal_exit")??this.images.get("portal")??null:this.images.get("portal")??null}getPickupSprite(e){return this.images.get(`pickup_${e}`)??null}getPropBumper(e){return this.images.get(e?"bumper_amber":"bumper_cyan")??null}getPropSawblade(e){return this.images.get(`skin:${e.id}`)??this.images.get("skin:steel_sawblade")??null}getBlockSprite(e,t,s,i){const a=Math.abs(s*73856093^i*19349663)%3;let n="stone_slate",r=!0;switch(e){case"strata":n=a===0?"stone_slate":a===1?"stone_sand":"stone_granite";break;case"granite":n="stone_granite";break;case"boss_armor":n="boss_armor",r=!1;break;case"ore":n=a===0?"ore_nuggets":a===1?"ore_gold":"ore_molten";break;case"tnt":n="tnt",r=!1;break;case"frost":n="frost",r=!1;break;case"boss_core":n="bedrock_core",r=!1;break;case"splitter":n="splitter",r=!1;break;case"laser":n="laser",r=!1;break;case"vault":n="vault",r=!1;break;default:n="stone_slate"}const d=this.images.get(n);return d?!r||t.index===0?d:this.getGraded(`blk:${n}:${t.index}`,d,t):null}getGraded(e,t,s,i,a){const n=this.tintedCache.get(e);if(n)return n;if(typeof document>"u")return t;const r=t.naturalWidth||t.width,d=t.naturalHeight||t.height;if(!r||!d)return t;const l=document.createElement("canvas");l.width=r,l.height=d;const o=l.getContext("2d");if(!o)return t;const h=Xe[s.index]??Xe[0],m=i??h.multiplyAlpha,p=a??h.glowAlpha;return o.drawImage(t,0,0,r,d),m>0&&(o.globalCompositeOperation="multiply",o.globalAlpha=m,o.fillStyle=h.multiplyHex,o.fillRect(0,0,r,d)),p>0&&(o.globalCompositeOperation="lighter",o.globalAlpha=p,o.fillStyle=s.palette.glow,o.fillRect(0,0,r,d)),o.globalCompositeOperation="destination-in",o.globalAlpha=1,o.drawImage(t,0,0,r,d),o.globalCompositeOperation="source-over",this.tintedCache.set(e,l),l}}const ft=new Ws;class Ks{constructor(e){c(this,"ctx");c(this,"atlas",ft);c(this,"lastFrameMs",typeof performance<"u"?performance.now():Date.now());const t=e.getContext("2d",{alpha:!1});if(!t)throw new Error("Could not initialize 2D canvas context");this.ctx=t}async preloadAssets(){await this.atlas.loadAll()}getLogoEmblemUrl(){return this.atlas.getLogoEmblemUrl()}render(e,t){const s=typeof performance<"u"?performance.now():Date.now(),i=Math.min(.05,Math.max(.001,(s-this.lastFrameMs)*.001));this.lastFrameMs=s;const a=this.ctx,{cssWidth:n,cssHeight:r,dpr:d,scale:l,shaftX:o,topOffsetPx:h}=e,m=Math.round(t.cameraY*l)/l,p=t.baseDepthMeters+m/y.TILE_SIZE*y.METERS_PER_ROW,u=De.getBiomeAtDepth(p);a.save(),a.scale(d,d),a.imageSmoothingEnabled=!0,a.imageSmoothingQuality="high",this.renderRockFlanks(a,n,r,o,e.shaftWidthPx,m,t.baseDepthMeters,l,u,e.isPortrait,h);const b=t.juice.getShakeOffset(),_=t.juice.getZoomScale(),v=26*l,k=m-h/l,R=r/l+h/l;if(a.save(),a.beginPath(),a.rect(o-v,0,e.shaftWidthPx+v*2,r),a.clip(),_!==1){const w=o+e.shaftWidthPx*.5,T=h+(r-h)*.42;a.translate(w,T),a.scale(_,_),a.translate(-w,-T)}a.translate(o+b.x*l,h+b.y*l),a.scale(l,l),a.translate(0,-m),this.renderShaftInterior(a,k,R,u,t.timeS);const M=k-90,A=m+r/l+90;for(let w=0;w<t.entities.length;w++){const T=t.entities[w];T.alive&&(T.y+T.height<M||T.y>A||this.renderEntity(a,T,u,t.timeS,i))}t.aimAngleRad!==null&&(t.targetedBlockId||t.secondTargetedBlockId)&&this.renderTargetHighlights(a,t.entities,t.targetedBlockId??null,t.secondTargetedBlockId??null,t.timeS),t.aimAngleRad!==null&&t.trajectoryDots.length>0&&this.renderTrajectory(a,t.trajectoryDots,t.trajectoryImpact,t.trajectorySecondImpact??null,t.trajectoryBounceIdx??t.trajectoryDots.length,t.timeS),this.renderLauncher(a,t.launcherX,t.launcherY,t.aimAngleRad,t.turretRecoil??0,!!t.isAimingState,t.skin,t.loadedOrbRadius??14,t.loadedOrbCount??1,t.timeS),t.aimFeedback&&this.renderAimFeedback(a,t.aimFeedback,t.timeS);for(let w=0;w<t.coins.length;w++){const T=t.coins[w];if(!T.alive)continue;const L=t.timeS*8.5+w*1.17,K=Math.max(.24,Math.abs(Math.cos(L)));if(a.save(),T.magnetized){const j=T.x-T.vx*.035,z=T.y-T.vy*.035;a.strokeStyle="rgba(253, 224, 71, 0.55)",a.lineWidth=4,a.lineCap="round",a.beginPath(),a.moveTo(j,z),a.lineTo(T.x,T.y),a.stroke()}a.fillStyle="rgba(251, 191, 36, 0.25)",a.beginPath(),a.arc(T.x,T.y,10.5,0,Math.PI*2),a.fill(),a.translate(T.x,T.y),a.scale(K,1),a.fillStyle="#f59e0b",a.beginPath(),a.arc(0,0,7.2,0,Math.PI*2),a.fill(),a.strokeStyle="#181210",a.lineWidth=2,a.stroke(),a.fillStyle="#fde047",a.beginPath(),a.arc(-.5,-.5,4.6,0,Math.PI*2),a.fill(),a.fillStyle="#fffbeb",a.fillRect(-1.1,-3,2.2,6),a.restore()}for(let w=0;w<t.orbs.length;w++){const T=t.orbs[w];T.alive&&this.renderOrb(a,T,t.skin)}t.juice.renderWorldEffects(a,y.SHAFT_WIDTH),t.particles.render(a),t.floatingText.render(a),this.renderTimberShaftFrame(a,k,R,u,t.timeS),a.restore();const E=t.juice.getVignetteAlpha(),C=n*.5,B=r*.5,P=Math.hypot(C,B),U=a.createRadialGradient(C,B,P*.52,C,B,P);U.addColorStop(0,"rgba(0, 0, 0, 0)"),U.addColorStop(.82,"rgba(8, 6, 5, 0.22)"),U.addColorStop(1,E>.01?`rgba(249, 115, 22, ${Math.min(.45,E*1.15).toFixed(2)})`:"rgba(8, 6, 5, 0.52)"),a.fillStyle=U,a.fillRect(0,0,n,r),a.restore()}renderRockFlanks(e,t,s,i,a,n,r,d,l,o,h){if(e.fillStyle=l.index===0?"#16110e":l.palette.bgBottom,e.fillRect(0,0,t,s),o)return;const m=i+a,p=t-m,u=this.atlas.getEnvRockFlank(l);if(u){const v=Math.max(i,p,320),k=u.width||512,R=u.height||768,M=Math.round(R/k*v),A=n*.65*d%M;e.save(),e.beginPath(),e.rect(0,0,i,s),e.clip();for(let E=-A-M;E<s+M;E+=M)e.drawImage(u,i-v,E,v,M+1);e.restore(),e.save(),e.beginPath(),e.rect(m,0,p,s),e.clip(),e.translate(m+v,0),e.scale(-1,1);for(let E=-A-M;E<s+M;E+=M)e.drawImage(u,0,E,v,M+1);e.restore()}const b=e.createLinearGradient(0,0,i,0);b.addColorStop(0,"rgba(6, 5, 4, 0.72)"),b.addColorStop(.75,"rgba(6, 5, 4, 0.22)"),b.addColorStop(1,"rgba(6, 5, 4, 0.05)"),e.fillStyle=b,e.fillRect(0,0,i,s);const _=e.createLinearGradient(m,0,t,0);_.addColorStop(0,"rgba(6, 5, 4, 0.05)"),_.addColorStop(.25,"rgba(6, 5, 4, 0.22)"),_.addColorStop(1,"rgba(6, 5, 4, 0.72)"),e.fillStyle=_,e.fillRect(m,0,p,s),this.renderDepthRuler(e,s,n,r,d,h)}renderDepthRuler(e,t,s,i,a,n){const r=y.TILE_SIZE/y.METERS_PER_ROW,d=Math.max(0,Math.floor((i+s/r)/10)*10),l=d+Math.ceil(t/(r*a*10))*10+10;e.save(),e.font='700 12px "Lilita One", "Fredoka", system-ui, sans-serif',e.textAlign="left",e.textBaseline="middle";for(let o=d;o<=l;o+=5){const h=(o-i)*r,m=n+(h-s)*a;if(m<Math.max(58,n+20)||m>t-16)continue;const p=o%10===0;e.fillStyle=p?"#fde68a":"rgba(226, 232, 240, 0.55)",e.fillRect(0,m-1,p?14:7,2),p&&o>0&&(e.strokeStyle="#181210",e.lineWidth=3.5,e.strokeText(`${o}m`,18,m),e.fillText(`${o}m`,18,m))}e.restore()}renderShaftInterior(e,t,s,i,a){e.fillStyle=i.index===0?"#1e1612":i.palette.bgBottom,e.fillRect(0,t,y.SHAFT_WIDTH,s),e.save();for(let l=0;l<3;l++){const o=70+l*165+Math.sin(a*.4+l)*12,h=e.createLinearGradient(o,t,o+90,t+s*.75);h.addColorStop(0,this.hexToRgba(i.palette.glow,.14)),h.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=h,e.beginPath(),e.moveTo(o-30,t),e.lineTo(o+42,t),e.lineTo(o+150,t+s),e.lineTo(o+40,t+s),e.closePath(),e.fill()}e.restore();const n=y.TILE_SIZE,r=Math.floor(t/n)*n,d=t+s+n;e.save(),e.strokeStyle="#ffffff",e.globalAlpha=.04,e.lineWidth=1;for(let l=n;l<y.SHAFT_WIDTH;l+=n)e.beginPath(),e.moveTo(l,r),e.lineTo(l,d),e.stroke();for(let l=r;l<=d;l+=n)e.beginPath(),e.moveTo(0,l),e.lineTo(y.SHAFT_WIDTH,l),e.stroke();for(let l=0;l<18;l++){const o=((l*89+Math.sin(a*.7+l)*20)%y.SHAFT_WIDTH+y.SHAFT_WIDTH)%y.SHAFT_WIDTH,h=t+((l*67+a*(10+l%4*3))%s+s)%s;e.globalAlpha=.28+.25*Math.sin(a*2+l),e.fillStyle=i.palette.glow,e.beginPath(),e.arc(o,h,1.6,0,Math.PI*2),e.fill()}e.restore()}renderTimberShaftFrame(e,t,s,i,a){const r=this.atlas.getEnvTimberBeam(i);if(e.save(),r){const h=r.width||128,m=r.height||512,p=Math.round(m/h*24),u=Math.floor((t-20)/p)*p,b=t+s+p;for(let _=u;_<b;_+=p)e.drawImage(r,-24,_,24,p+1),e.drawImage(r,y.SHAFT_WIDTH,_,24,p+1)}else e.fillStyle="#6b3e1e",e.fillRect(-24,t-20,24,s+40),e.fillRect(y.SHAFT_WIDTH,t-20,24,s+40);const d=y.TILE_SIZE*5,l=Math.floor(t/d)*d+120,o=this.atlas.getPropLantern();for(let h=l;h<t+s+d;h+=d){const m=.85+.15*Math.sin(a*11+h),p=Math.sin(a*2.4+h*.01)*.035;for(const u of[-24*.5,y.SHAFT_WIDTH+24*.5]){e.save(),e.globalCompositeOperation="lighter";const b=e.createRadialGradient(u,h+16,2,u,h+16,86*m);if(b.addColorStop(0,this.hexToRgba(i.palette.glow,.3*m)),b.addColorStop(1,"rgba(0,0,0,0)"),e.fillStyle=b,e.beginPath(),e.arc(u,h+16,86*m,0,Math.PI*2),e.fill(),e.restore(),e.strokeStyle="#181210",e.lineWidth=3,e.beginPath(),e.moveTo(u,h-4),e.lineTo(u,h+2),e.stroke(),o){e.save(),e.translate(u,h),e.rotate(p);const _=(o.width||100)/(o.height||160),v=Math.min(20,30*_),k=v/_;e.drawImage(o,-v*.5,0,v,k),e.restore()}}}e.restore()}renderTrajectory(e,t,s,i,a,n){const r=n*5%1;for(let d=0;d<t.length;d++){const l=t[d],o=d>=a,h=(o?.62:1)*(1-d/(t.length+3))*(.78+.22*Math.sin((d-r)*1.4));e.fillStyle=o?`rgba(56, 189, 248, ${h.toFixed(2)})`:`rgba(255, 224, 102, ${h.toFixed(2)})`,e.beginPath(),e.arc(l.x,l.y,Math.max(1.8,(o?3.5:4.6)-d*.14),0,Math.PI*2),e.fill()}if(s){e.save();const d=8.5+Math.sin(n*8)*1.8;e.strokeStyle="rgba(255, 216, 77, 0.95)",e.lineWidth=2.5,e.beginPath(),e.arc(s.x,s.y,d,0,Math.PI*2),e.stroke(),e.fillStyle="rgba(255, 216, 77, 0.35)",e.beginPath(),e.arc(s.x,s.y,3.5,0,Math.PI*2),e.fill(),e.restore()}i&&(e.save(),e.strokeStyle="rgba(56, 189, 248, 0.8)",e.lineWidth=2,e.beginPath(),e.arc(i.x,i.y,6.5,0,Math.PI*2),e.stroke(),e.restore())}renderLauncher(e,t,s,i,a,n,r,d,l,o){const h=i??Math.PI*.5,m=t-Math.cos(h)*a*6,u=s-Math.sin(h)*a*6+y.MUZZLE_PIVOT_OFFSET_Y;if(n){const v=Ie(t,s,h),k=Math.min(18,d);e.save(),e.fillStyle="rgba(251, 191, 36, 0.24)",e.beginPath(),e.arc(v.x,v.y,k+4,0,Math.PI*2),e.fill();const R=this.atlas.getPropSawblade(r);if(e.translate(v.x,v.y),e.rotate(o*4.5),R?e.drawImage(R,-k,-k,k*2,k*2):(e.fillStyle=r.primaryColor,e.beginPath(),e.arc(0,0,k,0,Math.PI*2),e.fill()),e.restore(),i===null){e.save();for(let M=0;M<3;M++){const A=v.y+20+M*16,E=.28+.24*Math.sin(o*5-M*.9);e.strokeStyle=`rgba(255, 224, 102, ${E.toFixed(2)})`,e.lineWidth=2.2,e.beginPath(),e.moveTo(v.x-6,A-4),e.lineTo(v.x,A+2),e.lineTo(v.x+6,A-4),e.stroke()}e.restore()}}e.save();const b=e.createLinearGradient(0,s-42,0,s-24);b.addColorStop(0,"#475569"),b.addColorStop(1,"#1e293b"),e.fillStyle=b,e.fillRect(0,s-42,y.SHAFT_WIDTH,16),e.strokeStyle="#181210",e.lineWidth=2.5,e.strokeRect(0,s-42,y.SHAFT_WIDTH,16);for(let v=24;v<y.SHAFT_WIDTH;v+=48)e.fillStyle="#94a3b8",e.beginPath(),e.arc(v,s-34,2.2,0,Math.PI*2),e.fill();const _=this.atlas.getPropTurret();if(e.translate(m,u),e.rotate(h-Math.PI*.5),_){const k=(_.width||180)/(_.height||220)*66;e.drawImage(_,-k*.5,0,k,66)}else e.fillStyle="#d97706",e.strokeStyle="#181210",e.lineWidth=2.5,e.fillRect(-14,0,28,34),e.strokeRect(-14,0,28,34);if(e.restore(),n&&l>1){const v=t+44,k=s+8;e.save(),e.fillStyle="rgba(24, 18, 16, 0.88)",e.strokeStyle="#fbbf24",e.lineWidth=2,e.beginPath(),e.roundRect(v-18,k-11,36,22,8),e.fill(),e.stroke(),e.fillStyle="#fde047",e.font="900 12px system-ui, sans-serif",e.textAlign="center",e.textBaseline="middle",e.fillText(`x${l}`,v,k+1),e.restore()}}renderTargetHighlights(e,t,s,i,a){const n=.55+.45*Math.sin(a*10);for(let r=0;r<t.length;r++){const d=t[r];if(!d.alive)continue;const l=d.id===s,o=!l&&d.id===i;if(!(!l&&!o)){if(e.save(),d.kind==="bumper"||d.kind==="portal_entry"){const h=d.x+d.width*.5,m=d.y+d.height*.5;e.strokeStyle=l?`rgba(253, 224, 71, ${(.65+.35*n).toFixed(2)})`:"rgba(56, 189, 248, 0.72)",e.lineWidth=l?3:2,e.beginPath(),e.arc(h,m,d.radius+4+(l?n*2:0),0,Math.PI*2),e.stroke()}else{const h=l?2+n*1.5:1.5;e.strokeStyle=l?`rgba(253, 224, 71, ${(.72+.28*n).toFixed(2)})`:"rgba(56, 189, 248, 0.65)",e.fillStyle=l?`rgba(253, 224, 71, ${(.1+.1*n).toFixed(2)})`:"rgba(56, 189, 248, 0.08)",e.lineWidth=l?3:2,l||e.setLineDash([5,4]),e.fillRect(d.x-h,d.y-h,d.width+h*2,d.height+h*2),e.strokeRect(d.x-h,d.y-h,d.width+h*2,d.height+h*2)}e.restore()}}}renderAimFeedback(e,t,s){if(t.dragging){if(e.save(),t.mode==="slingshot"){const i=t.canceled?"rgba(248, 113, 113, 0.9)":"rgba(255, 224, 102, 0.72)";if(e.strokeStyle=i,e.lineWidth=2.2,e.setLineDash([5,4]),e.beginPath(),e.arc(t.originWorld.x,t.originWorld.y,t.deadzoneWorldRadius,0,Math.PI*2),e.stroke(),e.setLineDash([]),t.canceled){const a=t.originWorld.x,n=t.originWorld.y;e.strokeStyle="#f87171",e.lineWidth=2.8,e.beginPath(),e.moveTo(a-6,n-6),e.lineTo(a+6,n+6),e.moveTo(a+6,n-6),e.lineTo(a-6,n+6),e.stroke()}else{e.strokeStyle="rgba(251, 191, 36, 0.65)",e.lineWidth=2.5,e.beginPath(),e.moveTo(t.originWorld.x,t.originWorld.y),e.lineTo(t.currentWorld.x,t.currentWorld.y),e.stroke();const a=6+Math.sin(s*8)*.8;e.fillStyle="#fde047",e.strokeStyle="#181210",e.lineWidth=2,e.beginPath(),e.arc(t.currentWorld.x,t.currentWorld.y,a,0,Math.PI*2),e.fill(),e.stroke()}}else if(t.canceled){const i=t.currentWorld.x,a=t.currentWorld.y;e.strokeStyle="#f87171",e.lineWidth=2.4,e.beginPath(),e.arc(i,a,16,0,Math.PI*2),e.moveTo(i-5,a-5),e.lineTo(i+5,a+5),e.moveTo(i+5,a-5),e.lineTo(i-5,a+5),e.stroke()}e.restore()}}renderEntity(e,t,s,i,a){const n=t.x,r=t.renderX??n,d=Math.abs(n-r)<.4?n:r+(n-r)*Math.min(1,a*24);t.renderX=d;const l=d,o=l+t.width*.5,h=t.y+t.height*.5;if(t.kind==="portal_entry"||t.kind==="portal_exit"){e.save();const p=t.kind==="portal_entry",u=this.atlas.getPropPortal(p);e.translate(o,h);const b=1+Math.sin(i*4.5+t.id)*.08;e.save(),e.globalCompositeOperation="lighter";const _=e.createRadialGradient(0,0,t.radius*.2,0,0,t.radius*1.45*b);if(_.addColorStop(0,p?"rgba(34, 211, 238, 0.55)":"rgba(251, 146, 60, 0.55)"),_.addColorStop(1,"rgba(0, 0, 0, 0)"),e.fillStyle=_,e.beginPath(),e.arc(0,0,t.radius*1.45*b,0,Math.PI*2),e.fill(),e.restore(),e.rotate(i*(p?2.4:-2.4)),u){const v=t.radius*2.55;e.drawImage(u,-v*.5,-v*.5,v,v)}else e.strokeStyle=p?"#28e0d8":"#fb923c",e.lineWidth=3,e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.stroke();e.restore();return}if(t.kind==="bumper"){e.save();const p=t.id%2===0,u=this.atlas.getPropBumper(p),b=t.hitFlashTimer>0?1.22:1+Math.sin(i*5+t.id)*.03;if(e.translate(o,h),e.scale(b,b),u){const _=t.radius*2.45;e.drawImage(u,-_*.5,-_*.5,_,_)}else e.fillStyle="#d97706",e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.fill();t.hitFlashTimer>0&&(e.strokeStyle="#ffffff",e.lineWidth=3,e.beginPath(),e.arc(0,0,t.radius*1.15,0,Math.PI*2),e.stroke()),e.restore();return}const m=this.atlas.getBlockSprite(t.kind,s,t.col,t.row);if(e.save(),t.kind==="boss_core"){const p=.55+.35*Math.sin(i*5+t.id);e.save(),e.globalCompositeOperation="lighter";const u=e.createRadialGradient(o,h,4,o,h,t.width*.78);u.addColorStop(0,`rgba(251, 146, 60, ${(.55*p).toFixed(2)})`),u.addColorStop(.6,`rgba(244, 63, 94, ${(.28*p).toFixed(2)})`),u.addColorStop(1,"rgba(0, 0, 0, 0)"),e.fillStyle=u,e.beginPath(),e.arc(o,h,t.width*.78,0,Math.PI*2),e.fill(),e.restore()}else if(t.kind==="vault"){e.save(),e.globalCompositeOperation="lighter";const p=e.createRadialGradient(o,h,4,o,h,t.width*.7);p.addColorStop(0,"rgba(250, 204, 21, 0.32)"),p.addColorStop(1,"rgba(0, 0, 0, 0)"),e.fillStyle=p,e.beginPath(),e.arc(o,h,t.width*.7,0,Math.PI*2),e.fill(),e.restore()}if(m?e.drawImage(m,l,t.y,t.width,t.height):(e.fillStyle=s.palette.strataFill,e.fillRect(l,t.y,t.width,t.height)),t.kind==="laser"){const p=.55+.45*Math.sin(i*8+t.id);e.save(),e.globalCompositeOperation="lighter",e.fillStyle=`rgba(253, 224, 71, ${(.65*p).toFixed(2)})`,e.beginPath(),e.arc(l+5,h,4.5,0,Math.PI*2),e.arc(l+t.width-5,h,4.5,0,Math.PI*2),e.fill(),e.restore()}else t.kind==="boss_core"&&(e.save(),e.strokeStyle="rgba(253, 186, 116, 0.85)",e.lineWidth=2,e.beginPath(),e.arc(o,h,t.width*.34,0,Math.PI*2),e.stroke(),e.restore());if(t.hitFlashTimer>0&&(e.fillStyle="rgba(255, 255, 255, 0.65)",e.fillRect(l+2,t.y+2,t.width-4,t.height-4)),Number.isFinite(t.hp)&&t.maxHp>0){const p=t.hp/t.maxHp;if(p<1&&(e.save(),e.beginPath(),e.rect(l+2,t.y+2,t.width-4,t.height-4),e.clip(),e.strokeStyle="rgba(24, 18, 16, 0.78)",e.lineWidth=3.2,e.lineCap="round",e.lineJoin="round",this.traceJaggedCracks(e,l,t.y,t.width,t.height,o,h,p,t.id),e.stroke(),e.strokeStyle="rgba(255, 224, 102, 0.92)",e.lineWidth=1.6,this.traceJaggedCracks(e,l,t.y,t.width,t.height,o,h,p,t.id),e.stroke(),e.restore()),t.kind!=="tnt"&&(t.hp<t.maxHp||t.hp>=10)){const u=N(Math.ceil(t.hp));e.font='700 17px "Lilita One", "Fredoka", system-ui, sans-serif',e.textAlign="center",e.textBaseline="middle",e.lineWidth=4.5,e.strokeStyle="#181210",e.strokeText(u,o,h+1),e.fillStyle="#ffffff",e.fillText(u,o,h+1)}}e.restore()}traceJaggedCracks(e,t,s,i,a,n,r,d,l){const o=(l%5-2)*1.4;e.beginPath(),d<=.78&&(e.moveTo(t+6,s+6),e.lineTo(t+i*.28+o,s+a*.34),e.lineTo(t+i*.42-o,s+a*.3),e.lineTo(n,r)),d<=.5&&(e.moveTo(t+i-6,s+8),e.lineTo(t+i*.72-o,s+a*.28),e.lineTo(t+i*.58+o,s+a*.44),e.lineTo(n-2,r+2)),d<=.25&&(e.moveTo(t+8,s+a-6),e.lineTo(t+i*.32-o,s+a*.68),e.lineTo(t+i*.46+o,s+a*.56),e.lineTo(n+3,r-2),e.moveTo(n+4,r+3),e.lineTo(t+i*.76,s+a*.76),e.lineTo(t+i-7,s+a-9))}renderOrb(e,t,s){const i=t.bouncesLeft<=2||t.overheatDraining,a=i?"#f59e0b":t.isOverdrive?"#fde047":s.trailColor,n=1+Math.min(.4,t.comboCount*.025);if(t.trail.length>1){e.save();for(let l=1;l<t.trail.length;l++){const o=t.trail[l-1],h=t.trail[l],m=l/t.trail.length;e.strokeStyle=a,e.globalAlpha=m*.72,e.lineWidth=t.radius*1.2*n*m,e.lineCap="round",e.beginPath(),e.moveTo(o.x,o.y),e.lineTo(h.x,h.y),e.stroke()}e.restore()}const r=Math.max(0,Math.min(1,t.bouncesLeft/Math.max(1,t.maxBounces)));e.save(),e.strokeStyle=i?"#f59e0b":"#ffe066",e.lineWidth=2.5,e.beginPath(),e.arc(t.x,t.y,t.radius+5,-Math.PI/2,-Math.PI/2+Math.PI*2*r),e.stroke(),e.translate(t.x,t.y),e.rotate(t.rotation);const d=this.atlas.getPropSawblade(s);if(d){const l=t.radius*2.45;e.drawImage(d,-l*.5,-l*.5,l,l)}else e.fillStyle=s.primaryColor,e.beginPath(),e.arc(0,0,t.radius,0,Math.PI*2),e.fill();e.restore()}hexToRgba(e,t){const s=e.replace("#","");if(s.length!==6)return`rgba(255, 191, 71, ${t})`;const i=parseInt(s.slice(0,2),16),a=parseInt(s.slice(2,4),16),n=parseInt(s.slice(4,6),16);return`rgba(${i}, ${a}, ${n}, ${t})`}}const js=6e4;class Ys{constructor(){c(this,"name","crazygames");c(this,"supportsBanners",!0);c(this,"hideFullscreenButton",!0);c(this,"disabled",!1);c(this,"lastBannerRequestMs",new Map)}get sdk(){return window.CrazyGames?.SDK}isDisabled(){return this.disabled?!0:this.sdk?.environment==="disabled"}async init(){try{const e=this.sdk;if(!e||e.environment==="disabled"||!e.init){this.disabled=!0;return}await e.init(),this.sdk?.environment==="disabled"&&(this.disabled=!0)}catch{this.disabled=!0}}async hasAdblock(){if(this.isDisabled())return!0;try{const e=this.sdk?.ad?.hasAdblock;if(!e)return!1;const t=new Promise(s=>{setTimeout(()=>s(!1),1500)});return await Promise.race([e(),t])}catch{return!1}}loadingStart(){if(!this.isDisabled())try{this.sdk?.game?.loadingStart?.()}catch{}}loadingStop(){if(!this.isDisabled())try{this.sdk?.game?.loadingStop?.()}catch{}}gameplayStart(){if(!this.isDisabled())try{this.sdk?.game?.gameplayStart?.()}catch{}}gameplayStop(){if(!this.isDisabled())try{this.sdk?.game?.gameplayStop?.()}catch{}}happytime(){if(!this.isDisabled())try{this.sdk?.game?.happytime?.()}catch{}}requestAd(e){return this.isDisabled()?Promise.resolve({rewarded:!1,reason:"error"}):new Promise(t=>{const s=this.sdk?.ad?.requestAd;if(!s){t({rewarded:!1,reason:"error"});return}let i=!1;const a=setTimeout(()=>{i||(i=!0,t({rewarded:!1,reason:"error"}))},6e4);try{s(e,{adFinished:()=>{i||(i=!0,clearTimeout(a),t({rewarded:!0,reason:"finished"}))},adError:n=>{if(!i){i=!0,clearTimeout(a);const d=String(n?.code??n??"").toLowerCase().includes("adblock");t({rewarded:!1,reason:d?"adblock":"error"})}}})}catch{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}})}showMidgameAd(){return this.requestAd("midgame")}showRewardedAd(e){return this.requestAd("rewarded")}requestBanner(e){if(this.isDisabled())return;const t=Date.now(),s=this.lastBannerRequestMs.get(e)??0;if(!(t-s<js)){this.lastBannerRequestMs.set(e,t);try{this.sdk?.banner?.requestResponsiveBanner?.(e)}catch{}}}clearBanner(e){try{this.sdk?.banner?.clearBanner?.(e)}catch{}}clearAllBanners(){try{this.sdk?.banner?.clearAllBanners?.()}catch{}}async saveCloudData(e){if(!this.isDisabled())try{this.sdk?.data?.setItem?.("ricochet_miner_save",e)}catch{}}async loadCloudData(){if(this.isDisabled())return null;try{return this.sdk?.data?.getItem?.("ricochet_miner_save")??null}catch{return null}}getLocale(){const e=this.sdk?.user?.systemInfo?.locale,t=typeof this.sdk?.environment=="object"?this.sdk.environment:void 0;return e??t?.locale??(typeof navigator<"u"?navigator.language:"en")}getDeviceType(){const e=this.sdk?.user?.systemInfo?.device?.type,t=typeof this.sdk?.environment=="object"?this.sdk.environment:void 0,s=e??t?.device?.type;return s==="mobile"||s==="tablet"||s==="desktop"?s:typeof window>"u"?"desktop":window.innerWidth<=640?"mobile":window.innerWidth<=1024&&window.innerHeight>window.innerWidth?"tablet":"desktop"}getServerTimeMs(){return Date.now()}}class Xs{constructor(){c(this,"name","gamedistribution");c(this,"supportsBanners",!1);c(this,"hideFullscreenButton",!1);c(this,"rewardedGranted",!1);c(this,"adResolve",null)}get sdk(){return window.gdsdk}async init(){const e=window,t=e.GD_OPTIONS??{};e.GD_OPTIONS={...t,onEvent:s=>{if(s?.name==="SDK_REWARDED_WATCH_COMPLETE")this.rewardedGranted=!0;else if(s?.name==="SDK_GAME_START"){const i=this.adResolve;this.adResolve=null,i&&i({rewarded:this.rewardedGranted,reason:this.rewardedGranted?"finished":"skipped"})}}}}loadingStart(){}loadingStop(){}gameplayStart(){}gameplayStop(){}happytime(){}async showMidgameAd(){if(!this.sdk?.showAd)return{rewarded:!1,reason:"error"};this.rewardedGranted=!0;try{return await this.sdk.showAd("interstitial"),{rewarded:!0,reason:"finished"}}catch{return{rewarded:!1,reason:"error"}}}showRewardedAd(e){return this.sdk?.showAd?(this.rewardedGranted=!1,new Promise(t=>{const s=setTimeout(()=>{this.adResolve&&(this.adResolve=null,t({rewarded:!1,reason:"error"}))},6e4);this.adResolve=i=>{clearTimeout(s),t(i)},this.sdk.showAd("rewarded").catch(()=>{clearTimeout(s),this.adResolve=null,t({rewarded:!1,reason:"error"})})})):Promise.resolve({rewarded:!1,reason:"error"})}requestBanner(){}clearBanner(){}async saveCloudData(){}async loadCloudData(){return null}getLocale(){return navigator.language??"en"}getDeviceType(){return window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}class Qe{constructor(e="mock",t=!0){c(this,"name");c(this,"supportsBanners");c(this,"hideFullscreenButton",!1);c(this,"simulateAdError",!1);c(this,"simulateAdBlock",!1);c(this,"simulatedDelayMs",450);this.name=e,this.supportsBanners=t}async init(){return Promise.resolve()}loadingStart(){}loadingStop(){}gameplayStart(){}gameplayStop(){}happytime(){}async showMidgameAd(){return this.name==="standalone"?{rewarded:!1,reason:"skipped"}:this.simulateAdBlock?{rewarded:!1,reason:"adblock"}:this.simulateAdError?{rewarded:!1,reason:"error"}:(await new Promise(e=>setTimeout(e,this.simulatedDelayMs)),{rewarded:!0,reason:"finished"})}async showRewardedAd(e){return this.name==="standalone"?{rewarded:!1,reason:"error"}:this.simulateAdBlock?{rewarded:!1,reason:"adblock"}:this.simulateAdError?{rewarded:!1,reason:"error"}:(await new Promise(t=>setTimeout(t,this.simulatedDelayMs)),{rewarded:!0,reason:"finished"})}async hasAdblock(){return this.simulateAdBlock||this.simulateAdError}isDisabled(){return this.name==="standalone"}requestBanner(e){const t=typeof document<"u"?document.getElementById(e):null;t&&(t.textContent="BANNER AD SLOT (DEV)",t.style.visibility="visible")}clearBanner(e){const t=typeof document<"u"?document.getElementById(e):null;t&&(t.textContent="")}clearAllBanners(){typeof document>"u"||document.querySelectorAll(".rm-banner-slot").forEach(e=>{e.textContent=""})}async saveCloudData(e){return Promise.resolve()}async loadCloudData(){return Promise.resolve(null)}getLocale(){return typeof navigator<"u"?navigator.language:"en"}getDeviceType(){return typeof window>"u"?"desktop":window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}const Ze=45e3;class Qs{constructor(){c(this,"name","poki");c(this,"supportsBanners",!1);c(this,"hideFullscreenButton",!1)}get sdk(){return window.PokiSDK}async init(){try{await this.sdk?.init?.()}catch{}}loadingStart(){}loadingStop(){try{this.sdk?.gameLoadingFinished?.()}catch{}}gameplayStart(){try{this.sdk?.gameplayStart?.()}catch{}}gameplayStop(){try{this.sdk?.gameplayStop?.()}catch{}}happytime(){}async showMidgameAd(){if(!this.sdk?.commercialBreak)return{rewarded:!1,reason:"error"};try{let e;const t=await Promise.race([this.sdk.commercialBreak().then(()=>({rewarded:!0,reason:"finished"})),new Promise(s=>{e=setTimeout(()=>s({rewarded:!1,reason:"error"}),Ze)})]);return e&&clearTimeout(e),t}catch{return{rewarded:!1,reason:"error"}}}async showRewardedAd(e){if(!this.sdk?.rewardedBreak)return{rewarded:!1,reason:"error"};try{let t;const s=await Promise.race([this.sdk.rewardedBreak().then(i=>({rewarded:!!i,reason:i?"finished":"skipped"})),new Promise(i=>{t=setTimeout(()=>i({rewarded:!1,reason:"error"}),Ze)})]);return t&&clearTimeout(t),s}catch{return{rewarded:!1,reason:"error"}}}requestBanner(){}clearBanner(){}async saveCloudData(){}async loadCloudData(){return null}getLocale(){return navigator.language??"en"}getDeviceType(){return window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){return Date.now()}}const Je=45e3;class Zs{constructor(){c(this,"name","yandex");c(this,"supportsBanners",!0);c(this,"hideFullscreenButton",!1);c(this,"ysdk",null);c(this,"player",null)}async init(){try{const e=window.YaGames;if(e?.init){this.ysdk=await e.init();try{this.player=await this.ysdk.getPlayer?.({scopes:!1})??null}catch{this.player=null}}}catch{this.ysdk=null}}loadingStart(){}loadingStop(){try{this.ysdk?.features?.LoadingAPI?.ready?.()}catch{}}gameplayStart(){try{this.ysdk?.features?.GameplayAPI?.start?.()}catch{}}gameplayStop(){try{this.ysdk?.features?.GameplayAPI?.stop?.()}catch{}}happytime(){}showMidgameAd(){return new Promise(e=>{if(!this.ysdk?.adv?.showFullscreenAdv){e({rewarded:!1,reason:"error"});return}let t=!1;const s=setTimeout(()=>{t||(t=!0,e({rewarded:!1,reason:"error"}))},Je);try{this.ysdk.adv.showFullscreenAdv({callbacks:{onClose:i=>{t||(t=!0,clearTimeout(s),e({rewarded:!!i,reason:"finished"}))},onError:()=>{t||(t=!0,clearTimeout(s),e({rewarded:!1,reason:"error"}))}}})}catch{t||(t=!0,clearTimeout(s),e({rewarded:!1,reason:"error"}))}})}showRewardedAd(e){return new Promise(t=>{if(!this.ysdk?.adv?.showRewardedVideo){t({rewarded:!1,reason:"error"});return}let s=!1,i=!1;const a=setTimeout(()=>{i||(i=!0,t({rewarded:!1,reason:"error"}))},Je);try{this.ysdk.adv.showRewardedVideo({callbacks:{onRewarded:()=>{s=!0},onClose:()=>{i||(i=!0,clearTimeout(a),t({rewarded:s,reason:s?"finished":"skipped"}))},onError:()=>{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}}})}catch{i||(i=!0,clearTimeout(a),t({rewarded:!1,reason:"error"}))}})}requestBanner(){try{window.innerHeight>=600&&this.ysdk?.adv?.showBannerAdv?.()}catch{}}clearBanner(){try{this.ysdk?.adv?.hideBannerAdv?.()}catch{}}async saveCloudData(e){try{await this.player?.setData({ricochet_miner_save:e},!0)}catch{}}async loadCloudData(){try{const t=(await this.player?.getData(["ricochet_miner_save"]))?.ricochet_miner_save;return typeof t=="string"?t:null}catch{return null}}getLocale(){return this.ysdk?.environment?.i18n?.lang??navigator.language??"en"}getDeviceType(){const e=this.ysdk?.deviceInfo?.type;return e==="mobile"||e==="tablet"||e==="desktop"?e:window.innerWidth<768?"mobile":"desktop"}getServerTimeMs(){try{const e=this.ysdk?.serverTime?.();if(typeof e=="number"&&e>0)return e}catch{}return Date.now()}}const Js=3e3;class ei{constructor(e){c(this,"adapter");c(this,"initialized",!1);c(this,"initPromise",null);c(this,"fallbackToOffline",!1);c(this,"rewardedAdsAvailable",!0);c(this,"sessionAdsBlocked",!1);c(this,"activeBannerIds",new Set);c(this,"adListeners",new Set);c(this,"playstate","IDLE");c(this,"lifecycle",{onBeforeAd:()=>{},onAfterAd:()=>{}});this.adapter=e??this.createAdapter(),this.rewardedAdsAvailable=this.computeInitialAdSupport()}createAdapter(){switch("crazygames"){case"crazygames":return new Ys;case"poki":return new Qs;case"gamedistribution":return new Xs;case"yandex":return new Zs;case"standalone":return new Qe("standalone",!1);default:return new Qe("mock",!0)}}computeInitialAdSupport(){return!(this.fallbackToOffline||this.sessionAdsBlocked||this.adapter.name==="standalone"||this.adapter.isDisabled?.())}setAdapterForTest(e){this.adapter=e,this.initialized=!1,this.initPromise=null,this.fallbackToOffline=!1,this.sessionAdsBlocked=!1,this.activeBannerIds.clear(),this.playstate="IDLE",this.rewardedAdsAvailable=this.computeInitialAdSupport(),this.emitAdAvailabilityChanged()}setAdLifecycleCallbacks(e){this.lifecycle=e}getAdapter(){return this.adapter}get activePlaystate(){return this.playstate}get gameplayActive(){return this.playstate==="GAMEPLAY"}get adInFlight(){return this.playstate==="AD_PAUSED"}get isOfflineFallback(){return this.fallbackToOffline||!!this.adapter.isDisabled?.()}get supportsBanners(){return!this.isOfflineFallback&&this.adapter.supportsBanners}get hideFullscreenButton(){return this.adapter.hideFullscreenButton}canShowRewardedAds(){return this.rewardedAdsAvailable&&!this.isOfflineFallback&&!this.sessionAdsBlocked}canShowBanners(){return this.supportsBanners&&this.canShowRewardedAds()}onAdAvailabilityChange(e){return this.adListeners.add(e),()=>{this.adListeners.delete(e)}}emitAdAvailabilityChanged(){const e=this.canShowRewardedAds();for(const t of this.adListeners)try{t(e)}catch{}if(typeof window<"u"&&typeof CustomEvent<"u")try{window.dispatchEvent(new CustomEvent("ad-availability-changed",{detail:{available:e}}))}catch{}}async init(e=Js){if(!this.initialized)return this.initPromise?this.initPromise:(this.initPromise=(async()=>{let t;try{await Promise.race([this.adapter.init().then(()=>"ok"),new Promise(i=>{t=setTimeout(()=>i("timeout"),e)})])==="timeout"?(console.warn(`[PlatformSDK] ${this.adapter.name} init timed out after ${e}ms; activating offline fallback.`),this.fallbackToOffline=!0):this.adapter.isDisabled?.()&&(this.fallbackToOffline=!0)}catch(s){console.warn(`[PlatformSDK] ${this.adapter.name} init failed; activating offline fallback.`,s),this.fallbackToOffline=!0}finally{t&&clearTimeout(t)}this.initialized=!0,await this.refreshAdAvailability()})(),this.initPromise)}async refreshAdAvailability(){const e=this.canShowRewardedAds();if(this.isOfflineFallback||this.adapter.name==="standalone"||this.sessionAdsBlocked)return this.rewardedAdsAvailable=!1,e!==this.canShowRewardedAds()&&this.emitAdAvailabilityChanged(),!1;let t=!1;try{this.adapter.hasAdblock&&(t=await this.adapter.hasAdblock())}catch{t=!1}t?(this.sessionAdsBlocked=!0,this.rewardedAdsAvailable=!1):this.rewardedAdsAvailable=!0;const s=this.canShowRewardedAds();return e!==s&&this.emitAdAvailabilityChanged(),s}loadingStart(){this.isOfflineFallback||this.adapter.loadingStart()}loadingStop(){this.isOfflineFallback||this.adapter.loadingStop()}gameplayStart(){this.playstate==="IDLE"&&(this.playstate="GAMEPLAY",!this.isOfflineFallback&&this.adapter.gameplayStart())}gameplayStop(){this.playstate==="GAMEPLAY"&&(this.playstate="IDLE",!this.isOfflineFallback&&this.adapter.gameplayStop())}happytime(){this.playstate==="AD_PAUSED"||this.isOfflineFallback||this.adapter.happytime()}async showMidgameAd(){if(this.playstate==="AD_PAUSED")return{rewarded:!1,reason:"skipped"};if(!this.canShowRewardedAds())return{rewarded:!1,reason:"skipped"};this.gameplayStop(),this.playstate="AD_PAUSED",this.lifecycle.onBeforeAd();try{return await this.adapter.showMidgameAd()}catch{return{rewarded:!1,reason:"error"}}finally{this.playstate="IDLE",this.lifecycle.onAfterAd()}}async showRewardedAd(e){if(this.playstate==="AD_PAUSED")return{rewarded:!1,reason:"skipped"};if(!this.canShowRewardedAds())return{rewarded:!1,reason:"adblock"};this.gameplayStop(),this.playstate="AD_PAUSED",this.lifecycle.onBeforeAd();try{const t=await this.adapter.showRewardedAd(e);return!t.rewarded&&(t.reason==="adblock"||t.reason==="error")&&(this.sessionAdsBlocked=!0,this.rewardedAdsAvailable=!1,this.emitAdAvailabilityChanged()),t}catch{return this.sessionAdsBlocked=!0,this.rewardedAdsAvailable=!1,this.emitAdAvailabilityChanged(),{rewarded:!1,reason:"error"}}finally{this.playstate="IDLE",this.lifecycle.onAfterAd()}}requestBanner(e,t){this.playstate==="AD_PAUSED"||!this.canShowBanners()||(this.activeBannerIds.add(e),this.adapter.requestBanner(e,t))}clearBanner(e){this.activeBannerIds.delete(e),!(this.playstate==="AD_PAUSED"||!this.supportsBanners)&&this.adapter.clearBanner(e)}clearAllBanners(){if(!this.supportsBanners){this.activeBannerIds.clear();return}if(this.adapter.clearAllBanners)this.adapter.clearAllBanners();else for(const e of this.activeBannerIds)this.adapter.clearBanner(e);this.activeBannerIds.clear()}async saveCloudData(e){this.isOfflineFallback||await this.adapter.saveCloudData(e)}async loadCloudData(){return this.isOfflineFallback?null:await this.adapter.loadCloudData()}getLocale(){return this.adapter.getLocale()}getDeviceType(){return this.adapter.getDeviceType()}getServerTimeMs(){return this.adapter.getServerTimeMs()}}const S=new ei,gt=1,me="ricochet_miner_save_v1";function Te(f=Date.now()){return{version:gt,saveTimestamp:f,coins:0,totalCoinsEarned:0,shards:0,prestigeLevel:0,relicGems:0,ascensionTier:0,ascensionRecords:[],unlockedAchievements:[],claimedAchievements:[],runsCompleted:0,recentRunEarnings:[],recentRunCoinsPerMin:120,maxDepthMeters:0,unlockedBiomeIndex:0,selectedBiomeIndex:0,bossGateHpByBiome:{},upgrades:{damage:1,bounces:1,multiorb:1,orbsize:1,luck:1,orevalue:1},unlockedSkins:["steel_sawblade"],equippedSkin:"steel_sawblade",skinRvProgress:{},overdrivePasses:0,stats:{tntDetonated:0,bumpersHit:0,blocksDestroyed:0,vaultsBroken:0,maxBounceCombo:0,runsCompleted:0},loginStreak:{day:1,lastClaimDate:"",claimedToday:!1},dailyQuests:{dateKey:Se(f),quests:[],megaChestClaimed:!1},settings:{muted:!1,sfxMuted:!1,musicMuted:!1,musicVolume:"high",aimMode:"direct",aimModeUserSet:!1},ftueDone:!1,lastActiveTimestamp:f}}function Me(f,e=Date.now()){const t=Te(e);if(!f)return t;try{const s=JSON.parse(f);if(!s||typeof s!="object")return t;const i={...t,...s,upgrades:{...t.upgrades,...s.upgrades??{}},stats:{...t.stats,...s.stats??{}},loginStreak:{...t.loginStreak,...s.loginStreak??{}},dailyQuests:{...t.dailyQuests,...s.dailyQuests??{}},settings:{...t.settings,...s.settings??{}},version:gt};return(!Array.isArray(i.unlockedSkins)||i.unlockedSkins.length===0)&&(i.unlockedSkins=["steel_sawblade"]),i.unlockedSkins.includes(i.equippedSkin)||(i.equippedSkin="steel_sawblade"),(!Number.isFinite(i.coins)||i.coins<0)&&(i.coins=0),(!Number.isFinite(i.totalCoinsEarned)||i.totalCoinsEarned<0)&&(i.totalCoinsEarned=i.coins),(!Number.isFinite(i.ascensionTier)||i.ascensionTier<0)&&(i.ascensionTier=0),Array.isArray(i.ascensionRecords)||(i.ascensionRecords=[]),Array.isArray(i.unlockedAchievements)||(i.unlockedAchievements=[]),Array.isArray(i.claimedAchievements)||(i.claimedAchievements=[]),i.settings.musicVolume!=="off"&&i.settings.musicVolume!=="low"&&i.settings.musicVolume!=="high"&&(i.settings.musicVolume=i.settings.musicMuted?"off":"high"),i.settings.musicVolume==="off"&&(i.settings.musicMuted=!0),i}catch{return t}}function ti(f,e){return e?e.totalCoinsEarned>f.totalCoinsEarned?e:f.totalCoinsEarned>e.totalCoinsEarned?f:e.saveTimestamp>f.saveTimestamp?e:f:f}class si{constructor(e){c(this,"storage");c(this,"memoryFallback",new Map);c(this,"storageWriteFailed",!1);if(e!==void 0)this.storage=e;else if(typeof window<"u")try{this.storage=window.localStorage}catch{this.storage=null}else this.storage=null}loadLocal(e=Date.now()){if(this.storageWriteFailed){const t=this.memoryFallback.get(me)??null;return Me(t,e)}try{const t=this.storage?.getItem(me)??this.memoryFallback.get(me)??null;return Me(t,e)}catch{this.storageWriteFailed=!0;const t=this.memoryFallback.get(me)??null;return Me(t,e)}}saveLocal(e){e.saveTimestamp=Date.now();const t=JSON.stringify(e);this.memoryFallback.set(me,t);try{this.storage?.setItem(me,t),this.storageWriteFailed=!1}catch{this.storageWriteFailed=!0}return t}resetProgress(e=Date.now()){const t=Te(e);return this.saveLocal(t),t}}class ii{getSpec(e){const t=ne.find(s=>s.id===e);if(!t)throw new Error(`Unknown upgrade: ${e}`);return t}getLevel(e,t){return e.upgrades[t]??1}getMaxLevel(e,t){return this.getSpec(t).maxLevel+ct(e.ascensionTier)}isMaxLevel(e,t){return this.getLevel(e,t)>=this.getMaxLevel(e,t)}getUpgradeCost(e,t){const s=this.getSpec(t),i=this.getLevel(e,t);return Nt(s,i)}canAfford(e,t){return this.isMaxLevel(e,t)?!1:e.coins>=this.getUpgradeCost(e,t)}buyUpgrade(e,t){if(!this.canAfford(e,t))return!1;const s=this.getUpgradeCost(e,t);return e.coins-=s,e.upgrades[t]=this.getLevel(e,t)+1,!0}grantFreeUpgrade(e,t){return this.isMaxLevel(e,t)?!1:(e.upgrades[t]=this.getLevel(e,t)+1,!0)}getCheapestNearlyAffordableUpgrade(e,t,s){let i=null,a=Number.POSITIVE_INFINITY;for(const n of ne){if(this.isMaxLevel(e,n.id))continue;const r=this.getUpgradeCost(e,n.id);if(e.coins>=r)continue;const d=(r-e.coins)/r;d>=t&&d<=s&&r<a&&(a=r,i=n.id)}return i}getEffectiveDrillDamage(e){return Ft(e.upgrades.damage,e.prestigeLevel,e.ascensionTier)}getEffectiveMaxBounces(e){return Vt(e.upgrades.bounces)}getEffectiveMultiOrbCount(e){return $t(e.upgrades.multiorb)}getEffectiveOrbRadius(e){return Ht(e.upgrades.orbsize)}getEffectiveOreValueMultiplier(e){return pt(e.upgrades.orevalue)}}class ai{constructor(){c(this,"sessionElapsedS",0);c(this,"lastMidgameAdTimeS",-9999);c(this,"lastDoubleRunAt",-99);c(this,"lastFreeUpgradeAt",-99);c(this,"lastOverdriveAt",-99)}updateSessionTime(e){this.sessionElapsedS+=e}canShowMidgameAd(){return this.sessionElapsedS<Q.MIDGAME_GRACE_PERIOD_S?!1:this.sessionElapsedS-this.lastMidgameAdTimeS>=Q.MIDGAME_COOLDOWN_S}resetMidgameCooldown(){this.lastMidgameAdTimeS=this.sessionElapsedS}async tryShowMidgameAd(){return this.canShowMidgameAd()?(this.lastMidgameAdTimeS=this.sessionElapsedS,await S.showMidgameAd()):{rewarded:!1,reason:"skipped"}}async showRewarded(e){const t=await S.showRewardedAd(e);return t.rewarded&&this.resetMidgameCooldown(),t}canOfferDoubleRun(e,t){if(t<=0||e.runsCompleted<1||e.runsCompleted-this.lastDoubleRunAt<Q.RV_DOUBLE_RUN_COOLDOWN_RUNS)return!1;if(e.recentRunEarnings.length===0)return!0;const s=e.recentRunEarnings.reduce((i,a)=>i+a,0)/e.recentRunEarnings.length;return t>=s*Q.RV_DOUBLE_RUN_RATIO}markDoubleRunOffered(e){this.lastDoubleRunAt=e}canOfferFreeUpgrade(e){return e-this.lastFreeUpgradeAt>=Q.RV_FREE_UPGRADE_COOLDOWN_RUNS}markFreeUpgradeOffered(e){this.lastFreeUpgradeAt=e}canOfferOverdriveTrial(e){return e>=2&&e-this.lastOverdriveAt>=Q.RV_OVERDRIVE_COOLDOWN_RUNS}markOverdriveOffered(e){this.lastOverdriveAt=e}}class ni{getSelectedBiome(e){const t=Math.max(0,Math.min(e.unlockedBiomeIndex,e.selectedBiomeIndex));return O[t]??O[0]}getBaseRowOffset(e){const t=this.getSelectedBiome(e);return Math.floor(t.startDepthM/y.METERS_PER_ROW)}selectBiome(e,t){return t<0||t>e.unlockedBiomeIndex||t>=O.length?!1:(e.selectedBiomeIndex=t,!0)}unlockNextBiome(e,t){const s=t+1;return s>=O.length?!1:(delete e.bossGateHpByBiome[t],s>e.unlockedBiomeIndex?(e.unlockedBiomeIndex=s,e.selectedBiomeIndex=s,!0):!1)}recordBossCoreDamage(e,t,s,i){e.bossGateHpByBiome[t]||(e.bossGateHpByBiome[t]=[-1,-1,-1]),e.bossGateHpByBiome[t][s]=Math.max(0,i)}completeFinalGateClear(e,t,s){if(delete e.bossGateHpByBiome[V.FINAL_BIOME_INDEX],!t)return{ascended:!1,newTier:e.ascensionTier};const i=e.ascensionTier+1;e.ascensionTier=i;const a=ht(i);return e.ascensionRecords.push({tier:i,titleKey:a.titleKey,blocksSmashed:s.blocksSmashed,maxCombo:s.maxCombo,timestamp:s.timestamp}),e.selectedBiomeIndex=0,{ascended:!0,newTier:i}}checkMasteryFeats(e,t){const s=[],i=a=>{e.unlockedAchievements.includes(a)||(e.unlockedAchievements.push(a),s.push(a))};return t.tntChainMax>=5&&i("chain_detonator"),t.maxCombo>=50&&i("combo_master"),ne.some(a=>(e.upgrades[a.id]??1)>=20)&&i("heavy_investor"),t.isFullShaftRun&&t.maxDepthMeters>=O[3].startDepthM&&i("zero_skip_purist"),s}claimMasteryFeat(e,t){if(!e.unlockedAchievements.includes(t)||e.claimedAchievements.includes(t))return 0;const s=rt.find(i=>i.id===t);return s?(e.claimedAchievements.push(t),e.coins+=s.rewardCoins,e.totalCoinsEarned+=s.rewardCoins,s.rewardCoins):0}hasUnclaimedFeats(e){return e.unlockedAchievements.some(t=>!e.claimedAchievements.includes(t))}canPrestige(e){return e.maxDepthMeters>=Pt}triggerPrestige(e){return this.canPrestige(e)?(e.prestigeLevel+=1,e.relicGems+=1,e.coins=0,e.unlockedBiomeIndex=0,e.selectedBiomeIndex=0,e.bossGateHpByBiome={},e.upgrades={damage:1,bounces:1,multiorb:1,orbsize:1,luck:1,orevalue:1},!0):!1}}class ri{calculateOfflineEarnings(e,t){if(e.runsCompleted<G.OFFLINE_UNLOCK_RUNS||!e.lastActiveTimestamp||t<=e.lastActiveTimestamp)return 0;const i=(t-e.lastActiveTimestamp)/6e4;if(i<G.OFFLINE_MIN_MINUTES)return 0;const a=G.OFFLINE_MAX_HOURS*60,n=Math.min(i,a),r=Math.max(10,e.recentRunCoinsPerMin)*G.OFFLINE_RATE_FRACTION;return Math.max(1,Math.floor(n*r))}refreshDailyQuestsIfNeeded(e,t){const s=Se(t);if(e.dailyQuests.dateKey===s&&e.dailyQuests.quests.length===3)return;const i=[...G.DAILY_QUEST_POOL];let a=0;for(let r=0;r<s.length;r++)a=a*31+s.charCodeAt(r)>>>0;const n=[];for(let r=0;r<3;r++){const d=(a+r*2)%i.length,l=i.splice(d,1)[0];n.push({id:l.id,progress:0,target:l.target,claimed:!1})}e.dailyQuests={dateKey:s,quests:n,megaChestClaimed:!1}}recordQuestProgress(e,t,s){for(const i of e.dailyQuests.quests){const a=G.DAILY_QUEST_POOL.find(n=>n.id===i.id);a&&a.metric===t&&!i.claimed&&(i.progress=Math.min(i.target,i.progress+s))}}claimQuest(e,t){const s=e.dailyQuests.quests.find(a=>a.id===t);if(!s||s.claimed||s.progress<s.target)return 0;const i=G.DAILY_QUEST_POOL.find(a=>a.id===s.id);return i?(s.claimed=!0,e.coins+=i.rewardCoins,e.totalCoinsEarned+=i.rewardCoins,i.rewardCoins):0}canClaimMegaChest(e){return e.dailyQuests.megaChestClaimed?!1:e.dailyQuests.quests.length===3&&e.dailyQuests.quests.every(t=>t.claimed)}claimMegaChest(e){return this.canClaimMegaChest(e)?(e.dailyQuests.megaChestClaimed=!0,e.coins+=G.DAILY_MEGA_CHEST_COINS,e.totalCoinsEarned+=G.DAILY_MEGA_CHEST_COINS,e.shards+=G.DAILY_MEGA_CHEST_SHARDS,!0):!1}syncLoginStreakState(e,t){const s=Se(t);if(e.loginStreak.lastClaimDate===s){e.loginStreak.claimedToday=!0;return}if(e.loginStreak.claimedToday=!1,e.loginStreak.lastClaimDate){const i=Date.parse(`${e.loginStreak.lastClaimDate}T00:00:00Z`),a=Date.parse(`${s}T00:00:00Z`),n=Math.round((a-i)/864e5);n>1?e.loginStreak.day=1:n===1&&(e.loginStreak.day=e.loginStreak.day>=7?1:e.loginStreak.day+1)}}claimDailyLoginReward(e,t){if(this.syncLoginStreakState(e,t),e.loginStreak.claimedToday)return!1;const s=Math.max(0,Math.min(6,e.loginStreak.day-1)),i=G.LOGIN_REWARDS[s];return i.type==="coins"?(e.coins+=i.amount,e.totalCoinsEarned+=i.amount):i.type==="free_damage"?e.upgrades.damage=Math.min(40,e.upgrades.damage+i.amount):i.type==="shards"?e.shards+=i.amount:i.type==="overdrive_pass"?e.overdrivePasses+=i.amount:i.type==="skin"&&(e.unlockedSkins.includes(i.skinId)||e.unlockedSkins.push(i.skinId)),e.loginStreak.lastClaimDate=Se(t),e.loginStreak.claimedToday=!0,!0}}class oi{getEquippedSkin(e){return fe.find(t=>t.id===e.equippedSkin)??fe[0]}checkAndUnlockEligibleSkins(e){const t=[];for(const s of fe)e.unlockedSkins.includes(s.id)||(s.category==="milestone"&&typeof s.unlockBiomeIndex=="number"&&e.unlockedBiomeIndex>=s.unlockBiomeIndex||s.category==="mastery"&&s.masteryStat&&typeof s.masteryTarget=="number"&&e.stats[s.masteryStat]>=s.masteryTarget)&&(e.unlockedSkins.push(s.id),t.push(s.id));return t}equipSkin(e,t){return e.unlockedSkins.includes(t)?(e.equippedSkin=t,!0):!1}unlockWithCoins(e,t){const s=fe.find(i=>i.id===t);return!s||e.unlockedSkins.includes(t)||!s.coinCost||e.coins<s.coinCost?!1:(e.coins-=s.coinCost,e.unlockedSkins.push(t),e.equippedSkin=t,!0)}addRvProgress(e,t){const s=fe.find(n=>n.id===t);if(!s||e.unlockedSkins.includes(t)||!s.rvCost)return!1;const a=(e.skinRvProgress[t]??0)+1;return e.skinRvProgress[t]=a,a>=s.rvCost?(e.unlockedSkins.push(t),e.equippedSkin=t,!0):!1}}const li={coin:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9.5" fill="#d97706" stroke="#181210" stroke-width="2"/><circle cx="12" cy="11.3" r="8" fill="#fbbf24" stroke="#92400e" stroke-width="1.2"/><circle cx="12" cy="11.3" r="5" fill="#fde047" stroke="#b45309" stroke-width="1.3"/><path d="M9.5 8.5l2.5-1.5 2.5 1.5" stroke="#fffbeb" stroke-width="1.6" stroke-linecap="round"/></svg>',pickaxe:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M5 19L15 9" stroke="#d97706" stroke-width="3" stroke-linecap="round"/><path d="M9 5c4-1 8 1 10 5l-3 2c-1.5-2.5-4-3.8-7-4V5z" fill="#94a3b8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',pause:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="6" y="5" width="4.5" height="14" rx="1.5" fill="#f8fafc" stroke="#1a1310" stroke-width="1.8"/><rect x="13.5" y="5" width="4.5" height="14" rx="1.5" fill="#f8fafc" stroke="#1a1310" stroke-width="1.8"/></svg>',play:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M7 5l12 7-12 7V5z" fill="#f8fafc" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',soundOn:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9z" fill="#f8fafc" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><path d="M16.5 8.5a5 5 0 010 7M19 6a8.5 8.5 0 010 12" stroke="#f8fafc" stroke-width="2.2" stroke-linecap="round"/></svg>',soundOff:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 9h4l5-4v14l-5-4H4V9z" fill="#94a3b8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><path d="M16 9l5 6m0-6l-5 6" stroke="#ef4444" stroke-width="2.4" stroke-linecap="round"/></svg>',upgradePickaxe:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><path d="M5 19L15 9" stroke="#fde68a" stroke-width="3" stroke-linecap="round"/><path d="M8 4c5-1 9 2 11 6l-3 2c-1.5-2.5-4.5-4-8-4.5V4z" fill="#38bdf8" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',questClipboard:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="5" y="4" width="14" height="16" rx="2.5" fill="#e2e8f0" stroke="#1a1310" stroke-width="2"/><rect x="9" y="2" width="6" height="4" rx="1" fill="#fbbf24" stroke="#1a1310" stroke-width="1.8"/><path d="M8.5 11h7M8.5 15h5" stroke="#334155" stroke-width="2" stroke-linecap="round"/></svg>',streakArrows:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M7 18V7m0 0l-3.5 3.5M7 7l3.5 3.5M17 18V7m0 0l-3.5 3.5M17 7l3.5 3.5" stroke="#fb923c" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',elevatorCar:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><rect x="5" y="4" width="14" height="16" rx="2" fill="#64748b" stroke="#1a1310" stroke-width="2"/><path d="M12 8l3 3.5H9L12 8zm0 8l-3-3.5h6L12 16z" fill="#fde047"/></svg>',adPlay:'<svg viewBox="0 0 24 24" width="20" height="20" fill="none"><rect x="3" y="5" width="18" height="14" rx="3" fill="#fffbeb" stroke="#1a1310" stroke-width="2"/><path d="M10 9l6 3-6 3V9z" fill="#d97706" stroke="#1a1310" stroke-width="1.4" stroke-linejoin="round"/></svg>',handPointer:'<svg viewBox="0 0 36 36" width="38" height="38" fill="none"><path d="M18 4v14m0 0l-5-5m5 5l5-5" stroke="#fde047" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><circle cx="18" cy="27" r="6" fill="#fbbf24" stroke="#1a1310" stroke-width="2.5"/></svg>',globe:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9" fill="#38bdf8" stroke="#1a1310" stroke-width="2"/><ellipse cx="12" cy="12" rx="4" ry="9" stroke="#1a1310" stroke-width="1.6"/><path d="M3.5 9h17M3.5 15h17" stroke="#1a1310" stroke-width="1.6"/></svg>',palette:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9" fill="#e879f9" stroke="#1a1310" stroke-width="2"/><circle cx="9" cy="10" r="1.8" fill="#fde047"/><circle cx="14.5" cy="9.5" r="1.8" fill="#38bdf8"/><circle cx="14" cy="14.5" r="1.8" fill="#4ade80"/></svg>',lightning:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',orb:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="8" fill="#c084fc" stroke="#1a1310" stroke-width="2"/><circle cx="9.5" cy="9.5" r="2.2" fill="#f5d0fe"/></svg>',blast:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M12 2l2.5 5.5L20 6l-3 5.5L22 14l-5.5 2L18 21l-5.5-2.5L9 22l-1-5.5L2 15l4.5-3.5L4 6l5.5 1.5L12 2z" fill="#fb923c" stroke="#1a1310" stroke-width="1.8" stroke-linejoin="round"/></svg>',clover:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="9" cy="9" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/><circle cx="15" cy="9" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/><circle cx="12" cy="14.5" r="4" fill="#4ade80" stroke="#1a1310" stroke-width="1.8"/></svg>',gem:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M6 4h12l4 6-10 11L2 10l4-6z" fill="#e879f9" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>',close:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="#f8fafc" stroke-width="2.8" stroke-linecap="round"/></svg>',lock:'<svg viewBox="0 0 24 24" width="14" height="14" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" fill="#94a3b8" stroke="#1a1310" stroke-width="2"/><path d="M8 11V8a4 4 0 018 0v3" stroke="#cbd5e1" stroke-width="2.2"/></svg>',check:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M5 13l4 4L19 7" stroke="#4ade80" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/></svg>',fastForward:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 6l8 6-8 6V6zm9 0l8 6-8 6V6z" fill="#fde047" stroke="#1a1310" stroke-width="1.8" stroke-linejoin="round"/></svg>',recall:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M12 19V6m0 0l-5 5m5-5l5 5" stroke="#f8fafc" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',restart:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M4 12a8 8 0 102.3-5.6L4 9m0-5v5h5" stroke="#f8fafc" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',gear:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="3.5" fill="#fbbf24" stroke="#1a1310" stroke-width="2"/><path d="M12 2v3m0 14v3M4.9 4.9l2.1 2.1m10 10l2.1 2.1M2 12h3m14 0h3M4.9 19.1l2.1-2.1m10-10l2.1-2.1" stroke="#cbd5e1" stroke-width="2.6" stroke-linecap="round"/></svg>',home:'<svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M3 11l9-7 9 7v9a1.5 1.5 0 01-1.5 1.5H4.5A1.5 1.5 0 013 20v-9z" fill="#fbbf24" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/><rect x="9.5" y="13" width="5" height="8" fill="#4b382a" stroke="#1a1310" stroke-width="1.6"/></svg>',bossCore:'<svg viewBox="0 0 24 24" width="16" height="16" fill="none"><circle cx="12" cy="12" r="9" fill="#be123c" stroke="#1a1310" stroke-width="2"/><circle cx="12" cy="12" r="4.5" fill="#fde047"/></svg>'};function x(f){return`<span class="rm-ico" aria-hidden="true">${li[f]}</span>`}const ci=""+new URL("badge_ascension_star-B45ww98k.webp",import.meta.url).href,di=""+new URL("badge_chain_detonator-D65INHL_.webp",import.meta.url).href,hi=""+new URL("badge_combo_master-Cnbs7_AW.webp",import.meta.url).href,ui=""+new URL("badge_heavy_investor-BQfZH7w7.webp",import.meta.url).href,pi=""+new URL("badge_zero_skip-KfsgLs7p.webp",import.meta.url).href,mi=""+new URL("crest_tier_1-DAg54eJv.webp",import.meta.url).href,fi=""+new URL("crest_tier_2-CS3GvrQL.webp",import.meta.url).href,gi=""+new URL("crest_tier_3-D32WghhJ.webp",import.meta.url).href,yi=""+new URL("crest_tier_4-Bn1DmMec.webp",import.meta.url).href,bi=""+new URL("icon_chest-D_cFWHcx.webp",import.meta.url).href,yt=""+new URL("icon_drill_damage-D6r6sewr.webp",import.meta.url).href,_i=""+new URL("icon_gear_elevator-CSNPXUG4.webp",import.meta.url).href,vi=""+new URL("icon_luck-S_sqklRE.webp",import.meta.url).href,bt=""+new URL("icon_max_bounces-p3pl0hif.webp",import.meta.url).href,ki=""+new URL("icon_multiball-DR5vWYDa.webp",import.meta.url).href,xi=""+new URL("icon_orb_size-Bz8fW7IA.webp",import.meta.url).href,wi=""+new URL("icon_ore_value-BdPwZk7R.webp",import.meta.url).href,Si=""+new URL("icon_trophy-Cq8U42vz.webp",import.meta.url).href,Mi=""+new URL("ui_modal_frame-CTlqQCEp.webp",import.meta.url).href,Ti=Mi,D={drillDamage:yt,maxBounces:bt,trophy:Si,gearElevator:_i,chest:bi,badgeChainDetonator:di,badgeComboMaster:hi,badgeHeavyInvestor:ui,badgeZeroSkip:pi,badgeAscensionStar:ci};function ve(f){return f<=1?mi:f===2?fi:f===3?gi:yi}const Ai={damage:yt,bounces:bt,multiorb:ki,orbsize:xi,luck:vi,orevalue:wi},Ei={chain_detonator:D.badgeChainDetonator,combo_master:D.badgeComboMaster,heavy_investor:D.badgeHeavyInvestor,zero_skip_purist:D.badgeZeroSkip};class Ci{constructor(e){c(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}open(e,t,s){this.render(e,t,s),this.backdrop.style.display="flex"}render(e,t,s){const i=e.ascensionTier,a=ot(i),n=lt(i),r=ct(i),d=Math.round((dt(i)-1)*100),l=i>0?ve(i):D.badgeAscensionStar,o=i>0?`${g.t("tier_label").toUpperCase()} ${re(i)}`:g.t("no_ascension_yet"),h=Be.map(p=>{const u=i>=p.tier,b=e.ascensionRecords.find(k=>p.tier===4?k.tier>=4:k.tier===p.tier),_=ve(p.tier),v=re(p.tier);return`
        <div class="rm-achievement-card ${u?"unlocked":"locked"}">
          <div class="rm-icon-socket" style="border-color:${u?"#fbbf24":"#3b3531"};">
            <img src="${_}" style="${u?"":"filter:grayscale(1) brightness(0.45);"}" alt="" />
          </div>
          <div style="flex:1;min-width:0;">
            <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
              <span style="font-weight:900;font-size:13px;color:${u?"#fde047":"#94a3b8"};">
                ${g.t(p.titleKey)} (${g.t("tier_label")} ${v}${p.tier===4?"+":""})
              </span>
            </div>
            <div style="font-size:11px;color:${u?"#e2e8f0":"#94a3b8"};">
              ${b?`${g.t("blocks_smashed")}: ${N(b.blocksSmashed)} • ${g.t("max_combo_label")}: ${b.maxCombo}x`:g.t("asc_req_hint").replace("{tier}",v)}
            </div>
          </div>
          <span class="rm-lv-pill" style="border-color:${u?"#4ade80":"#4a3728"};color:${u?"#4ade80":"#94a3b8"};">
            ${x(u?"check":"lock")}
          </span>
        </div>
      `}).join(""),m=rt.map(p=>{const u=e.unlockedAchievements.includes(p.id),b=e.claimedAchievements.includes(p.id),_=Ei[p.id]??D.trophy;return`
        <div class="rm-achievement-card ${u?"unlocked":"locked"}">
          <div class="rm-icon-socket" style="border-color:${u?"#fbbf24":"#3b3531"};">
            <img src="${_}" style="${u?"":"filter:grayscale(1) brightness(0.45);"}" alt="" />
          </div>
          <div style="flex:1;min-width:0;">
            <div style="font-weight:900;font-size:13px;color:${u?"#fffbeb":"#94a3b8"};">
              ${g.t(p.nameKey)}
            </div>
            <div style="font-size:11px;color:#cbd5e1;">
              ${g.t(p.descKey)}
            </div>
          </div>
          ${b?`<span class="rm-lv-pill" style="color:#4ade80;border-color:#4ade80;">${g.t("claimed")}</span>`:u?`<button class="rm-btn rm-btn-green" style="min-height:36px;padding:4px 9px;font-size:11px;" data-feat-claim="${p.id}">
                  ${x("coin")} +${N(p.rewardCoins)}
                </button>`:`<span class="rm-lv-pill">${N(p.rewardCoins)}</span>`}
        </div>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div class="rm-modal-header">
          <div class="rm-header-plaque">
            <img src="${D.trophy}" style="width:22px;height:22px;object-fit:contain;" alt="" />
            ${g.t("hall_of_ascension")}
          </div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>

        <div class="rm-stat-plaque" style="flex-direction:row;justify-content:space-between;padding:8px 10px;border-color:#8c5a2b;flex-shrink:0;">
          <div style="display:flex;align-items:center;gap:10px;">
            <img src="${l}" style="width:44px;height:44px;object-fit:contain;" alt="" />
            <div>
              <div style="font-weight:900;font-size:13px;color:#fde047;">${o}</div>
              <div style="font-size:11px;color:#e2e8f0;font-weight:800;">
                ${a}x HP • ${n.toFixed(2).replace(/\.00$/,"")}x ${g.t("coins")} • +${r} Cap • +${d}% DMG
              </div>
            </div>
          </div>
        </div>

        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">
            <div style="font-size:11px;font-weight:900;color:#fbbf24;letter-spacing:0.6px;margin-top:2px;">
              ${g.t("ascension_milestones").toUpperCase()}
            </div>
            ${h}
            <div style="font-size:11px;font-weight:900;color:#38bdf8;letter-spacing:0.6px;margin-top:6px;">
              ${g.t("mastery_feats").toUpperCase()}
            </div>
            ${m}
          </div>
        </div>
      </div>
    `,this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelectorAll("[data-feat-claim]").forEach(p=>{p.addEventListener("click",()=>{t(p.dataset.featClaim),this.render(e,t,s)})})}hide(){this.backdrop.style.display="none"}}class ee{static isAvailable(){return S.canShowRewardedAds()}static renderMarkup(e){if(this.isAvailable()){const t=e.className??"rm-btn rm-btn-gold",s=e.style?` style="${e.style}"`:"";return`<button class="${t}"${s} data-ad-cta="true" ${e.attrs}>${x("adPlay")} ${e.labelHtml}</button>`}if(e.fallbackMode==="coin_alt"&&e.coinAltHtml){const t=e.coinAltClassName??"rm-btn rm-btn-green",s=e.style?` style="${e.style}"`:"",i=e.coinAltDisabled?" disabled":"";return`<button class="${t}"${s} ${e.coinAltAttrs??""}${i}>${e.coinAltHtml}</button>`}return""}static syncVisibility(e,t=!0){if(!e)return;const s=t&&this.isAvailable();e.style.display=s?"inline-flex":"none"}}function et(f){const e=Math.max(1,Math.min(4,f));return new Array(e).fill('<svg viewBox="0 0 24 24" width="22" height="22" fill="none"><path d="M12 2l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 16.9 6.1 20l1.2-6.5L2.5 8.9l6.6-.9L12 2z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>').join("")}class Ri{constructor(e){c(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}show(e){const t=ht(e.newTier),s=g.t(t.titleKey),i=g.t(t.quoteKey),a=re(e.newTier),n=re(e.newTier+1),r=ve(e.newTier),d=ve(e.newTier+1),l=e.coinsEarned>0?ee.renderMarkup({labelHtml:g.t("double_victory_coins"),attrs:'data-vic="double"',className:"rm-btn rm-btn-gold",style:"flex:1;min-height:44px;",fallbackMode:"hide"}):"";this.backdrop.innerHTML=`
      <div class="arcade-modal-shell rm-victory-shell">
        <div class="rm-sunburst" aria-hidden="true"></div>

        <div class="rm-victory-crest-wrap">
          <div class="rm-victory-stars">${et(Math.min(2,e.newTier))}</div>
          <img src="${r}" class="rm-victory-crest" alt="" />
          <div class="rm-victory-stars">${et(Math.min(2,Math.max(1,e.newTier-1)))}</div>
        </div>

        <div class="rm-victory-ribbon">${g.t("one_shot_victory")}</div>

        <div style="text-align:center;position:relative;z-index:2;">
          <div class="rm-victory-title">${s.toUpperCase()} — ${g.t("tier_label").toUpperCase()} ${a}</div>
          <div class="rm-victory-quote">"${i}"</div>
        </div>

        <div class="rm-scroll-area" style="position:relative;z-index:2;">
          <div class="rm-stat-row">
            <div class="rm-stat-plaque">
              <img src="${D.drillDamage}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${g.t("blocks_smashed").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fffbeb;text-shadow:0 2px 0 #120c08;">${N(e.blocksSmashed)}</div>
            </div>
            <div class="rm-stat-plaque">
              <img src="${D.maxBounces}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${g.t("max_combo_label").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fde047;text-shadow:0 2px 0 #120c08;">${e.maxCombo}x</div>
            </div>
            <div class="rm-stat-plaque">
              <span class="rm-stat-coin-svg">${x("coin")}</span>
              <div style="font-size:10px;color:#cbd5e1;font-weight:900;letter-spacing:0.4px;">${g.t("earned_coins").toUpperCase()}</div>
              <div style="font-size:20px;font-weight:900;color:#fbbf24;text-shadow:0 2px 0 #120c08;" data-vic="coins">${N(e.coinsEarned)}</div>
            </div>
            <div class="rm-stat-plaque" style="border-color:#d97706;">
              <img src="${d}" style="width:32px;height:32px;object-fit:contain;" alt="" />
              <div style="font-size:10px;color:#fde68a;font-weight:900;letter-spacing:0.4px;">${g.t("next_tier_label").toUpperCase()} ${n}</div>
              <div style="font-size:10px;font-weight:900;color:#fffbeb;text-align:center;line-height:1.25;">${g.t("next_tier_preview")}</div>
            </div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;position:relative;z-index:2;flex-shrink:0;">
          <button class="rm-btn rm-btn-ascend" style="width:100%;min-height:48px;font-size:14px;" data-vic="descend">
            ${g.t("descend_to_tier").replace("{tier}",n)}
          </button>
          <div style="display:flex;gap:8px;">
            <button class="rm-btn rm-btn-primary" style="flex:1;min-height:44px;" data-vic="upgrades">
              <img src="${D.drillDamage}" style="width:18px;height:18px;object-fit:contain;" alt="" />
              ${g.t("upgrades").toUpperCase()}
            </button>
            ${l}
          </div>
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-vic="descend"]')?.addEventListener("click",()=>{this.hide(),e.onDescendNextTier()}),this.backdrop.querySelector('[data-vic="upgrades"]')?.addEventListener("click",()=>{this.hide(),e.onOpenUpgrades()});const o=this.backdrop.querySelector('[data-vic="double"]');o?.addEventListener("click",async()=>{if(o.disabled=!0,await e.onDoubleVictoryCoins()){const m=this.backdrop.querySelector('[data-vic="coins"]');m&&(m.textContent=N(e.coinsEarned*2)),o.style.display="none"}else ee.isAvailable()?o.disabled=!1:o.style.display="none"})}hide(){this.backdrop.style.display="none"}}class Bi{constructor(e,t){c(this,"panel",null)}}const tt='<svg viewBox="0 0 36 36" width="34" height="34" fill="none"><circle cx="18" cy="18" r="11" stroke="#fde047" stroke-width="2.5" stroke-dasharray="4 3"/><circle cx="18" cy="18" r="4" fill="#fbbf24" stroke="#181210" stroke-width="2"/><path d="M18 3v6M18 27v6M3 18h6M27 18h6" stroke="#fde047" stroke-width="2.5" stroke-linecap="round"/></svg>';class Ii{constructor(e){c(this,"el");c(this,"iconEl");c(this,"pillEl");c(this,"aimMode","direct");this.el=document.createElement("div"),this.el.className="rm-ftue",this.el.innerHTML=`
      <div class="rm-ftue-hand">${tt}</div>
      <div class="rm-pill rm-ftue-pill" style="margin-top:6px;border-color:#fde047;color:#fde047;">
        ${g.t("click_to_shoot")}
      </div>
    `,e.appendChild(this.el),this.iconEl=this.el.querySelector(".rm-ftue-hand"),this.pillEl=this.el.querySelector(".rm-ftue-pill")}setAimMode(e){this.aimMode=e,this.refreshText()}updateLayout(e){const s=e.topOffsetPx+152*e.scale;this.el.style.top=`${Math.round(s)}px`}setVisible(e){this.el.style.display=e?"block":"none"}refreshText(){this.aimMode==="slingshot"?(this.iconEl.className="rm-ftue-hand",this.iconEl.innerHTML=x("handPointer"),this.pillEl.textContent=g.t("drag_to_shoot")):(this.iconEl.className="rm-ftue-reticle",this.iconEl.innerHTML=tt,this.pillEl.textContent=g.t("click_to_shoot"))}}const Di='<svg viewBox="0 0 24 24" width="14" height="14" fill="none"><path d="M12 2l2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 8.3l6-.8L12 2z" fill="#fde047" stroke="#1a1310" stroke-width="2" stroke-linejoin="round"/></svg>';class Li{constructor(e,t){c(this,"root");c(this,"topEl");c(this,"depthEl");c(this,"coinsEl");c(this,"biomeEl");c(this,"crestPillEl");c(this,"crestTextEl");c(this,"bouncesEl");c(this,"aimModeBtn");c(this,"aimModeLblEl");c(this,"muteBtn");c(this,"speedBtn");c(this,"recallBtn");c(this,"overdriveBtn");c(this,"shopBtn");c(this,"shopBadgeEl");c(this,"achievementsBtn");c(this,"achievementsDotEl");c(this,"questBtn");c(this,"questDotEl");c(this,"loginBtn");c(this,"loginDotEl");c(this,"elevatorBtn");c(this,"toastEl");c(this,"toastTimer",null);c(this,"arcadeConsole");c(this,"runningBar");c(this,"bossRowEl");c(this,"bossBarEl");c(this,"bossTextEl");c(this,"bossFillEl");c(this,"bossIcoEl");c(this,"fullShaftPillEl");c(this,"gateHpBarEl");c(this,"gateTitleEl");c(this,"gateHpTextEl");c(this,"gateHpFillEl");this.root=e;const s=document.createElement("div");s.className="rm-hud-stack",this.root.appendChild(s),this.topEl=document.createElement("div"),this.topEl.className="rm-hud-top",this.topEl.innerHTML=`
      <div class="rm-pill-row">
        <div class="rm-pill">${x("coin")} <span data-hud="coins">0</span></div>
        <div class="rm-pill">${x("pickaxe")} <span data-hud="depth">0m</span></div>
        <div class="rm-pill"><span data-hud="biome">Sunlit Quarry</span></div>
        <div class="rm-ascension-crest-pill" data-hud="crest-pill" style="display:none;">
          <img src="${D.badgeAscensionStar}" style="width:16px;height:16px;object-fit:contain;" alt="" />
          <span data-hud="crest-text">TIER I</span>
        </div>
        <div class="rm-pill" data-hud="bounces-pill" style="display:none;">${x("lightning")} <span data-hud="bounces">0</span></div>
      </div>
      <div class="rm-pill-row rm-pill-row-nowrap">
        <button class="rm-btn" data-interactive="true" data-hud="aim-mode" style="display:none;min-height:34px;padding:4px 8px;font-size:11px;" aria-label="Aim Mode">
          ${x("orb")} <span data-hud="aim-mode-lbl">Direct</span>
        </button>
        <button class="rm-btn" data-interactive="true" data-hud="pause" aria-label="Pause">${x("pause")}</button>
        <button class="rm-btn" data-interactive="true" data-hud="mute" aria-label="Mute">${x("soundOn")}</button>
      </div>
    `,s.appendChild(this.topEl),this.bossRowEl=document.createElement("div"),this.bossRowEl.className="rm-boss-row",this.bossRowEl.style.display="none",s.appendChild(this.bossRowEl),this.bossBarEl=document.createElement("div"),this.bossBarEl.className="rm-boss-bar",this.bossBarEl.innerHTML=`
      <span data-hud="boss-ico" class="rm-boss-pulse">${x("bossCore")}</span>
      <span data-hud="boss-text">0m / 150m to Biome 2 Boss</span>
      <div class="rm-boss-track"><div class="rm-boss-fill" data-hud="boss-fill" style="width:0%;"></div></div>
    `,this.bossRowEl.appendChild(this.bossBarEl),this.bossTextEl=this.bossBarEl.querySelector('[data-hud="boss-text"]'),this.bossFillEl=this.bossBarEl.querySelector('[data-hud="boss-fill"]'),this.bossIcoEl=this.bossBarEl.querySelector('[data-hud="boss-ico"]'),this.fullShaftPillEl=document.createElement("div"),this.fullShaftPillEl.className="rm-fullshaft-pill",this.fullShaftPillEl.innerHTML=`<span class="rm-ico" aria-hidden="true">${Di}</span> <span data-lbl="fullshaft">${g.t("full_shaft_run")}</span>`,this.bossRowEl.appendChild(this.fullShaftPillEl),this.gateHpBarEl=document.createElement("div"),this.gateHpBarEl.className="rm-gate-hp-bar",this.gateHpBarEl.innerHTML=`
      <div class="rm-gate-hp-head">
        <span style="display:inline-flex;align-items:center;gap:5px;">${x("bossCore")} <span data-hud="gate-title">${g.t("boss_gate")}</span></span>
        <span data-hud="gate-hp-text">0 / 0</span>
      </div>
      <div class="rm-gate-hp-track">
        <div class="rm-gate-hp-fill" data-hud="gate-hp-fill" style="width:100%;"></div>
      </div>
    `,s.appendChild(this.gateHpBarEl),this.gateTitleEl=this.gateHpBarEl.querySelector('[data-hud="gate-title"]'),this.gateHpTextEl=this.gateHpBarEl.querySelector('[data-hud="gate-hp-text"]'),this.gateHpFillEl=this.gateHpBarEl.querySelector('[data-hud="gate-hp-fill"]'),this.coinsEl=this.topEl.querySelector('[data-hud="coins"]'),this.depthEl=this.topEl.querySelector('[data-hud="depth"]'),this.biomeEl=this.topEl.querySelector('[data-hud="biome"]'),this.crestPillEl=this.topEl.querySelector('[data-hud="crest-pill"]'),this.crestTextEl=this.topEl.querySelector('[data-hud="crest-text"]'),this.bouncesEl=this.topEl.querySelector('[data-hud="bounces"]'),this.aimModeBtn=this.topEl.querySelector('[data-hud="aim-mode"]'),this.aimModeLblEl=this.topEl.querySelector('[data-hud="aim-mode-lbl"]'),this.aimModeBtn.addEventListener("click",t.onToggleAimMode),this.muteBtn=this.topEl.querySelector('[data-hud="mute"]'),this.muteBtn.addEventListener("click",t.onToggleMute),this.topEl.querySelector('[data-hud="pause"]')?.addEventListener("click",t.onTogglePause),this.runningBar=document.createElement("div"),this.runningBar.className="rm-bottom-bar",this.runningBar.style.display="none",this.runningBar.innerHTML=`
      <button class="rm-btn" data-interactive="true" data-hud="speed">${x("fastForward")} <span data-lbl="speed">${g.t("fast_forward")}</span></button>
      <button class="rm-btn rm-btn-gold" data-interactive="true" data-hud="recall">${x("recall")} <span data-lbl="recall">${g.t("recall")}</span></button>
    `,this.root.appendChild(this.runningBar),this.speedBtn=this.runningBar.querySelector('[data-hud="speed"]'),this.recallBtn=this.runningBar.querySelector('[data-hud="recall"]'),this.speedBtn.addEventListener("click",t.onToggleSpeed),this.recallBtn.addEventListener("click",t.onRecall),this.arcadeConsole=document.createElement("div"),this.arcadeConsole.className="rm-arcade-console",this.arcadeConsole.innerHTML=`
      <button class="rm-btn rm-btn-primary" data-interactive="true" data-hud="shop">
        ${x("upgradePickaxe")} <span data-lbl="upgrades">${g.t("upgrades").toUpperCase()}</span>
        <span class="rm-badge-count" data-hud="shop-badge" style="display:none;">0</span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="achievements">
        <img src="${D.trophy}" style="width:18px;height:18px;object-fit:contain;" alt="" />
        <span data-lbl="achievements">${g.t("achievements")}</span>
        <span class="rm-dot" data-hud="ach-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="quests">
        ${x("questClipboard")} <span data-lbl="quests">${g.t("quests")}</span>
        <span class="rm-dot" data-hud="quest-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="login">
        ${x("streakArrows")} <span data-lbl="streak">${g.t("streak_short")}</span>
        <span class="rm-dot" data-hud="login-dot" style="display:none;"></span>
      </button>
      <button class="rm-btn" data-interactive="true" data-hud="elevator" style="display:none;">
        ${x("elevatorCar")} <span data-lbl="elevator">${g.t("elevator")}</span>
      </button>
      <button class="rm-btn rm-btn-gold" data-interactive="true" data-hud="overdrive" style="display:none;flex-direction:column;gap:1px;padding:6px 10px;">
        <span style="display:inline-flex;align-items:center;gap:6px;">${x("adPlay")} <span data-lbl="superorb">${g.t("super_orb_label")}</span></span>
        <span data-lbl="freead" style="font-size:10px;opacity:0.9;">${g.t("free_ad_sub")}</span>
      </button>
    `,this.root.appendChild(this.arcadeConsole),this.shopBtn=this.arcadeConsole.querySelector('[data-hud="shop"]'),this.shopBadgeEl=this.arcadeConsole.querySelector('[data-hud="shop-badge"]'),this.achievementsBtn=this.arcadeConsole.querySelector('[data-hud="achievements"]'),this.achievementsDotEl=this.arcadeConsole.querySelector('[data-hud="ach-dot"]'),this.questBtn=this.arcadeConsole.querySelector('[data-hud="quests"]'),this.questDotEl=this.arcadeConsole.querySelector('[data-hud="quest-dot"]'),this.loginBtn=this.arcadeConsole.querySelector('[data-hud="login"]'),this.loginDotEl=this.arcadeConsole.querySelector('[data-hud="login-dot"]'),this.elevatorBtn=this.arcadeConsole.querySelector('[data-hud="elevator"]'),this.overdriveBtn=this.arcadeConsole.querySelector('[data-hud="overdrive"]'),this.shopBtn.addEventListener("click",t.onOpenShop),this.achievementsBtn.addEventListener("click",t.onOpenAchievements),this.questBtn.addEventListener("click",t.onOpenQuests),this.loginBtn.addEventListener("click",t.onOpenDailyLogin),this.elevatorBtn.addEventListener("click",t.onOpenElevator),this.overdriveBtn.addEventListener("click",t.onTriggerOverdriveAd),this.toastEl=document.createElement("div"),this.toastEl.className="rm-toast",this.toastEl.style.display="none",this.root.appendChild(this.toastEl),S.onAdAvailabilityChange(()=>{ee.isAvailable()||(this.overdriveBtn.style.display="none")})}refreshLabels(){const e=(t,s)=>{const i=this.root.querySelector(t);i&&(i.textContent=s)};e('[data-lbl="speed"]',g.t("fast_forward")),e('[data-lbl="recall"]',g.t("recall")),e('[data-lbl="upgrades"]',g.t("upgrades").toUpperCase()),e('[data-lbl="achievements"]',g.t("achievements")),e('[data-lbl="quests"]',g.t("quests")),e('[data-lbl="streak"]',g.t("streak_short")),e('[data-lbl="elevator"]',g.t("elevator")),e('[data-lbl="superorb"]',g.t("super_orb_label")),e('[data-lbl="freead"]',g.t("free_ad_sub")),e('[data-lbl="fullshaft"]',g.t("full_shaft_run"))}update(e){if(this.topEl.style.display=e.isTitle?"none":"flex",this.bossRowEl.style.display=e.isTitle?"none":"flex",this.bossTextEl.textContent=e.bossProgressText,this.bossFillEl.style.width=`${Math.max(0,Math.min(100,e.bossProgressPct))}%`,this.bossIcoEl.classList.toggle("rm-boss-pulse",e.bossNear||e.isRunning),this.fullShaftPillEl.style.display=e.isFullShaftRun?"inline-flex":"none",e.ascensionTier>=1?(this.crestPillEl.style.display="inline-flex",this.crestTextEl.textContent=`${g.t("tier_label").toUpperCase()} ${re(e.ascensionTier)}`):this.crestPillEl.style.display="none",!e.isTitle&&e.activeGate&&e.activeGate.maxHp>0){const s=Math.max(0,Math.min(100,e.activeGate.hp/e.activeGate.maxHp*100));this.gateHpBarEl.style.display="flex",this.gateHpBarEl.classList.toggle("critical",s<=20),this.gateTitleEl.textContent=`${g.t("boss_gate")} (${e.activeGate.coresAlive}/3)`,this.gateHpTextEl.textContent=`${N(Math.ceil(e.activeGate.hp))} / ${N(Math.ceil(e.activeGate.maxHp))}`,this.gateHpFillEl.style.width=`${s}%`}else this.gateHpBarEl.style.display="none",this.gateHpBarEl.classList.remove("critical");this.coinsEl.textContent=N(e.coins),this.depthEl.textContent=Le(e.depthMeters),this.biomeEl.textContent=e.biomeName,this.muteBtn.innerHTML=x(e.muted?"soundOff":"soundOn");const t=this.topEl.querySelector('[data-hud="bounces-pill"]');t&&(t.style.display=e.isRunning?"inline-flex":"none"),this.bouncesEl.textContent=Math.ceil(e.bouncesLeft).toString(),this.runningBar.style.display=e.isRunning?"flex":"none",this.aimModeBtn.style.display=e.isAiming?"inline-flex":"none",this.aimModeLblEl.textContent=e.aimMode==="slingshot"?g.t("aim_slingshot"):g.t("aim_direct"),this.speedBtn.style.borderColor=e.speedMult>1?"#fde047":"#1a1310",this.arcadeConsole.style.display=e.isAiming?"flex":"none",this.elevatorBtn.style.display=e.hasElevator?"inline-flex":"none",ee.syncVisibility(this.overdriveBtn,e.showOverdriveOffer&&e.isAiming&&!e.isRunning),this.achievementsDotEl.style.display=e.hasUnclaimedFeats?"block":"none",this.loginDotEl.style.display=e.hasClaimableLogin?"block":"none",this.questDotEl.style.display=e.hasClaimableQuest?"block":"none",this.shopBadgeEl.style.display=e.affordableUpgradeCount>0?"inline-flex":"none",this.shopBadgeEl.textContent=e.affordableUpgradeCount.toString()}showToast(e,t=2200){this.toastEl.textContent=e,this.toastEl.style.display="block",this.toastTimer!==null&&window.clearTimeout(this.toastTimer),this.toastTimer=window.setTimeout(()=>{this.toastEl.style.display="none",this.toastTimer=null},t)}}class Oi{constructor(e){c(this,"backdrop");this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}showOfflineModal(e,t){const s=ee.renderMarkup({labelHtml:g.t("collect_2x"),attrs:'data-act="collect2x"',className:"rm-btn rm-btn-gold",style:"flex:1;min-height:48px;",fallbackMode:"hide"});this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.chest}" class="rm-crown-icon" alt="" />
        <div style="display:flex;justify-content:center;">
          <div class="rm-header-plaque">${g.t("welcome_back")}</div>
        </div>
        <p style="margin:0;text-align:center;color:#cbd5e1;font-size:13px;">${g.t("offline_earned")}</p>
        <div class="rm-stat-plaque" style="flex-direction:row;justify-content:center;gap:10px;">
          <span class="rm-stat-coin-svg">${x("coin")}</span>
          <span style="font-size:26px;font-weight:900;color:#fbbf24;">${N(e)}</span>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="rm-btn rm-btn-green" style="flex:1;min-height:48px;" data-act="collect">${g.t("collect")}</button>
          ${s}
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="collect"]')?.addEventListener("click",()=>{this.hide(),t(!1)}),this.backdrop.querySelector('[data-act="collect2x"]')?.addEventListener("click",()=>{this.hide(),t(!0)})}showDailyLogin(e,t,s){const i=G.LOGIN_REWARDS.map(a=>{const n=a.day===e.loginStreak.day,r=a.day<e.loginStreak.day||n&&e.loginStreak.claimedToday;return`
        <div class="rm-upgrade-plaque" style="justify-content:space-between;border-color:${n?"#fbbf24":"#120c08"};">
          <span style="font-weight:900;font-size:13px;">Day ${a.day}: ${g.t(a.labelKey)}</span>
          <span style="font-size:12px;color:${r?"#4ade80":"#fbbf24"};">${r?x("check"):n?"READY":x("lock")}</span>
        </div>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.chest}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${g.t("daily_login")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${i}</div></div>
        ${e.loginStreak.claimedToday?`<button class="rm-btn" disabled>${g.t("claimed")}</button>`:`<button class="rm-btn rm-btn-green" data-act="claim">${g.t("claim")}</button>`}
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelector('[data-act="claim"]')?.addEventListener("click",()=>{t(),this.hide(),s()})}showDailyQuests(e,t,s,i,a){const n=e.dailyQuests.quests.map(d=>{const l=G.DAILY_QUEST_POOL.find(m=>m.id===d.id),o=l?g.t(l.labelKey):d.id,h=d.progress>=d.target;return`
          <div class="rm-upgrade-plaque" style="justify-content:space-between;">
            <div>
              <div style="font-weight:900;font-size:13px;">${o}</div>
              <div style="font-size:12px;color:#cbd5e1;display:inline-flex;align-items:center;gap:5px;">
                ${d.progress}/${d.target}
                ${x("coin")}
                ${l?.rewardCoins??0}
              </div>
            </div>
            ${d.claimed?`${x("check")}`:h?`<button class="rm-btn rm-btn-green" style="min-height:36px;" data-qclaim="${d.id}">${g.t("claim")}</button>`:`<span class="rm-lv-pill">${d.progress}/${d.target}</span>`}
          </div>
        `}).join(""),r=t.canClaimMegaChest(e);this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.chest}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${g.t("quests")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${n}</div></div>
        <button class="rm-btn rm-btn-gold" data-act="mega" ${r?"":"disabled"}>
          <img src="${D.chest}" style="width:22px;height:22px;object-fit:contain;" alt="" />
          ${g.t("daily_mega_chest")}
        </button>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),a()}),this.backdrop.querySelectorAll("[data-qclaim]").forEach(d=>{d.addEventListener("click",()=>{s(d.dataset.qclaim)})}),this.backdrop.querySelector('[data-act="mega"]')?.addEventListener("click",i)}showElevator(e,t,s){const i=O.map(a=>{const n=a.index<=e.unlockedBiomeIndex;return`
        <button class="rm-btn ${a.index===e.selectedBiomeIndex?"rm-btn-primary":""}" data-biome="${a.index}" ${n?"":"disabled"} style="justify-content:space-between;">
          <span>${g.t(a.nameKey)} (${a.startDepthM}m)</span>
          <span class="rm-lv-pill">${n?`${a.coinMultiplier}x`:x("lock")}</span>
        </button>
      `}).join("");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.gearElevator}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${g.t("elevator")}</div>
          <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
        </div>
        <div class="rm-scroll-area"><div class="rm-upgrade-list">${i}</div></div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelectorAll("[data-biome]").forEach(a=>{a.addEventListener("click",()=>{t(Number(a.dataset.biome)),this.hide(),s()})})}showPauseModal(e,t,s,i){this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div style="display:flex;justify-content:center;">
          <div class="rm-header-plaque">${x("pause")} ${g.t("paused")}</div>
        </div>
        <button class="rm-btn rm-btn-green" style="min-height:48px;" data-act="resume">${x("play")} ${g.t("resume")}</button>
        <button class="rm-btn" data-act="restart">${x("restart")} ${g.t("restart_run")}</button>
        <div style="display:flex;gap:8px;">
          <button class="rm-btn" style="flex:1;" data-act="settings">
            <img src="${D.gearElevator}" style="width:20px;height:20px;object-fit:contain;" alt="" /> ${g.t("settings")}
          </button>
          <button class="rm-btn rm-btn-gold" style="flex:1;" data-act="home">${x("home")} ${g.t("home_btn")}</button>
        </div>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="resume"]')?.addEventListener("click",()=>{this.hide(),e()}),this.backdrop.querySelector('[data-act="restart"]')?.addEventListener("click",()=>{this.hide(),t()}),this.backdrop.querySelector('[data-act="settings"]')?.addEventListener("click",()=>{this.hide(),s()}),this.backdrop.querySelector('[data-act="home"]')?.addEventListener("click",()=>{this.hide(),i()})}showBiomeUnlockModal(e,t,s,i){const a=s.length>0?`<div class="rm-stat-plaque" style="border-color:#4ade80;padding:8px;">
            <div style="font-size:11px;color:#86efac;font-weight:900;">${g.t("skin_unlocked_badge").toUpperCase()}</div>
            <div style="font-size:15px;font-weight:900;color:#fffbeb;">${s.join(", ")}</div>
          </div>`:"";this.backdrop.innerHTML=`
      <div class="arcade-modal-shell" style="border-color:#fbbf24;">
        <img src="${D.trophy}" class="rm-crown-icon" style="width:68px;height:68px;" alt="" />
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
          <div class="rm-new-best">${g.t("biome_unlocked_desc").toUpperCase()}</div>
          <div class="rm-header-plaque" style="color:#fde047;">${g.t("biome_unlocked_title")}</div>
        </div>
        <div class="rm-stat-plaque" style="border-color:#fbbf24;">
          <div style="font-size:22px;font-weight:900;color:#38bdf8;text-shadow:0 2px 0 #120c08;">${e}</div>
          <div style="font-size:14px;font-weight:900;color:#fbbf24;">${t}x ${g.t("coin_mult_badge")}</div>
        </div>
        ${a}
        <button class="rm-btn rm-btn-green" style="min-height:50px;font-size:16px;" data-act="biome-go">
          ${x("elevatorCar")} ${g.t("descend_now")}
        </button>
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="biome-go"]')?.addEventListener("click",()=>{this.hide(),i()})}hide(){this.backdrop.style.display="none"}}class Pi{constructor(e){c(this,"backdrop");c(this,"isOpen",!1);c(this,"lastOpts",null);this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop),S.onAdAvailabilityChange(()=>{this.isOpen&&this.lastOpts&&this.show(this.lastOpts)})}show(e){this.isOpen=!0,this.lastOpts=e;const t=re((e.currentAscensionTier??0)+1),s=e.clearedBiome6ViaElevator?`
        <div class="rm-teaser-banner">
          <img src="${D.badgeZeroSkip}" style="width:42px;height:42px;object-fit:contain;flex-shrink:0;" alt="" />
          <div style="flex:1;min-width:0;">
            <div style="font-weight:900;font-size:13px;color:#fde047;">${g.t("elevator_clear_title")}</div>
            <div style="font-size:11px;color:#fffbeb;line-height:1.3;">${g.t("elevator_clear_desc").replace("{tier}",t)}</div>
          </div>
          <button class="rm-btn rm-btn-gold" style="min-height:38px;padding:6px 10px;font-size:11px;flex-shrink:0;" data-act="start0m">
            ${g.t("start_0m_run")}
          </button>
        </div>
      `:"",i=e.showExtraLaunchAd?ee.renderMarkup({labelHtml:g.t("extra_launch_cta"),attrs:'data-act="extra"',className:"rm-btn rm-btn-gold",style:"min-height:48px;",fallbackMode:"hide"}):"",a=e.showDoubleAd?ee.renderMarkup({labelHtml:`${x("coin")} ${g.t("double_run_cta")}`,attrs:'data-act="double"',className:"rm-btn rm-btn-gold",style:"min-height:48px;",fallbackMode:"hide"}):"";this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.trophy}" class="rm-crown-icon" style="width:64px;height:64px;" alt="" />
        <div style="display:flex;flex-direction:column;align-items:center;gap:4px;">
          ${e.isNewBest?`<div class="rm-new-best">${g.t("new_best_badge")}</div>`:""}
          <div class="rm-header-plaque">${g.t("run_complete")}</div>
        </div>

        ${s}

        <div class="rm-stat-row">
          <div class="rm-stat-plaque">
            <span class="rm-stat-coin-svg">${x("coin")}</span>
            <div style="font-size:11px;color:#cbd5e1;font-weight:800;">${g.t("earned_coins")}</div>
            <div style="font-size:21px;font-weight:900;color:#fbbf24;text-shadow:0 2px 0 #120c08;">${N(e.coinsEarned)}</div>
          </div>
          <div class="rm-stat-plaque">
            <img src="${D.drillDamage}" style="width:36px;height:36px;object-fit:contain;" alt="" />
            <div style="font-size:11px;color:#cbd5e1;font-weight:800;">${g.t("max_depth")}</div>
            <div style="font-size:21px;font-weight:900;color:#fffbeb;text-shadow:0 2px 0 #120c08;">${Le(e.maxDepthMeters)}</div>
          </div>
        </div>

        <div style="display:flex;gap:8px;">
          <button class="rm-btn rm-btn-green" style="flex:1;min-height:48px;" data-act="relaunch">
            ${x("play")} ${g.t("launch_again")}
          </button>
          <button class="rm-btn rm-btn-primary" style="flex:1;min-height:48px;" data-act="shop">
            <img src="${D.drillDamage}" style="width:20px;height:20px;object-fit:contain;" alt="" />
            ${g.t("upgrades")}
            ${e.affordableUpgradeCount>0?`<span class="rm-badge-count">${e.affordableUpgradeCount}</span>`:""}
          </button>
        </div>

        ${i}
        ${a}
      </div>
    `,this.backdrop.style.display="flex",this.backdrop.querySelector('[data-act="start0m"]')?.addEventListener("click",()=>{this.hide(),e.onStartZeroMeterRun?.()}),this.backdrop.querySelector('[data-act="relaunch"]')?.addEventListener("click",()=>{this.hide(),e.onRelaunch()}),this.backdrop.querySelector('[data-act="shop"]')?.addEventListener("click",()=>{this.hide(),e.onOpenShop()}),this.backdrop.querySelector('[data-act="double"]')?.addEventListener("click",e.onDoubleAd),this.backdrop.querySelector('[data-act="extra"]')?.addEventListener("click",e.onExtraLaunchAd)}hide(){this.isOpen=!1,this.lastOpts=null,this.backdrop.style.display="none"}}const Ui=[{code:"en",label:"English"},{code:"ru",label:"Русский"},{code:"es",label:"Español"},{code:"pt",label:"Português"},{code:"fr",label:"Français"},{code:"de",label:"Deutsch"},{code:"tr",label:"Türkçe"},{code:"ja",label:"日本語"},{code:"ko",label:"한국어"}];class Ni{constructor(e){c(this,"backdrop");c(this,"confirmingReset",!1);this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",e.appendChild(this.backdrop)}open(e,t,s){this.confirmingReset=!1,this.render(e,t,s),this.backdrop.style.display="flex"}render(e,t,s){if(this.confirmingReset){this.backdrop.innerHTML=`
        <div class="arcade-modal-shell">
          <div style="display:flex;justify-content:center;">
            <div class="rm-header-plaque" style="color:#fca5a5;">${g.t("reset_progress")}</div>
          </div>
          <p style="margin:0;text-align:center;color:#e2e8f0;font-size:14px;line-height:1.45;">
            ${g.t("reset_confirm_desc")}
          </p>
          <div style="display:flex;gap:10px;">
            <button class="rm-btn rm-btn-primary" style="flex:1;" data-set="cancel-reset">${g.t("cancel_btn")}</button>
            <button class="rm-btn rm-btn-crimson" style="flex:1;" data-set="confirm-reset">${g.t("confirm_reset_btn")}</button>
          </div>
        </div>
      `,this.backdrop.querySelector('[data-set="cancel-reset"]')?.addEventListener("click",()=>{this.confirmingReset=!1,this.render(e,t,s)}),this.backdrop.querySelector('[data-set="confirm-reset"]')?.addEventListener("click",()=>{this.hide(),s.onConfirmReset()});return}const i=Ui.map(n=>`<option value="${n.code}" ${n.code===t?"selected":""}>${n.label}</option>`).join(""),a=e.settings.musicVolume??(e.settings.musicMuted?"off":"high");this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <img src="${D.gearElevator}" class="rm-crown-icon" alt="" />
        <div class="rm-modal-header">
          <div class="rm-header-plaque">${g.t("settings")}</div>
          <button class="rm-btn rm-close-btn" data-set="close" aria-label="Close">${x("close")}</button>
        </div>

        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">
            <button class="rm-btn" style="justify-content:space-between;" data-set="sfx">
              <span>${x(e.settings.sfxMuted?"soundOff":"soundOn")} ${g.t("sfx_label")}</span>
              <span style="color:${e.settings.sfxMuted?"#fca5a5":"#4ade80"};">${e.settings.sfxMuted?g.t("vol_off"):"ON"}</span>
            </button>

            <div class="rm-btn" style="justify-content:space-between;cursor:default;">
              <span style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;" data-set="music">
                ${x(a==="off"?"soundOff":"soundOn")} ${g.t("music_label")}
              </span>
              <span style="display:inline-flex;gap:4px;">
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="off"?"#ef4444":"#3f2e21"};color:${a==="off"?"#fca5a5":"#94a3b8"};" data-set="music-vol" data-vol="off">${g.t("vol_off")}</button>
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="low"?"#fbbf24":"#3f2e21"};color:${a==="low"?"#fde047":"#94a3b8"};" data-set="music-vol" data-vol="low">${g.t("vol_low")}</button>
                <button class="rm-btn" style="min-height:28px;padding:3px 8px;font-size:11px;border-color:${a==="high"?"#22c55e":"#3f2e21"};color:${a==="high"?"#4ade80":"#94a3b8"};" data-set="music-vol" data-vol="high">${g.t("vol_high")}</button>
              </span>
            </div>

            <button class="rm-btn" style="justify-content:space-between;" data-set="aim">
              <span>${x("orb")} ${g.t("aim_mode_label")}</span>
              <span style="color:#38bdf8;">${e.settings.aimMode==="slingshot"?g.t("aim_slingshot"):g.t("aim_direct")}</span>
            </button>

            <label class="rm-btn" style="justify-content:space-between;">
              <span style="display:inline-flex;align-items:center;gap:6px;">${x("globe")} ${g.t("language_label")}</span>
              <select data-set="lang" style="background:#181210;color:#fffbeb;border:1.5px solid #8c5a2b;border-radius:6px;padding:4px 8px;font-weight:800;font-size:13px;">
                ${i}
              </select>
            </label>
          </div>
        </div>

        <button class="rm-btn rm-btn-crimson" data-set="reset" style="margin-top:4px;">
          ${g.t("reset_progress")}
        </button>
      </div>
    `,this.backdrop.querySelector('[data-set="close"]')?.addEventListener("click",()=>{this.hide(),s.onClose()}),this.backdrop.querySelector('[data-set="sfx"]')?.addEventListener("click",()=>{s.onToggleSfx(),this.render(e,t,s)}),this.backdrop.querySelector('[data-set="music"]')?.addEventListener("click",()=>{s.onToggleMusic(),this.render(e,t,s)}),this.backdrop.querySelectorAll('[data-set="music-vol"]').forEach(n=>{n.addEventListener("click",()=>{const r=n.dataset.vol;s.onSetMusicVolume(r),this.render(e,t,s)})}),this.backdrop.querySelector('[data-set="aim"]')?.addEventListener("click",()=>{s.onToggleAimMode(),this.render(e,t,s)}),this.backdrop.querySelector('[data-set="lang"]')?.addEventListener("change",n=>{const r=n.target.value;s.onSelectLocale(r),this.render(e,r,s)}),this.backdrop.querySelector('[data-set="reset"]')?.addEventListener("click",()=>{this.confirmingReset=!0,this.render(e,t,s)})}hide(){this.backdrop.style.display="none"}}const Ce="rm-shop-banner-slot",st=320,it=50;class Fi{constructor(e){c(this,"backdrop");c(this,"shellEl");c(this,"headerEl");c(this,"bodyEl");c(this,"bannerEl");c(this,"tab","upgrades");c(this,"isOpen",!1);c(this,"resizeObserver",null);c(this,"lastProps",null);this.backdrop=document.createElement("div"),this.backdrop.className="rm-modal-backdrop",this.backdrop.style.display="none",this.backdrop.innerHTML=`
      <div class="arcade-modal-shell">
        <div class="rm-modal-header" data-shop="header"></div>
        <div class="rm-shop-body" data-shop="body" style="display:flex;flex-direction:column;gap:8px;flex:1 1 auto;min-height:0;overflow:hidden;"></div>
        <div id="${Ce}" class="rm-banner-slot"></div>
      </div>
    `,e.appendChild(this.backdrop),this.shellEl=this.backdrop.querySelector(".arcade-modal-shell"),this.headerEl=this.backdrop.querySelector('[data-shop="header"]'),this.bodyEl=this.backdrop.querySelector('[data-shop="body"]'),this.bannerEl=this.backdrop.querySelector(`#${Ce}`),typeof ResizeObserver<"u"&&(this.resizeObserver=new ResizeObserver(()=>this.evaluateBannerViewportFit()),this.resizeObserver.observe(this.shellEl)),typeof window<"u"&&window.addEventListener("resize",()=>this.evaluateBannerViewportFit()),S.onAdAvailabilityChange(()=>{if(this.isOpen&&this.lastProps){const t=this.lastProps;this.render(t.save,t.economy,t.skins,t.progression,t.freeUpgradeCandidate,t.callbacks),this.evaluateBannerViewportFit()}})}evaluateBannerViewportFit(){if(!this.isOpen)return;if(!S.canShowBanners()){this.suppressBanner();return}const e=this.bannerEl.clientWidth||this.shellEl.clientWidth-44,t=window.innerHeight;if(e<st||t<420){this.suppressBanner();return}this.bannerEl.classList.remove("suppressed"),this.bannerEl.style.visibility="visible",this.bannerEl.style.height=e>=468&&t>=560?"60px":`${it}px`;const s=this.bannerEl.getBoundingClientRect();if(s.width<st||s.height<it||s.bottom>window.innerHeight||s.right>window.innerWidth){this.suppressBanner();return}S.requestBanner(Ce)}suppressBanner(){S.clearAllBanners(),this.bannerEl.classList.add("suppressed"),this.bannerEl.style.height="0px",this.bannerEl.style.visibility="hidden"}open(e,t,s,i,a,n,r="upgrades"){this.tab=r,this.isOpen=!0,this.lastProps={save:e,economy:t,skins:s,progression:i,freeUpgradeCandidate:a,callbacks:n},this.render(e,t,s,i,a,n),this.backdrop.style.display="flex",this.evaluateBannerViewportFit()}render(e,t,s,i,a,n){if(!this.isOpen)return;this.lastProps={save:e,economy:t,skins:s,progression:i,freeUpgradeCandidate:a,callbacks:n};const r=i.canPrestige(e)?`<button class="rm-btn rm-btn-gold" data-act="prestige">${x("lightning")} ${g.t("prestige_btn")} (+50%)</button>`:"";this.headerEl.innerHTML=`
      <div style="display:flex;gap:6px;">
        <button class="rm-btn ${this.tab==="upgrades"?"rm-btn-primary":""}" data-tab="upgrades">
          <img src="${D.drillDamage}" style="width:18px;height:18px;object-fit:contain;" alt="" /> ${g.t("upgrades")}
        </button>
        <button class="rm-btn ${this.tab==="skins"?"rm-btn-primary":""}" data-tab="skins">
          ${x("palette")} ${g.t("skins")}
        </button>
      </div>
      <button class="rm-btn rm-close-btn" data-act="close" aria-label="Close">${x("close")}</button>
    `;let d="";this.tab==="upgrades"?d=`
        <div class="rm-scroll-area">
          <div class="rm-upgrade-list">${ne.map(o=>{const h=t.getLevel(e,o.id),m=t.getMaxLevel(e,o.id),p=t.isMaxLevel(e,o.id),u=t.getUpgradeCost(e,o.id),b=t.canAfford(e,o.id),_=a===o.id?ee.renderMarkup({labelHtml:"",attrs:`data-free-upg="${o.id}" aria-label="${g.t("free_upgrade_cta")}"`,className:"rm-btn rm-btn-gold",style:"min-height:40px;padding:4px 8px;font-size:11px;",fallbackMode:"hide"}):"";return`
          <div class="rm-upgrade-plaque">
            <div class="rm-icon-socket">
              <img src="${Ai[o.id]}" alt="" />
            </div>
            <div style="flex:1;min-width:0;">
              <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
                <span style="font-weight:900;font-size:13px;text-shadow:0 2px 0 #120c08;">${g.t(o.nameKey)}</span>
                <span class="rm-lv-pill">LV. ${h}/${m}</span>
              </div>
              <div style="font-size:11px;color:#cbd5e1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                ${g.t(o.descKey)}
              </div>
            </div>
            <div style="display:flex;gap:5px;align-items:center;">
              ${_}
              <button class="rm-btn rm-buy-btn ${p?"":b?"rm-btn-green":"unaffordable"}" data-upg="${o.id}" ${p||!b?"disabled":""}>
                ${p?g.t("maxed"):`${x("coin")} ${N(u)}`}
              </button>
            </div>
          </div>
        `}).join("")}</div>
        </div>
        ${r}
      `:d=`<div class="rm-scroll-area"><div class="rm-upgrade-grid">${fe.map(o=>{const h=e.unlockedSkins.includes(o.id),m=e.equippedSkin===o.id,p=e.skinRvProgress[o.id]??0,u=ft.getSkinThumbnailUrl(o.id);let b="";if(m)b=`<span class="rm-btn rm-btn-gold" style="min-height:34px;font-size:11px;cursor:default;">${x("check")} ${g.t("equipped")}</span>`;else if(h)b=`<button class="rm-btn rm-btn-green" style="min-height:34px;font-size:11px;" data-equip="${o.id}">${g.t("select_btn")}</button>`;else{const _=!!(o.coinCost&&e.coins>=o.coinCost),v=o.rvCost?ee.renderMarkup({labelHtml:`${p}/${o.rvCost}`,attrs:`data-rv-skin="${o.id}"`,className:"rm-btn rm-btn-gold",style:"min-height:32px;font-size:11px;padding:4px 8px;width:100%;",fallbackMode:"hide"}):"";b=`
            <div style="display:flex;flex-direction:column;gap:4px;align-items:center;width:100%;">
              ${o.coinCost?`<button class="rm-btn ${_?"rm-btn-green":"unaffordable"}" style="min-height:32px;font-size:11px;padding:4px 8px;width:100%;" data-coin-unlock="${o.id}" ${_?"":"disabled"}>
                      ${x("coin")} ${N(o.coinCost)}
                    </button>`:""}
              ${v}
              <span style="font-size:10px;color:#cbd5e1;display:inline-flex;align-items:center;gap:3px;">${x("lock")} ${g.t(o.unlockDescKey)}</span>
            </div>
          `}return`
          <div class="rm-skin-card">
            <div class="rm-skin-showcase" style="border-color:${m?"#fbbf24":"#8c5a2b"};">
              <img src="${u}" alt="${g.t(o.nameKey)}" />
            </div>
            <div class="rm-skin-name">${g.t(o.nameKey)}</div>
            ${b}
          </div>
        `}).join("")}</div></div>`,this.bodyEl.innerHTML=d,this.headerEl.querySelector('[data-act="close"]')?.addEventListener("click",()=>{this.close(),n.onClose()}),this.headerEl.querySelector('[data-tab="upgrades"]')?.addEventListener("click",()=>{this.tab="upgrades",this.render(e,t,s,i,a,n)}),this.headerEl.querySelector('[data-tab="skins"]')?.addEventListener("click",()=>{this.tab="skins",this.render(e,t,s,i,a,n)}),this.bodyEl.querySelector('[data-act="prestige"]')?.addEventListener("click",n.onPrestige),this.bodyEl.querySelectorAll("[data-upg]").forEach(l=>{l.addEventListener("click",()=>{const o=l.dataset.upg;n.onBuyUpgrade(o)})}),this.bodyEl.querySelectorAll("[data-free-upg]").forEach(l=>{l.addEventListener("click",()=>{const o=l.dataset.freeUpg;n.onFreeUpgradeAd(o)})}),this.bodyEl.querySelectorAll("[data-equip]").forEach(l=>{l.addEventListener("click",()=>{const o=l.dataset.equip;n.onEquipSkin(o)})}),this.bodyEl.querySelectorAll("[data-coin-unlock]").forEach(l=>{l.addEventListener("click",()=>{const o=l.dataset.coinUnlock;n.onUnlockSkinCoins(o)})}),this.bodyEl.querySelectorAll("[data-rv-skin]").forEach(l=>{l.addEventListener("click",()=>{const o=l.dataset.rvSkin;n.onUnlockSkinAd(o)})})}close(){this.isOpen&&(this.isOpen=!1,this.lastProps=null,this.backdrop.style.display="none",this.suppressBanner())}}class Vi{constructor(e){c(this,"el");c(this,"floatingCrestEl");c(this,"visible",!1);this.el=document.createElement("div"),this.el.className="rm-title-overlay",this.el.style.display="none",e.appendChild(this.el),this.floatingCrestEl=document.createElement("div"),this.floatingCrestEl.className="rm-floating-brand",this.floatingCrestEl.style.display="none",e.appendChild(this.floatingCrestEl)}showFloatingIntroBanner(e){this.floatingCrestEl.innerHTML=`<img src="${e}" alt="Ricochet Miner" />`,this.floatingCrestEl.classList.remove("fading"),this.floatingCrestEl.style.display="flex"}dismissFloatingIntroBanner(){this.floatingCrestEl.style.display!=="none"&&(this.floatingCrestEl.classList.add("fading"),window.setTimeout(()=>{this.floatingCrestEl.style.display="none",this.floatingCrestEl.classList.remove("fading")},240))}show(e){this.dismissFloatingIntroBanner(),this.visible=!0,this.el.classList.remove("hiding"),this.el.style.display="flex";const t=e.ascensionTier>=1?`<div class="rm-ascension-crest-pill">
            <img src="${ve(e.ascensionTier)}" style="width:20px;height:20px;object-fit:contain;" alt="" />
            <img src="${D.badgeAscensionStar}" style="width:16px;height:16px;object-fit:contain;" alt="" />
            <span>${g.t("tier_label").toUpperCase()} ${re(e.ascensionTier)}</span>
          </div>`:"";this.el.innerHTML=`
      <img src="${e.logoUrl}" class="rm-logo-img" alt="Ricochet Miner" />

      <button class="rm-btn rm-btn-green rm-play-btn" data-title="play" data-interactive="true">
        ${x("play")} ${g.t("play_btn")}
      </button>

      ${e.bestDepthMeters>0?`<div class="rm-pill" style="border-color:#fbbf24;">${x("pickaxe")} ${g.t("best_depth")}: ${Le(e.bestDepthMeters)}</div>`:""}
      ${t}

      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;justify-content:center;">
        <button class="rm-btn" data-title="mute" data-interactive="true" aria-label="Mute">
          ${x(e.muted?"soundOff":"soundOn")}
        </button>
        <button class="rm-btn" data-title="skins" data-interactive="true">
          ${x("palette")} ${g.t("skins")}
        </button>
        <button class="rm-btn" data-title="achievements" data-interactive="true">
          <img src="${D.trophy}" style="width:18px;height:18px;object-fit:contain;" alt="" />
          ${g.t("achievements")}
          ${e.hasUnclaimedFeats?'<span class="rm-dot"></span>':""}
        </button>
        <button class="rm-btn" data-title="settings" data-interactive="true">
          ${x("gear")} ${g.t("settings")}
        </button>
      </div>
    `,this.el.querySelector('[data-title="play"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),this.hideAnimated(e.callbacks.onPlay)}),this.el.querySelector('[data-title="mute"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onToggleMute()}),this.el.querySelector('[data-title="skins"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenSkins()}),this.el.querySelector('[data-title="achievements"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenAchievements()}),this.el.querySelector('[data-title="settings"]')?.addEventListener("click",()=>{e.callbacks.onUserGesture?.(),e.callbacks.onOpenSettings()})}hideAnimated(e){this.visible&&(this.visible=!1,this.el.classList.add("hiding"),window.setTimeout(()=>{this.el.style.display="none",this.el.classList.remove("hiding"),e()},220))}hideImmediate(){this.visible=!1,this.el.style.display="none"}}const $i=""+new URL("lilita-one-87r-Z-Re.woff2",import.meta.url).href,Hi=""+new URL("fredoka-bold-BOIZVyIN.woff2",import.meta.url).href;function Gi(){if(typeof document>"u"||document.getElementById("rm-styles"))return;const f=document.createElement("style");f.id="rm-styles",f.textContent=`
    @font-face {
      font-family: 'Lilita One';
      src: url("${$i}") format('woff2');
      font-weight: 400;
      font-style: normal;
      font-display: swap;
    }
    @font-face {
      font-family: 'Fredoka';
      src: url("${Hi}") format('woff2');
      font-weight: 700;
      font-style: normal;
      font-display: swap;
    }
    html, body, #app, #ui-root {
      scrollbar-width: none;
      -ms-overflow-style: none;
      font-family: 'Fredoka', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
    }
    html::-webkit-scrollbar,
    body::-webkit-scrollbar,
    .rm-modal::-webkit-scrollbar,
    .arcade-modal-shell::-webkit-scrollbar,
    .rm-scroll-area::-webkit-scrollbar {
      display: none;
      width: 0;
      height: 0;
    }
    .rm-ico {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }
    .rm-hud-stack {
      position: absolute;
      top: max(8px, env(safe-area-inset-top));
      left: max(8px, env(safe-area-inset-left));
      right: max(8px, env(safe-area-inset-right));
      display: flex;
      flex-direction: column;
      gap: 6px;
      pointer-events: none;
      z-index: 10;
    }
    .rm-hud-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 6px;
      pointer-events: none;
    }
    .rm-pill-row {
      display: flex;
      flex-wrap: wrap;
      gap: 6px;
      align-items: center;
      min-width: 0;
    }
    .rm-pill-row-nowrap {
      flex-wrap: nowrap;
      flex-shrink: 0;
    }
    .rm-pill {
      background: linear-gradient(180deg, #4f3a2a 0%, #2d1e15 100%);
      border: 2.5px solid #1a1310;
      box-shadow: inset 0 2px 0 rgba(255, 240, 200, 0.25), 0 4px 0 #1a1310;
      border-radius: 12px;
      padding: 5px 10px;
      font-size: clamp(11px, 2.8vw, 14px);
      font-weight: 800;
      font-variant-numeric: tabular-nums;
      color: #fffbeb;
      text-shadow: 0 2px 0 #1a1310;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      max-width: 42vw;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .rm-btn {
      position: relative;
      min-width: 42px;
      min-height: 42px;
      border-radius: 12px;
      border: 2.5px solid #1a1310;
      background: linear-gradient(180deg, #624836 0%, #3b291d 100%);
      box-shadow: inset 0 2px 0 rgba(255, 245, 220, 0.28), 0 4px 0 #1a1310;
      color: #fffbeb;
      text-shadow: 0 2px 0 #1a1310;
      font-family: 'Lilita One', 'Fredoka', system-ui, sans-serif;
      font-size: clamp(12px, 2.7vw, 14px);
      font-weight: 700;
      letter-spacing: 0.3px;
      padding: 7px 11px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      overflow: visible;
      white-space: nowrap;
      transition: filter 0.1s ease, box-shadow 0.06s ease;
    }
    .rm-btn:hover:not(:disabled) {
      filter: brightness(1.07);
    }
    .rm-btn:active:not(:disabled) {
      transform: translateY(3px);
      box-shadow: inset 0 2px 0 rgba(255, 245, 220, 0.15), 0 1px 0 #1a1310;
    }
    .rm-btn-primary {
      background: linear-gradient(180deg, #38bdf8 0%, #0284c7 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.45), 0 4px 0 #0c4a6e, 0 6px 0 #1a1310;
    }
    .rm-btn-gold {
      background: linear-gradient(180deg, #fbbf24 0%, #d97706 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 220, 0.55), 0 4px 0 #92400e, 0 6px 0 #1a1310;
      color: #fffbeb;
    }
    .rm-btn-green {
      background: linear-gradient(180deg, #4ade80 0%, #16a34a 100%);
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.5), 0 4px 0 #14532d, 0 6px 0 #1a1310;
    }
    .rm-btn-crimson {
      background: linear-gradient(180deg, #b91c1c 0%, #7f1d1d 100%);
      box-shadow: inset 0 2px 0 rgba(255, 220, 220, 0.3), 0 4px 0 #450a0a, 0 6px 0 #1a1310;
    }
    .rm-btn:disabled {
      opacity: 0.45;
      cursor: not-allowed;
    }
    .rm-badge-count {
      position: absolute;
      top: -7px;
      right: -7px;
      min-width: 20px;
      height: 20px;
      border-radius: 999px;
      background: #ef4444;
      border: 2px solid #1a1310;
      color: #ffffff;
      font-size: 11px;
      font-weight: 900;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 0 4px;
    }
    .rm-dot {
      position: absolute;
      top: 5px;
      right: 5px;
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: #ef4444;
      border: 2px solid #1a1310;
    }
    .rm-arcade-console {
      position: absolute;
      bottom: max(10px, env(safe-area-inset-bottom));
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(180deg, #332720 0%, #1e1612 100%);
      border: 3px solid #1a1310;
      box-shadow: inset 0 2px 0 rgba(255, 235, 200, 0.16), 0 6px 18px rgba(0,0,0,0.65);
      border-radius: 16px;
      padding: 7px;
      display: flex;
      gap: 6px;
      flex-wrap: wrap;
      justify-content: center;
      width: max-content;
      max-width: calc(100vw - 16px);
      z-index: 12;
      pointer-events: auto;
    }
    @media (min-width: 780px) and (min-aspect-ratio: 11/10) {
      .rm-hud-top > .rm-pill-row:first-child {
        max-width: max(180px, calc(var(--rm-shaft-x, 220px) - 16px));
      }
      .rm-boss-row {
        max-width: max(180px, calc(var(--rm-shaft-x, 220px) - 16px));
      }
      .rm-boss-bar {
        max-width: 100%;
        flex-wrap: wrap;
      }
      .rm-arcade-console {
        left: auto;
        right: 12px;
        bottom: 16px;
        transform: none;
        flex-direction: column;
        align-items: stretch;
        width: clamp(156px, calc(var(--rm-shaft-x, 220px) - 24px), 206px);
        padding: 9px;
        gap: 7px;
      }
    }
    .rm-bottom-bar {
      position: absolute;
      bottom: max(12px, env(safe-area-inset-bottom));
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 8px;
      justify-content: center;
      z-index: 12;
    }
    .rm-modal-backdrop {
      position: absolute;
      inset: 0;
      background: rgba(10, 8, 7, 0.78);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: clamp(8px, 2.5vw, 16px);
      pointer-events: auto;
      z-index: 30;
    }
    .rm-modal,
    .arcade-modal-shell {
      position: relative;
      width: min(490px, 100%);
      max-height: 88dvh;
      overflow: hidden;
      background: #231b16;
      border-style: solid;
      border-width: clamp(14px, 3.2vw, 22px);
      border-image-source: url("${Ti}");
      border-image-slice: 74;
      border-image-repeat: stretch;
      box-shadow: inset 0 0 26px rgba(0, 0, 0, 0.75), 0 24px 55px rgba(0, 0, 0, 0.85);
      padding: 6px 8px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      color: #fffbeb;
      scrollbar-width: none;
      -ms-overflow-style: none;
    }
    .rm-scroll-area {
      flex: 1 1 auto;
      min-height: 0;
      overflow-y: auto;
      scrollbar-width: none;
      -ms-overflow-style: none;
      padding-right: 1px;
    }
    .rm-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
      flex-shrink: 0;
    }
    .rm-header-plaque {
      background: linear-gradient(180deg, #4b3526 0%, #312117 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 225, 165, 0.25), 0 3px 0 #120c08;
      border-radius: 10px;
      padding: 6px 12px;
      color: #fbbf24;
      font-weight: 900;
      font-size: clamp(14px, 3.5vw, 18px);
      text-shadow: 0 2px 0 #120c08;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      letter-spacing: 0.4px;
      white-space: nowrap;
    }
    .rm-close-btn {
      min-width: 38px;
      min-height: 38px;
      padding: 6px;
      border-radius: 10px;
      background: linear-gradient(180deg, #7f1d1d 0%, #450a0a 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 200, 200, 0.25), 0 3px 0 #120c08;
      flex-shrink: 0;
    }
    .rm-crown-icon {
      width: 52px;
      height: 52px;
      object-fit: contain;
      display: block;
      margin: -2px auto 0 auto;
      flex-shrink: 0;
      filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.75));
    }
    .rm-new-best {
      align-self: center;
      background: linear-gradient(180deg, #fde047 0%, #d97706 100%);
      border: 2px solid #120c08;
      color: #120c08;
      font-size: 11px;
      font-weight: 900;
      padding: 2px 10px;
      border-radius: 999px;
      letter-spacing: 0.8px;
      box-shadow: 0 2px 0 #120c08;
    }
    .rm-stat-row {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .rm-stat-plaque {
      background: linear-gradient(180deg, #271d17 0%, #17110d 100%);
      border: 2.5px solid #6b4c30;
      box-shadow: inset 0 2px 0 rgba(255, 225, 170, 0.14), inset 0 -4px 10px rgba(0, 0, 0, 0.55), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 10px 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
    }
    .rm-stat-coin-svg svg {
      width: 34px;
      height: 34px;
      display: block;
    }
    .rm-upgrade-list {
      display: flex;
      flex-direction: column;
      gap: 7px;
    }
    .rm-upgrade-plaque {
      background: linear-gradient(180deg, #3c2e24 0%, #271d16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 7px 8px;
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
    }
    .rm-icon-socket {
      width: 46px;
      height: 46px;
      border-radius: 10px;
      background: #181210;
      border: 2px solid #4a3728;
      box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.75);
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      padding: 3px;
    }
    .rm-icon-socket img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
    .rm-lv-pill {
      display: inline-block;
      background: #181210;
      border: 1.5px solid #8c5a2b;
      color: #fbbf24;
      font-size: 10px;
      font-weight: 900;
      padding: 1px 6px;
      border-radius: 6px;
      letter-spacing: 0.4px;
      white-space: nowrap;
      flex-shrink: 0;
    }
    .rm-buy-btn {
      min-width: 78px;
      min-height: 40px;
      padding: 6px 9px;
      font-size: 12px;
      flex-shrink: 0;
    }
    .rm-buy-btn.unaffordable {
      opacity: 0.72;
      background: linear-gradient(180deg, #3b3531 0%, #24201d 100%);
      box-shadow: 0 3px 0 #120c08;
    }
    .rm-upgrade-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }
    .rm-skin-card {
      background: linear-gradient(180deg, #3c2e24 0%, #241b16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 8px;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      text-align: center;
      min-width: 0;
    }
    .rm-skin-name {
      font-weight: 900;
      font-size: 12px;
      text-shadow: 0 2px 0 #120c08;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .rm-skin-showcase {
      width: 62px;
      height: 62px;
      border-radius: 14px;
      background: #181210;
      border: 2.5px solid #8c5a2b;
      box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.8);
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 5px;
    }
    .rm-skin-showcase img {
      width: 100%;
      height: 100%;
      object-fit: contain;
    }
    .rm-toast {
      position: absolute;
      top: 96px;
      left: 50%;
      transform: translateX(-50%);
      background: #1a1310;
      border: 2px solid #fbbf24;
      color: #fde047;
      padding: 8px 16px;
      border-radius: 999px;
      font-size: 13px;
      font-weight: 900;
      z-index: 60;
      pointer-events: none;
      white-space: nowrap;
      max-width: 90vw;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .rm-banner-slot {
      width: 100%;
      min-width: 320px;
      max-width: 728px;
      height: 50px;
      margin: 0 auto;
      background: transparent;
      border: none;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 12px;
      color: #cbd5e1;
      flex-shrink: 0;
      overflow: hidden;
    }
    .rm-banner-slot.suppressed {
      min-width: 0;
      height: 0 !important;
      visibility: hidden;
      pointer-events: none;
      margin: 0;
      padding: 0;
    }
    .rm-ftue {
      position: absolute;
      top: calc(var(--rm-top-offset, 0px) + 150px);
      left: 50%;
      transform: translateX(-50%);
      text-align: center;
      pointer-events: none;
      z-index: 15;
    }
    .rm-ftue-hand {
      display: inline-block;
      animation: rmPull 1.3s ease-in-out infinite;
    }
    .rm-ftue-reticle {
      display: inline-block;
      animation: rmReticleBob 1.5s ease-in-out infinite;
    }
    @keyframes rmReticleBob {
      0%, 100% { transform: translateY(0px); opacity: 0.95; }
      50% { transform: translateY(6px); opacity: 0.72; }
    }
    .rm-floating-brand {
      position: absolute;
      bottom: max(112px, 14vh);
      left: 50%;
      transform: translateX(-50%);
      z-index: 14;
      pointer-events: none;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: opacity 0.24s ease;
    }
    .rm-floating-brand img {
      width: min(210px, 46vw);
      max-height: 78px;
      object-fit: contain;
      filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.82));
    }
    .rm-floating-brand.fading {
      opacity: 0;
    }
    @keyframes rmPull {
      0%, 100% { transform: translateY(0px); opacity: 0.95; }
      50% { transform: translateY(28px); opacity: 0.65; }
    }
    .rm-title-overlay {
      position: absolute;
      inset: 0;
      background: radial-gradient(circle at 50% 35%, rgba(26, 19, 16, 0.45), rgba(10, 8, 7, 0.78));
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 18px;
      padding: 20px;
      z-index: 25;
      pointer-events: auto;
      transition: opacity 0.22s ease, transform 0.22s ease;
    }
    .rm-title-overlay.hiding {
      opacity: 0;
      transform: scale(1.03);
      pointer-events: none;
    }
    .rm-logo-img {
      width: min(440px, 86vw);
      max-height: 36vh;
      object-fit: contain;
      filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.85));
      animation: rmLogoFloat 3.2s ease-in-out infinite;
      pointer-events: none;
    }
    .rm-boss-bar {
      align-self: flex-start;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(26, 19, 16, 0.9);
      border: 2px solid #1a1310;
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fde68a;
      pointer-events: none;
      box-shadow: 0 3px 0 #1a1310;
      max-width: calc(100vw - 24px);
    }
    .rm-boss-track {
      width: 78px;
      height: 8px;
      background: #2e2017;
      border: 1.5px solid #1a1310;
      border-radius: 999px;
      overflow: hidden;
      flex-shrink: 0;
    }
    .rm-boss-fill {
      height: 100%;
      background: linear-gradient(90deg, #f59e0b, #ef4444);
      transition: width 0.15s ease;
    }
    .rm-boss-pulse {
      animation: rmBossPulse 0.9s ease-in-out infinite;
    }
    .rm-gate-hp-bar {
      align-self: center;
      width: min(360px, calc(100vw - 24px));
      background: linear-gradient(180deg, #3b1318 0%, #220b0e 100%);
      border: 2.5px solid #1a1310;
      border-radius: 12px;
      padding: 5px 10px;
      box-shadow: inset 0 2px 0 rgba(255, 180, 180, 0.2), 0 4px 0 #1a1310;
      display: none;
      flex-direction: column;
      gap: 4px;
      pointer-events: none;
    }
    .rm-gate-hp-bar.critical {
      border-color: #fbbf24;
      animation: rmGateCritical 0.75s ease-in-out infinite;
    }
    @keyframes rmGateCritical {
      0%, 100% { box-shadow: 0 0 8px rgba(251, 191, 36, 0.45), 0 4px 0 #1a1310; }
      50% { box-shadow: 0 0 18px rgba(239, 68, 68, 0.85), 0 4px 0 #1a1310; }
    }
    .rm-gate-hp-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 11px;
      font-weight: 900;
      color: #fecaca;
      text-shadow: 0 1px 0 #120c08;
    }
    .rm-gate-hp-track {
      width: 100%;
      height: 10px;
      background: #18090b;
      border: 1.5px solid #120c08;
      border-radius: 999px;
      overflow: hidden;
    }
    .rm-gate-hp-fill {
      height: 100%;
      background: linear-gradient(90deg, #ef4444 0%, #f97316 55%, #fde047 100%);
      transition: width 0.08s linear;
    }
    .rm-boss-row {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      pointer-events: none;
    }
    .rm-fullshaft-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: linear-gradient(180deg, #4b3519 0%, #2d1d0b 100%);
      border: 2px solid #fbbf24;
      box-shadow: 0 3px 0 #1a1310, 0 0 10px rgba(251, 191, 36, 0.35);
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fde047;
      text-shadow: 0 1px 0 #120c08;
      white-space: nowrap;
    }
    .rm-ascension-crest-pill {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: linear-gradient(180deg, #6b4c14 0%, #3d2807 100%);
      border: 2px solid #fde047;
      box-shadow: inset 0 1px 0 rgba(255, 250, 210, 0.4), 0 3px 0 #1a1310;
      border-radius: 999px;
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 900;
      color: #fffbeb;
      text-shadow: 0 1px 0 #120c08;
      white-space: nowrap;
    }
    .rm-victory-shell {
      overflow: visible;
      padding-top: 38px;
    }
    .rm-sunburst {
      position: absolute;
      top: -90px;
      left: 50%;
      width: 260px;
      height: 260px;
      margin-left: -130px;
      background: conic-gradient(
        from 0deg,
        rgba(253, 224, 71, 0.28) 0deg 15deg,
        transparent 15deg 30deg,
        rgba(251, 191, 36, 0.26) 30deg 45deg,
        transparent 45deg 60deg,
        rgba(253, 224, 71, 0.28) 60deg 75deg,
        transparent 75deg 90deg,
        rgba(251, 191, 36, 0.26) 90deg 105deg,
        transparent 105deg 120deg,
        rgba(253, 224, 71, 0.28) 120deg 135deg,
        transparent 135deg 150deg,
        rgba(251, 191, 36, 0.26) 150deg 165deg,
        transparent 165deg 180deg,
        rgba(253, 224, 71, 0.28) 180deg 195deg,
        transparent 195deg 210deg,
        rgba(251, 191, 36, 0.26) 210deg 225deg,
        transparent 225deg 240deg,
        rgba(253, 224, 71, 0.28) 240deg 255deg,
        transparent 255deg 270deg,
        rgba(251, 191, 36, 0.26) 270deg 285deg,
        transparent 285deg 300deg,
        rgba(253, 224, 71, 0.28) 300deg 315deg,
        transparent 315deg 330deg,
        rgba(251, 191, 36, 0.26) 330deg 345deg,
        transparent 345deg 360deg
      );
      border-radius: 50%;
      mask-image: radial-gradient(circle, #000 18%, transparent 72%);
      -webkit-mask-image: radial-gradient(circle, #000 18%, transparent 72%);
      animation: rmSunburstSpin 18s linear infinite;
      pointer-events: none;
      z-index: 1;
    }
    @keyframes rmSunburstSpin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    .rm-victory-crest-wrap {
      position: absolute;
      top: -54px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      z-index: 3;
      pointer-events: none;
    }
    .rm-victory-crest {
      width: 86px;
      height: 86px;
      object-fit: contain;
      filter: drop-shadow(0 6px 12px rgba(0, 0, 0, 0.85));
    }
    .rm-victory-stars {
      display: inline-flex;
      gap: 2px;
      filter: drop-shadow(0 3px 4px rgba(0, 0, 0, 0.85));
    }
    .rm-victory-ribbon {
      align-self: center;
      position: relative;
      z-index: 2;
      background: linear-gradient(180deg, #4b3526 0%, #2b1c12 100%);
      border: 2.5px solid #fbbf24;
      box-shadow: inset 0 2px 0 rgba(255, 240, 200, 0.3), 0 4px 0 #120c08;
      border-radius: 10px;
      padding: 4px 16px;
      color: #fde68a;
      font-weight: 900;
      font-size: 13px;
      letter-spacing: 0.8px;
      text-shadow: 0 2px 0 #120c08;
    }
    .rm-victory-title {
      font-size: clamp(18px, 4.4vw, 22px);
      font-weight: 900;
      color: #fde047;
      text-shadow: 0 3px 0 #120c08;
      letter-spacing: 0.6px;
      margin-top: 2px;
    }
    .rm-victory-quote {
      font-size: 12px;
      font-style: italic;
      color: #fef3c7;
      line-height: 1.35;
      margin-top: 4px;
      text-shadow: 0 1px 0 #120c08;
    }
    .rm-btn-ascend {
      background: linear-gradient(180deg, #dc2626 0%, #b45309 100%);
      border-color: #fde047;
      box-shadow: inset 0 2px 0 rgba(255, 235, 190, 0.5), 0 4px 0 #7f1d1d, 0 6px 0 #1a1310;
      color: #fffbeb;
    }
    .rm-teaser-banner {
      background: linear-gradient(180deg, #4a3118 0%, #2a1b0d 100%);
      border: 2.5px solid #fbbf24;
      border-radius: 12px;
      padding: 8px 10px;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.2), 0 3px 0 #120c08;
    }
    .rm-achievement-card {
      background: linear-gradient(180deg, #3c2e24 0%, #271d16 100%);
      border: 2.5px solid #120c08;
      box-shadow: inset 0 2px 0 rgba(255, 235, 195, 0.16), 0 3px 0 #120c08;
      border-radius: 12px;
      padding: 7px 9px;
      display: flex;
      align-items: center;
      gap: 9px;
      min-width: 0;
    }
    .rm-achievement-card.unlocked {
      border-color: #fbbf24;
    }
    .rm-achievement-card.locked {
      opacity: 0.78;
    }
    @keyframes rmBossPulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.24); }
    }
    .rm-skin-thumb {
      width: 40px;
      height: 40px;
      object-fit: contain;
      flex-shrink: 0;
      filter: drop-shadow(0 2px 2px rgba(0,0,0,0.6));
    }
    @keyframes rmLogoFloat {
      0%, 100% { transform: translateY(-4px); }
      50% { transform: translateY(4px); }
    }
    .rm-play-btn {
      min-width: 210px;
      min-height: 58px;
      font-size: 22px;
      letter-spacing: 1px;
      border-radius: 16px;
      box-shadow: inset 0 2px 0 rgba(255, 255, 255, 0.5), 0 5px 0 #14532d, 0 8px 18px rgba(34, 197, 94, 0.35);
    }
    @media (max-width: 430px) {
      .rm-pill {
        padding: 4px 8px;
        font-size: 11px;
        max-width: 39vw;
      }
      .rm-arcade-console .rm-btn {
        min-height: 38px;
        padding: 6px 8px;
        font-size: 11px;
      }
      .rm-icon-socket {
        width: 40px;
        height: 40px;
      }
      .rm-buy-btn {
        min-width: 68px;
        min-height: 38px;
        padding: 5px 7px;
        font-size: 11px;
      }
      .rm-boss-track {
        width: 62px;
      }
    }
  `,document.head.appendChild(f)}class qi{constructor(e){c(this,"nextEntityId",1);c(this,"generatedChunks",new Set);c(this,"rng");c(this,"options");c(this,"spawnedBossGates",new Set);this.options=e,this.rng=new He(e.seed??1380533071)}updateOptions(e){Object.assign(this.options,e)}reset(e){this.nextEntityId=1,this.generatedChunks.clear(),this.spawnedBossGates.clear(),this.options=e,this.rng=new He(e.seed??1380533071)}ensureChunksUpToRow(e,t){const s=Math.floor(e/y.CHUNK_ROWS);for(let i=0;i<=s;i++)this.generatedChunks.has(i)||(this.generatedChunks.add(i),this.generateChunk(i,t))}generateChunk(e,t){const s=e*y.CHUNK_ROWS,i=s+y.CHUNK_ROWS-1,{tntChance:a,bumperChance:n}=qt(this.options.luckLevel),r=e===0&&this.options.baseRowOffset===0,d=e===0?r?4:3:s;for(let l=d;l<=i;l++){if(r&&l<=3)continue;const o=this.options.baseRowOffset+l,h=o*y.METERS_PER_ROW,m=this.getBiomeForRow(o),p=this.options.unlockedBiomeIndex,u=O[p+1],b=u?u.startDepthM:p===V.FINAL_BIOME_INDEX?V.FINAL_GATE_DEPTH_M:null;if(b!==null&&h>=b&&h<b+y.METERS_PER_ROW&&!this.spawnedBossGates.has(p)){this.spawnedBossGates.add(p),this.spawnBossGate(l,h,p,t);continue}if(e===0&&this.options.baseRowOffset===0&&l>=4&&l<=6){this.spawnFtueRow(l,h,m.index,t);continue}const _=(o-1)*y.METERS_PER_ROW;if(o>8&&Math.floor(h/Fe)>Math.floor(_/Fe)){const M=this.rng.int(2,y.GRID_COLS-4);t.push(this.createBlock("vault",M,l,h,m.index,2));for(let A=0;A<y.GRID_COLS;A++)A===M||A===M+1||this.rng.next()<.45&&t.push(this.createBlock("ore",A,l,h,m.index));continue}const k=Math.min(.72,.48+m.index*.04);let R=!1;for(let M=0;M<y.GRID_COLS;M++){if(this.rng.next()>k)continue;const A=this.rng.next();let E="strata";if(A<a)E="tnt";else if(A<a+n)E="bumper";else if(m.index>=1&&A<a+n+.06)E="splitter";else if(m.index>=2&&A<a+n+.11)E="laser";else if(m.index>=3&&A<a+n+.18)E="frost";else if(m.index>=4&&!R&&A<a+n+.22){R=!0,this.spawnPortalPair(M,l,h,m.index,t);continue}else A<a+n+.36?E="ore":h>=60&&A<a+n+.54?E="granite":E="strata";t.push(this.createBlock(E,M,l,h,m.index))}}}spawnFtueRow(e,t,s,i){e===4?(i.push(this.createBlock("strata",2,e,t,s)),i.push(this.createBlock("ore",3,e,t,s)),i.push(this.createBlock("ore",5,e,t,s)),i.push(this.createBlock("strata",6,e,t,s))):e===5?(i.push(this.createBlock("strata",2,e,t,s)),i.push(this.createBlock("ore",3,e,t,s)),i.push(this.createBlock("tnt",4,e,t,s)),i.push(this.createBlock("ore",5,e,t,s)),i.push(this.createBlock("strata",6,e,t,s))):e===6&&(i.push(this.createBlock("strata",1,e,t,s)),i.push(this.createBlock("strata",3,e,t,s)),i.push(this.createBlock("bumper",4,e,t,s)),i.push(this.createBlock("strata",5,e,t,s)),i.push(this.createBlock("strata",7,e,t,s)))}spawnBossGate(e,t,s,i){const a=[1,4,7],n=this.options.bossGateHpByBiome[s],r=Ve(t,"boss_core",this.options.ascensionTier??0);for(let d=0;d<y.GRID_COLS;d++){const l=a.indexOf(d);if(l!==-1){const o=n&&typeof n[l]=="number"?n[l]:r;if(o>0){const h=this.createBlock("boss_core",d,e,t,s);h.hp=o,h.maxHp=r,h.bossCoreIndex=l,i.push(h)}else i.push(this.createBlock("boss_armor",d,e,t,s))}else i.push(this.createBlock("boss_armor",d,e,t,s))}}spawnPortalPair(e,t,s,i,a){const n=t+16,r=zi(e+this.rng.int(-2,2)),d=(this.options.baseRowOffset+n)*y.METERS_PER_ROW,l=this.createBlock("portal_exit",r,n,d,i),o=this.createBlock("portal_entry",e,t,s,i);o.portalTargetId=l.id,a.push(o,l)}getBiomeForRow(e){const t=e*y.METERS_PER_ROW;for(let s=O.length-1;s>=0;s--)if(t>=O[s].startDepthM)return O[s];return O[0]}createBlock(e,t,s,i,a,n=1){const r=y.TILE_SIZE,d=r*n-4,l=r-4,o=t*r+2,h=s*r+2,m=Ve(i,e,this.options.ascensionTier??0);return{id:this.nextEntityId++,kind:e,col:t,row:s,colSpan:n,x:o,y:h,width:d,height:l,radius:e==="bumper"?22:e==="portal_entry"||e==="portal_exit"?20:0,hp:m,maxHp:m,depthMeters:i,biomeIndex:a,hitFlashTimer:0,hitsRemaining:e==="bumper"?y.BUMPER_MAX_HITS:void 0,alive:!0}}}function zi(f){return Math.max(0,Math.min(y.GRID_COLS-1,f))}const Re=96;class Wi{constructor(){c(this,"canvas");c(this,"uiRoot");c(this,"adShield");c(this,"saveManager",new si);c(this,"save",Te());c(this,"stateMachine",new jt);c(this,"viewport");c(this,"renderer");c(this,"physics",new cs);c(this,"particles",new us);c(this,"floatingText",new ds);c(this,"juice",new hs);c(this,"economy",new ii);c(this,"progression",new ni);c(this,"retention",new ri);c(this,"skins",new oi);c(this,"monetization",new ai);c(this,"audio",new It(!1));c(this,"hud");c(this,"ftue");c(this,"shop");c(this,"summary");c(this,"victoryModal");c(this,"achievementsModal");c(this,"retentionModals");c(this,"settingsModal");c(this,"titleOverlay");c(this,"input");c(this,"loop");c(this,"generator");c(this,"entities",[]);c(this,"orbs",[]);c(this,"coins",[]);c(this,"coinCursor",0);c(this,"cameraY",0);c(this,"aimAngleRad",null);c(this,"trajectoryDots",[]);c(this,"trajectoryImpact",null);c(this,"trajectorySecondImpact",null);c(this,"targetedBlockId",null);c(this,"secondTargetedBlockId",null);c(this,"trajectoryBounceIdx",14);c(this,"aimFeedback",null);c(this,"pendingVolleyOrbs",0);c(this,"volleyTimerS",0);c(this,"volleyAngleRad",Math.PI/2);c(this,"isOverdriveRun",!1);c(this,"runCoins",0);c(this,"runMaxDepthM",0);c(this,"runStartBestDepthM",0);c(this,"runElapsedS",0);c(this,"isFullShaftRun",!0);c(this,"runBlocksSmashed",0);c(this,"runMaxCombo",0);c(this,"runTntCount",0);c(this,"clearedBiome6ThisRun",!1);c(this,"victorySlowMoTimer",0);c(this,"pendingVictoryTier",null);c(this,"hasStartedGameplayOnce",!1);c(this,"skipNextMidgameBreak",!1);c(this,"pausedFromState",null);c(this,"bossActiveForAudio",!1);c(this,"pendingBiomeUnlock",null);c(this,"turretRecoil",0);c(this,"timeS",0);Gi();const e=document.getElementById("game-canvas"),t=document.getElementById("ui-root");if(!e||!t)throw new Error("Missing #game-canvas or #ui-root");this.canvas=e,this.uiRoot=t,this.adShield=document.createElement("div"),this.adShield.style.cssText="position:absolute;inset:0;z-index:999;background:transparent;pointer-events:auto;display:none;",this.uiRoot.appendChild(this.adShield);for(let s=0;s<Re;s++)this.coins.push({x:0,y:0,vx:0,vy:0,value:0,life:0,magnetized:!1,alive:!1});this.viewport=new Xt(this.canvas),this.renderer=new Ks(this.canvas)}async boot(){await S.init(),S.loadingStart();const e=S.getServerTimeMs(),t=this.saveManager.loadLocal(e),s=await S.loadCloudData(),i=s?Me(s,e):null;this.save=ti(t,i),g.setLocale(this.save.settings.localeOverride??S.getLocale()),this.audio.setUserMuted(this.save.settings.muted),this.audio.setSfxMuted(this.save.settings.sfxMuted),this.audio.setMusicVolume(this.save.settings.musicVolume??(this.save.settings.musicMuted?"off":"high")),this.save.settings.aimModeUserSet||(this.save.settings.aimMode=this.getDefaultAimModeForDevice()),this.retention.refreshDailyQuestsIfNeeded(this.save,e),this.retention.syncLoginStreakState(this.save,e),typeof document<"u"&&document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"?S.gameplayStop():this.hasStartedGameplayOnce&&(this.stateMachine.state==="AIMING"||this.stateMachine.state==="RUNNING")&&S.gameplayStart()}),S.setAdLifecycleCallbacks({onBeforeAd:()=>{this.stateMachine.pauseForAd(),this.audio.pauseForAd(),this.input.setLocked(!0),this.adShield.style.display="block"},onAfterAd:()=>{this.adShield.style.display="none",this.audio.resumeFromAd(),this.input.setLocked(!1),this.stateMachine.resumeFromAd(),this.hasStartedGameplayOnce&&(this.stateMachine.state==="AIMING"||this.stateMachine.state==="RUNNING")&&S.gameplayStart(),this.loop.resetAccumulator()}}),this.setupUI(),this.setupInput(),this.setupPhysicsEvents(),await this.renderer.preloadAssets(),this.generator=new qi({baseRowOffset:this.progression.getBaseRowOffset(this.save),luckLevel:this.save.upgrades.luck,bossGateHpByBiome:this.save.bossGateHpByBiome,unlockedBiomeIndex:this.save.unlockedBiomeIndex,ascensionTier:this.save.ascensionTier}),this.resetShaft(),this.loop=new Wt({onFixedUpdate:n=>this.fixedUpdate(n),onRender:(n,r)=>this.render(r),onVisibilityBlur:()=>{this.input?.setLocked(!1)}}),this.stateMachine.transition("AIMING"),this.titleOverlay.hideImmediate(),this.titleOverlay.showFloatingIntroBanner(this.renderer.getLogoEmblemUrl()),this.ftue.setAimMode(this.save.settings.aimMode),this.ftue.updateLayout(this.viewport.getLayout()),this.ftue.setVisible(!this.save.ftueDone),this.hasStartedGameplayOnce=!0,S.loadingStop(),S.gameplayStart(),this.loop.start();const a=this.retention.calculateOfflineEarnings(this.save,e);a>0&&this.retentionModals.showOfflineModal(a,async n=>{let r=a;if(n){const d=await this.monetization.showRewarded("rv_offline_double");d.rewarded?r*=2:this.showAdFailureToast(d.reason)}this.save.coins+=r,this.save.totalCoinsEarned+=r,this.persistSave()})}setupUI(){this.ftue=new Ii(this.uiRoot),this.ftue.setVisible(!1),this.viewport.onResize(e=>{this.ftue.updateLayout(e)}),this.shop=new Fi(this.uiRoot),this.summary=new Pi(this.uiRoot),this.victoryModal=new Ri(this.uiRoot),this.achievementsModal=new Ci(this.uiRoot),this.retentionModals=new Oi(this.uiRoot),this.settingsModal=new Ni(this.uiRoot),this.titleOverlay=new Vi(this.uiRoot),this.hud=new Li(this.uiRoot,{onToggleMute:()=>{this.save.settings.muted=this.audio.toggleMute(),this.persistSave()},onTogglePause:()=>this.togglePause(),onToggleAimMode:()=>{this.save.settings.aimMode=this.save.settings.aimMode==="slingshot"?"direct":"slingshot",this.save.settings.aimModeUserSet=!0,this.audio.playClick(),this.aimAngleRad=null,this.trajectoryDots=[],this.trajectoryImpact=null,this.trajectorySecondImpact=null,this.targetedBlockId=null,this.secondTargetedBlockId=null,this.aimFeedback=null,this.persistSave()},onToggleSpeed:()=>{const e=this.loop.getSpeedMultiplier()>1?1:2;this.loop.setSpeedMultiplier(e)},onRecall:()=>{for(const e of this.orbs)e.alive&&(this.particles.emitSparks(e.x,e.y,10,"#fde047"),e.alive=!1);for(let e=0;e<this.coins.length;e++){const t=this.coins[e];t.alive&&(t.magnetized=!0,t.life=Math.min(t.life,.45))}this.pendingVolleyOrbs=0},onOpenShop:()=>this.openShop(),onOpenAchievements:()=>this.openAchievements(!1),onOpenQuests:()=>{S.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showDailyQuests(this.save,this.retention,e=>{this.retention.claimQuest(this.save,e)>0&&(this.audio.playUpgrade(),this.persistSave(),this.retentionModals.hide(),this.resumeToAiming())},()=>{this.retention.claimMegaChest(this.save)&&(this.audio.playUpgrade(),this.persistSave(),this.retentionModals.hide(),this.resumeToAiming())},()=>this.resumeToAiming())},onOpenDailyLogin:()=>{S.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showDailyLogin(this.save,()=>{this.retention.claimDailyLoginReward(this.save,S.getServerTimeMs())&&(this.audio.playUpgrade(),this.persistSave())},()=>this.resumeToAiming())},onOpenElevator:()=>{S.gameplayStop(),this.stateMachine.transition("SHOP"),this.retentionModals.showElevator(this.save,e=>{this.progression.selectBiome(this.save,e)&&(this.persistSave(),this.resetShaft())},()=>this.resumeToAiming())},onTriggerOverdriveAd:async()=>{const e=await this.monetization.showRewarded("rv_overdrive_trial");e.rewarded?(this.monetization.markOverdriveOffered(this.save.runsCompleted),this.save.overdrivePasses+=1,this.persistSave(),this.hud.showToast("Super-Orb Armed!")):this.showAdFailureToast(e.reason)}}),new Bi(this.uiRoot,{getSave:()=>this.save,onAddCoins:e=>{this.save.coins+=e,this.save.totalCoinsEarned+=e,this.persistSave()},onUnlockAllBiomes:()=>{this.save.unlockedBiomeIndex=5,this.persistSave()},onSimulateOneShotClear:()=>this.simulateFinalGateClear(!0),onSimulateElevatorClear:()=>this.simulateFinalGateClear(!1),onResetSave:()=>{this.save=Te(),this.persistSave(),this.resetShaft(),this.ftue.setVisible(!0)}})}setupInput(){this.input=new Kt(this.canvas,{canAim:()=>this.stateMachine.state==="AIMING",getAimMode:()=>this.save.settings.aimMode,getLauncherPos:()=>({x:y.SHAFT_WIDTH*.5,y:y.LAUNCHER_Y}),clientToWorld:(e,t)=>this.viewport.clientToWorld(e,t,this.cameraY),onAimStart:()=>{this.audio.unlock(),this.titleOverlay.dismissFloatingIntroBanner(),this.hasStartedGameplayOnce||(this.hasStartedGameplayOnce=!0,S.gameplayStart())},onAimUpdate:(e,t,s)=>{if(this.aimFeedback=s??null,t||e===null){this.aimAngleRad=null,this.trajectoryDots=[],this.trajectoryImpact=null,this.trajectorySecondImpact=null,this.targetedBlockId=null,this.secondTargetedBlockId=null,this.trajectoryBounceIdx=y.TRAJECTORY_DOTS;return}this.aimAngleRad=e;const i=this.economy.getEffectiveOrbRadius(this.save),a=Ie(y.SHAFT_WIDTH*.5,y.LAUNCHER_Y,e),n=this.physics.computeTrajectoryPreview(a.x,a.y,e,i,this.entities);this.trajectoryDots=n.dots,this.trajectoryImpact=n.impactPoint,this.trajectorySecondImpact=n.secondImpactPoint,this.targetedBlockId=n.impactBlockId,this.secondTargetedBlockId=n.secondImpactBlockId,this.trajectoryBounceIdx=n.bounceStartIdx},onLaunch:e=>{this.save.ftueDone||(this.save.ftueDone=!0,this.ftue.setVisible(!1)),this.launchVolley(e)},onQuickRelaunch:()=>{this.stateMachine.state==="RUN_SUMMARY"&&(this.summary.hide(),this.prepareNextRun())},onToggleMute:()=>{this.save.settings.muted=this.audio.toggleMute(),this.persistSave()},onTogglePause:()=>this.togglePause(),onBuyUpgradeSlot:e=>{if(this.stateMachine.state!=="SHOP")return;const t=ne[e];t&&this.economy.buyUpgrade(this.save,t.id)&&(this.audio.playUpgrade(),this.persistSave())}})}spawnCoinDrop(e,t,s){const i=this.coins[this.coinCursor];this.coinCursor=(this.coinCursor+1)%Re,i.x=e,i.y=t,i.vx=(Math.random()-.5)*140,i.vy=-140-Math.random()*80,i.value=s,i.life=.7,i.magnetized=!0,i.alive=!0}setupPhysicsEvents(){this.physics.setEvents({onWallHit:(e,t,s)=>{this.audio.playWallHit(Math.hypot(e.vx,e.vy),t),this.particles.emitSparks(t,s,5,"#38bdf8")},onBlockHit:(e,t,s,i)=>{const a=t.x+t.width*.5,n=t.y+t.height*.5;this.audio.playHit(e.comboCount,i,t.kind==="granite"||t.kind==="boss_armor",Math.hypot(e.vx,e.vy),a),i?this.particles.emitSparks(a,n,10,"#fde047"):this.particles.emitRockShards(a,n,6,t.kind==="frost"?"#bae6fd":"#e2e8f0"),this.juice.triggerShake(i?3.5:1.8),i&&this.floatingText.spawn(a,n-12,"CLEAVE!","#38bdf8",1.05),e.comboCount>this.runMaxCombo&&(this.runMaxCombo=e.comboCount),e.comboCount>this.save.stats.maxBounceCombo&&(this.save.stats.maxBounceCombo=e.comboCount)},onBlockDestroyed:(e,t,s,i)=>{const a=e.x+e.width*.5,n=e.y+e.height*.5;this.runCoins+=t,this.runBlocksSmashed+=1,this.save.coins+=t,this.save.totalCoinsEarned+=t,this.save.stats.blocksDestroyed+=1,this.retention.recordQuestProgress(this.save,"blocksDestroyed",1),s||(this.audio.playCrunch(e.kind==="granite",a),this.particles.emitRockShards(a,n,8,e.kind==="ore"?"#fbbf24":e.kind==="frost"?"#7dd3fc":"#cbd5e1"),this.particles.emitSmokePuff(a,n,3,"#64748b")),s&&(this.runTntCount+=1,this.save.stats.tntDetonated+=1,this.retention.recordQuestProgress(this.save,"tntDetonated",1)),i&&(this.save.stats.vaultsBroken+=1,this.save.shards+=1,this.retention.recordQuestProgress(this.save,"vaultsBroken",1),this.audio.playFanfare(),this.juice.triggerHitStop(.04),this.floatingText.spawn(a,n-18,"+1 SHARD!","#e879f9",1.25),S.happytime()),t>0&&(this.audio.playCoin(a),this.floatingText.spawn(a,n,`+${N(t)}`,"#fbbf24",1),this.spawnCoinDrop(a,n,t))},onTntExplode:(e,t,s)=>{this.audio.playExplosion(e),this.runTntCount>=2&&this.audio.duck(500),this.juice.triggerHitStop(.035),this.juice.triggerShake(7.5),this.juice.triggerVignette(.35),this.juice.addShockwave(e,t,s,"#fb923c"),this.particles.emitSparks(e,t,16,"#fde047"),this.particles.emitRockShards(e,t,10,"#fb923c"),this.particles.emitSmokePuff(e,t,6,"#334155")},onBumperHit:(e,t,s)=>{const i=t.x+t.width*.5,a=t.y+t.height*.5;this.audio.playBumper(e.comboCount,i),this.save.stats.bumpersHit+=1,this.retention.recordQuestProgress(this.save,"bumpersHit",1),this.runCoins+=s,this.save.coins+=s,this.save.totalCoinsEarned+=s,this.floatingText.spawn(i,a-10,"+2 BOUNCE","#22d3ee",1.1),this.particles.emitSparks(i,a,10,"#e879f9")},onLaserFire:e=>{this.audio.playExplosion(y.SHAFT_WIDTH*.5),this.juice.addLaserBeam(e,"#fef08a"),this.juice.triggerShake(4.5)},onPortalWarp:(e,t,s)=>{this.audio.playBumper(6),this.particles.emitBurst(t.x+28,t.y+28,10,"#a3e635",60,180,4,.35),this.particles.emitBurst(s.x+28,s.y+28,10,"#f43f5e",60,180,4,.35),this.floatingText.spawn(s.x+28,s.y,"+2 WARP!","#a3e635",1.15)},onBossCoreDamaged:(e,t,s)=>{this.progression.recordBossCoreDamage(this.save,e,t,s)},onBossGateBroken:e=>{if(e>=V.FINAL_BIOME_INDEX){this.clearedBiome6ThisRun=!0;const a=this.progression.completeFinalGateClear(this.save,this.isFullShaftRun,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,timestamp:S.getServerTimeMs()});if(a.ascended){this.audio.playVictoryFanfare(),this.juice.triggerHitStop(.06),this.juice.triggerShake(10),S.happytime();const n=y.SHAFT_WIDTH*.5,r=this.cameraY+240;this.particles.emitBurst(n,r,50,"#fde047",120,440,6,1.3),this.particles.emitBurst(n-70,r-30,40,"#f59e0b",110,400,5.5,1.25),this.particles.emitBurst(n+70,r-30,40,"#fffbeb",110,400,5,1.2),this.particles.emitBurst(n,r-60,25,"#38bdf8",90,360,5,1.15),this.pendingVictoryTier=a.newTier,this.victorySlowMoTimer=.45}else this.audio.playFanfare(),this.juice.triggerHitStop(.05),this.juice.triggerShake(8),S.happytime(),this.hud.showToast(g.t("elevator_clear_title"));this.persistSave();return}this.audio.playFanfare(),this.juice.triggerHitStop(.05),this.juice.triggerShake(8),S.happytime();const t=this.progression.unlockNextBiome(this.save,e);this.generator.updateOptions({unlockedBiomeIndex:this.save.unlockedBiomeIndex});const i=this.skins.checkAndUnlockEligibleSkins(this.save).map(a=>{const n=this.skins.getEquippedSkin({...this.save,equippedSkin:a});return g.t(n.nameKey)});t&&(this.pendingBiomeUnlock={biomeIndex:this.save.unlockedBiomeIndex,unlockedSkinNames:i},this.hud.showToast(g.t("biome_unlocked_title"))),this.persistSave()}})}resetShaft(){this.entities=[],this.orbs.length=0;for(let e=0;e<Re;e++)this.coins[e].alive=!1;this.cameraY=0,this.particles.clear(),this.floatingText.clear(),this.juice.clear(),this.generator.reset({baseRowOffset:this.progression.getBaseRowOffset(this.save),luckLevel:this.save.upgrades.luck,bossGateHpByBiome:this.save.bossGateHpByBiome,unlockedBiomeIndex:this.save.unlockedBiomeIndex,ascensionTier:this.save.ascensionTier}),this.generator.ensureChunksUpToRow(24,this.entities)}launchVolley(e){this.audio.playLaunch(),this.aimFeedback=null,this.aimAngleRad=null,this.trajectoryDots=[],this.trajectoryImpact=null,this.trajectorySecondImpact=null,this.stateMachine.transition("RUNNING"),this.loop.setSpeedMultiplier(1),this.runCoins=0,this.runStartBestDepthM=this.save.maxDepthMeters;const t=this.progression.getSelectedBiome(this.save).startDepthM;this.runMaxDepthM=t,this.runElapsedS=0,this.isFullShaftRun=t===0,this.runBlocksSmashed=0,this.runMaxCombo=0,this.runTntCount=0,this.clearedBiome6ThisRun=!1,this.victorySlowMoTimer=0,this.pendingVictoryTier=null,this.save.overdrivePasses>0?(this.save.overdrivePasses-=1,this.isOverdriveRun=!0):this.isOverdriveRun=!1;const s=this.economy.getEffectiveMultiOrbCount(this.save);this.volleyAngleRad=e,this.pendingVolleyOrbs=s-1,this.volleyTimerS=0,this.spawnLauncherOrb(e)}spawnLauncherOrb(e){this.turretRecoil=1;const t=this.economy.getEffectiveOrbRadius(this.save),s=this.isOverdriveRun?t*1.4:t,i=this.economy.getEffectiveMaxBounces(this.save),a=this.economy.getEffectiveDrillDamage(this.save)*(this.isOverdriveRun?1.5:1),n=Ie(y.SHAFT_WIDTH*.5,y.LAUNCHER_Y,e);this.particles.emitDirectionalBurst(n.x,n.y,e,.45,9,"#fde047",160,340,3.6,.24,"spark",!0);const r=this.physics.createOrb(n.x,n.y,e,s,i,a,!1,this.isOverdriveRun);this.orbs.push(r)}fixedUpdate(e){this.monetization.updateSessionTime(e),this.timeS+=e,this.turretRecoil>0&&(this.turretRecoil=Math.max(0,this.turretRecoil-e*8));const s=this.progression.getSelectedBiome(this.save).startDepthM+this.cameraY/y.TILE_SIZE*y.METERS_PER_ROW,i=De.getBiomeAtDepth(s);if(this.audio.updateMusicState(i.index,this.stateMachine.state,this.bossActiveForAudio),this.stateMachine.state!=="RUNNING")return;if(this.runElapsedS+=e,this.juice.consumeHitStop(e)){this.juice.update(e);return}let a=e;this.victorySlowMoTimer>0&&(this.victorySlowMoTimer=Math.max(0,this.victorySlowMoTimer-e),a=e*.3),this.pendingVolleyOrbs>0&&(this.volleyTimerS+=a,this.volleyTimerS>=y.MULTI_ORB_INTERVAL_S&&(this.volleyTimerS-=y.MULTI_ORB_INTERVAL_S,this.pendingVolleyOrbs--,this.spawnLauncherOrb(this.volleyAngleRad))),this.physics.step(a,this.orbs,this.entities,this.save.upgrades.orevalue,this.save.upgrades.orbsize,this.save.prestigeLevel,this.save.ascensionTier);let n=0,r=!1;for(const o of this.orbs)o.alive&&(r=!0,o.y>n&&(n=o.y));if(r){const o=Math.max(0,n-y.CAMERA_LOOKAHEAD_Y);this.cameraY+=(o-this.cameraY)*Math.min(1,e*6);const h=Math.ceil((this.cameraY+1200)/y.TILE_SIZE);this.generator.ensureChunksUpToRow(h,this.entities);const p=this.progression.getSelectedBiome(this.save).startDepthM+n/y.TILE_SIZE*y.METERS_PER_ROW;p>this.runMaxDepthM&&(this.runMaxDepthM=p),p>this.save.maxDepthMeters&&(this.save.maxDepthMeters=p)}const d=56,l=this.cameraY+26;for(let o=0;o<this.coins.length;o++){const h=this.coins[o];if(h.alive){if(h.life-=e,h.life<=0){h.alive=!1;continue}if(h.magnetized&&h.life<=.48){const m=d-h.x,p=l-h.y,u=Math.hypot(m,p);if(u<22){h.alive=!1,this.particles.emitBurst(h.x,h.y,2,"#fde047",20,60,2.5,.16);continue}const b=Math.min(1,e*16),_=m/u*1150,v=p/u*1150;h.vx+=(_-h.vx)*b,h.vy+=(v-h.vy)*b}else h.vy+=520*e;h.x+=h.vx*e,h.y+=h.vy*e}}this.particles.update(a),this.floatingText.update(a),this.juice.update(a),(this.pendingVictoryTier!==null&&this.victorySlowMoTimer<=0||!r&&this.pendingVolleyOrbs<=0&&this.victorySlowMoTimer<=0)&&this.finishRun()}finishRun(){this.loop.setSpeedMultiplier(1),S.gameplayStop(),this.save.runsCompleted+=1,this.save.stats.runsCompleted+=1,this.retention.recordQuestProgress(this.save,"runsCompleted",1),this.save.recentRunEarnings.push(this.runCoins),this.save.recentRunEarnings.length>3&&this.save.recentRunEarnings.shift();const e=Math.max(.25,this.runElapsedS/60);if(this.save.recentRunCoinsPerMin=Math.max(40,Math.round(this.runCoins/e)),this.save.lastActiveTimestamp=S.getServerTimeMs(),this.progression.checkMasteryFeats(this.save,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,tntChainMax:this.runTntCount,maxDepthMeters:this.runMaxDepthM,isFullShaftRun:this.isFullShaftRun}),this.skins.checkAndUnlockEligibleSkins(this.save),this.persistSave(),this.pendingVictoryTier!==null){const r=this.pendingVictoryTier;this.pendingVictoryTier=null,this.stateMachine.transition("ASCENSION_VICTORY"),this.victoryModal.show({newTier:r,blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,coinsEarned:this.runCoins,onDescendNextTier:()=>{this.progression.selectBiome(this.save,0),this.persistSave(),this.resetShaft(),this.resumeToAiming()},onOpenUpgrades:()=>{this.openShop("upgrades",!1)},onDoubleVictoryCoins:async()=>{const d=await this.monetization.showRewarded("rv_double_run");return d.rewarded?(this.save.coins+=this.runCoins,this.save.totalCoinsEarned+=this.runCoins,this.persistSave(),!0):(this.showAdFailureToast(d.reason),!1)}});return}this.stateMachine.transition("RUN_SUMMARY");const t=this.entities.some(r=>r.alive&&(r.kind==="vault"||r.kind==="boss_core")&&r.hp/r.maxHp<=Q.RV_EXTRA_LAUNCH_HP_THRESHOLD),s=S.canShowRewardedAds()&&this.monetization.canOfferDoubleRun(this.save,this.runCoins);s&&this.monetization.markDoubleRunOffered(this.save.runsCompleted),this.skipNextMidgameBreak=!S.canShowRewardedAds()||s||t;const i=ne.filter(r=>this.economy.canAfford(this.save,r.id)).length,a=()=>{this.summary.show({coinsEarned:this.runCoins,maxDepthMeters:this.runMaxDepthM,isNewBest:this.runMaxDepthM>this.runStartBestDepthM&&this.runMaxDepthM>5,affordableUpgradeCount:i,showDoubleAd:s,showExtraLaunchAd:t,clearedBiome6ViaElevator:this.clearedBiome6ThisRun&&!this.isFullShaftRun,currentAscensionTier:this.save.ascensionTier,onRelaunch:()=>this.prepareNextRun(),onOpenShop:()=>this.openShop(),onStartZeroMeterRun:()=>{this.progression.selectBiome(this.save,0),this.persistSave(),this.resetShaft(),this.resumeToAiming()},onDoubleAd:async()=>{const r=await this.monetization.showRewarded("rv_double_run");r.rewarded?(this.save.coins+=this.runCoins,this.save.totalCoinsEarned+=this.runCoins,this.persistSave(),this.summary.hide(),this.prepareNextRun()):this.showAdFailureToast(r.reason)},onExtraLaunchAd:async()=>{const r=await this.monetization.showRewarded("rv_extra_launch");r.rewarded?(this.summary.hide(),this.cameraY=0,this.resumeToAiming()):this.showAdFailureToast(r.reason)}})},n=this.pendingBiomeUnlock;if(this.pendingBiomeUnlock=null,n){const r=O[n.biomeIndex];if(r){this.retentionModals.showBiomeUnlockModal(g.t(r.nameKey),r.coinMultiplier,n.unlockedSkinNames,a);return}}a()}async prepareNextRun(){S.clearAllBanners();const e=!this.skipNextMidgameBreak&&S.canShowRewardedAds()&&this.monetization.canShowMidgameAd();this.skipNextMidgameBreak=!1,e&&(this.hud.showToast(g.t("short_break"),500),await new Promise(t=>setTimeout(t,Q.PRE_AD_CUE_S*1e3)),await this.monetization.tryShowMidgameAd()),this.resetShaft(),this.resumeToAiming()}openShop(e="upgrades",t=!1){this.titleOverlay.dismissFloatingIntroBanner(),S.gameplayStop(),this.stateMachine.transition("SHOP");const s=this.monetization.canOfferFreeUpgrade(this.save.runsCompleted)?this.economy.getCheapestNearlyAffordableUpgrade(this.save,Q.RV_FREE_UPGRADE_MIN_GAP,Q.RV_FREE_UPGRADE_MAX_GAP):null,i=()=>{this.shop.render(this.save,this.economy,this.skins,this.progression,s,a)},a={onBuyUpgrade:n=>{this.economy.buyUpgrade(this.save,n)&&(this.audio.playUpgrade(),this.persistSave(),i())},onFreeUpgradeAd:async n=>{const r=await this.monetization.showRewarded("rv_free_upgrade");r.rewarded?(this.monetization.markFreeUpgradeOffered(this.save.runsCompleted),this.economy.grantFreeUpgrade(this.save,n),this.audio.playUpgrade(),this.persistSave(),i()):this.showAdFailureToast(r.reason)},onEquipSkin:n=>{this.skins.equipSkin(this.save,n)&&(this.audio.playClick(),this.persistSave(),i())},onUnlockSkinCoins:n=>{this.skins.unlockWithCoins(this.save,n)&&(this.audio.playUpgrade(),this.persistSave(),i())},onUnlockSkinAd:async n=>{const r=await this.monetization.showRewarded("rv_skin_progress");r.rewarded?(this.skins.addRvProgress(this.save,n),this.audio.playUpgrade(),this.persistSave(),i()):this.showAdFailureToast(r.reason)},onPrestige:()=>{this.progression.triggerPrestige(this.save)&&(this.audio.playUpgrade(),this.persistSave(),this.shop.close(),this.resetShaft(),this.stateMachine.transition("AIMING"))},onClose:()=>{this.resetShaft(),t?(this.stateMachine.transition("TITLE"),this.showTitleScreen()):this.resumeToAiming()}};this.shop.open(this.save,this.economy,this.skins,this.progression,s,a,e)}openAchievements(e){e||S.gameplayStop(),this.stateMachine.transition("SHOP"),this.achievementsModal.open(this.save,t=>{this.progression.claimMasteryFeat(this.save,t)>0&&(this.audio.playUpgrade(),this.persistSave())},()=>{e?(this.stateMachine.transition("TITLE"),this.showTitleScreen()):this.resumeToAiming()})}simulateFinalGateClear(e){this.titleOverlay.hideImmediate(),this.shop.close(),this.summary.hide(),this.victoryModal.hide(),this.achievementsModal.hide(),this.retentionModals.hide(),this.save.unlockedBiomeIndex=V.FINAL_BIOME_INDEX,this.progression.selectBiome(this.save,e?0:V.FINAL_BIOME_INDEX),this.isFullShaftRun=e,this.runMaxDepthM=V.FINAL_GATE_DEPTH_M,this.save.maxDepthMeters=Math.max(this.save.maxDepthMeters,this.runMaxDepthM),this.runBlocksSmashed=Math.max(this.runBlocksSmashed,145),this.runMaxCombo=Math.max(this.runMaxCombo,28),this.save.stats.maxBounceCombo=Math.max(this.save.stats.maxBounceCombo,this.runMaxCombo),this.runTntCount=Math.max(this.runTntCount,4);const t=Math.max(this.runCoins,2500);this.runCoins=t,this.save.coins+=t,this.save.totalCoinsEarned+=t;const{ascended:s,newTier:i}=this.progression.completeFinalGateClear(this.save,e,{blocksSmashed:this.runBlocksSmashed,maxCombo:this.runMaxCombo,timestamp:S.getServerTimeMs()});this.clearedBiome6ThisRun=!0,this.victorySlowMoTimer=0,this.pendingVictoryTier=s?i:null,s&&(this.audio.playVictoryFanfare(),S.happytime()),this.orbs.length=0,this.pendingVolleyOrbs=0,this.finishRun()}showTitleScreen(){this.ftue.setVisible(!1),this.titleOverlay.show({logoUrl:this.renderer.getLogoEmblemUrl(),bestDepthMeters:this.save.maxDepthMeters,ascensionTier:this.save.ascensionTier,hasUnclaimedFeats:this.progression.hasUnclaimedFeats(this.save),muted:this.audio.isMuted(),callbacks:{onUserGesture:()=>{this.audio.unlock()},onPlay:()=>{this.audio.unlock(),this.stateMachine.transition("AIMING"),this.ftue.setVisible(!this.save.ftueDone),this.hasStartedGameplayOnce||(this.hasStartedGameplayOnce=!0),S.gameplayStart()},onToggleMute:()=>{this.audio.unlock(),this.save.settings.muted=this.audio.toggleMute(),this.persistSave(),this.showTitleScreen()},onOpenSettings:()=>{this.openSettings(!0)},onOpenSkins:()=>{this.titleOverlay.hideImmediate(),this.openShop("skins",!0)},onOpenAchievements:()=>{this.titleOverlay.hideImmediate(),this.openAchievements(!0)}}})}openSettings(e){this.settingsModal.open(this.save,g.getLocale(),{onToggleSfx:()=>{this.save.settings.sfxMuted=!this.save.settings.sfxMuted,this.audio.setSfxMuted(this.save.settings.sfxMuted),this.persistSave()},onToggleMusic:()=>{this.audio.unlock(),this.save.settings.musicMuted=!this.save.settings.musicMuted,this.audio.setMusicMuted(this.save.settings.musicMuted),this.save.settings.musicVolume=this.audio.getMusicVolume(),this.persistSave()},onSetMusicVolume:t=>{this.audio.unlock(),this.save.settings.musicVolume=t,this.save.settings.musicMuted=t==="off",this.audio.setMusicVolume(t),this.persistSave()},onToggleAimMode:()=>{this.save.settings.aimMode=this.save.settings.aimMode==="slingshot"?"direct":"slingshot",this.save.settings.aimModeUserSet=!0,this.ftue.setAimMode(this.save.settings.aimMode),this.persistSave()},onSelectLocale:t=>{this.save.settings.localeOverride=t,g.setLocale(t),this.hud.refreshLabels(),this.ftue.refreshText(),this.persistSave()},onConfirmReset:()=>{this.save=this.saveManager.resetProgress(S.getServerTimeMs());const t=JSON.stringify(this.save);S.saveCloudData(t),this.audio.setUserMuted(!1),this.audio.setSfxMuted(!1),this.audio.setMusicVolume("high"),this.save.settings.aimMode=this.getDefaultAimModeForDevice(),this.save.settings.aimModeUserSet=!1,this.ftue.setAimMode(this.save.settings.aimMode),g.setLocale(S.getLocale()),this.hud.refreshLabels(),this.ftue.refreshText(),this.ftue.setVisible(!0),this.returnToHome()},onClose:()=>{e?this.showTitleScreen():this.resumeToAiming()}})}returnToHome(){S.gameplayStop(),this.pausedFromState=null,this.orbs=[],this.pendingVolleyOrbs=0,this.resetShaft(),this.stateMachine.transition("TITLE"),this.showTitleScreen()}render(e){const t=this.progression.getSelectedBiome(this.save),s=t.startDepthM+this.cameraY/y.TILE_SIZE*y.METERS_PER_ROW,i=De.getBiomeAtDepth(s),a=this.orbs.reduce((C,B)=>B.alive?C+B.bouncesLeft:C,0),n=ne.filter(C=>this.economy.canAfford(this.save,C.id)).length,r=this.save.dailyQuests.quests.some(C=>!C.claimed&&C.progress>=C.target),d=this.stateMachine.state==="RUNNING"?this.runMaxDepthM:t.startDepthM,l=t.startDepthM,o=Number.isFinite(t.endDepthM)?t.endDepthM:V.FINAL_GATE_DEPTH_M,h=Math.max(1,o-l),m=(d-l)/h*100,p=o-d<=15,u=Math.min(6,t.index+2),b=t.index>=V.FINAL_BIOME_INDEX?`${Math.floor(d)}m / ${V.FINAL_GATE_DEPTH_M}m (${g.t("boss_gate")})`:`${Math.floor(d)}m / ${Math.floor(o)}m to Biome ${u} Boss`,_=this.viewport.getLayout().cssHeight/this.viewport.getLayout().scale;let v=-1,k=0,R=0,M=0;for(let C=0;C<this.entities.length;C++){const B=this.entities[C];B.kind==="boss_core"&&B.biomeIndex===t.index&&(v===-1&&(v=B.row),B.row===v&&(M+=B.maxHp,B.alive&&(k++,R+=B.hp)))}const A=v*y.TILE_SIZE,E=v>=0&&k>0&&(R<M-.5||A>=this.cameraY-40&&A<=this.cameraY+_+60);this.bossActiveForAudio=p||E,this.hud.update({coins:this.save.coins,depthMeters:d,biomeName:g.t(i.nameKey),bouncesLeft:a,isTitle:this.stateMachine.state==="TITLE",isRunning:this.stateMachine.state==="RUNNING",isAiming:this.stateMachine.state==="AIMING",aimMode:this.save.settings.aimMode,muted:this.audio.isMuted(),speedMult:this.loop.getSpeedMultiplier(),hasElevator:this.save.unlockedBiomeIndex>0,showOverdriveOffer:this.save.overdrivePasses===0&&this.monetization.canOfferOverdriveTrial(this.save.runsCompleted),hasClaimableLogin:!this.save.loginStreak.claimedToday,hasClaimableQuest:r,hasUnclaimedFeats:this.progression.hasUnclaimedFeats(this.save),affordableUpgradeCount:n,bossProgressText:b,bossProgressPct:m,bossNear:p,isFullShaftRun:(this.stateMachine.state==="RUNNING"?this.isFullShaftRun:t.startDepthM===0)&&this.stateMachine.state!=="TITLE",ascensionTier:this.save.ascensionTier,activeGate:E?{coresAlive:k,hp:R,maxHp:M}:null}),this.renderer.render(this.viewport.getLayout(),{cameraY:this.cameraY,baseDepthMeters:t.startDepthM,launcherX:y.SHAFT_WIDTH*.5,launcherY:y.LAUNCHER_Y,aimAngleRad:this.stateMachine.state==="AIMING"?this.aimAngleRad:null,isAimingState:this.stateMachine.state==="AIMING",loadedOrbRadius:this.economy.getEffectiveOrbRadius(this.save),loadedOrbCount:this.economy.getEffectiveMultiOrbCount(this.save),turretRecoil:this.turretRecoil,trajectoryDots:this.trajectoryDots,trajectoryImpact:this.trajectoryImpact,trajectorySecondImpact:this.trajectorySecondImpact,targetedBlockId:this.targetedBlockId,secondTargetedBlockId:this.secondTargetedBlockId,trajectoryBounceIdx:this.trajectoryBounceIdx,aimFeedback:this.aimFeedback,orbs:this.orbs,entities:this.entities,coins:this.coins,skin:this.skins.getEquippedSkin(this.save),particles:this.particles,floatingText:this.floatingText,juice:this.juice,timeS:this.timeS+e})}getDefaultAimModeForDevice(){const e=S.getDeviceType();return e==="mobile"||e==="tablet"?"slingshot":"direct"}resumeToAiming(){S.clearAllBanners(),this.stateMachine.transition("AIMING"),this.hasStartedGameplayOnce&&S.gameplayStart()}togglePause(){const e=this.stateMachine.state;if(e==="PAUSED"){this.retentionModals.hide();const t=this.pausedFromState??"AIMING";this.pausedFromState=null,this.stateMachine.transition(t),this.hasStartedGameplayOnce&&S.gameplayStart();return}e!=="AIMING"&&e!=="RUNNING"||(this.pausedFromState=e,this.stateMachine.transition("PAUSED"),S.gameplayStop(),this.retentionModals.showPauseModal(()=>this.togglePause(),()=>{this.pausedFromState=null,this.resetShaft(),this.resumeToAiming()},()=>{this.pausedFromState=null,this.openSettings(!1)},()=>this.returnToHome()))}showAdFailureToast(e){this.hud.showToast(e==="skipped"?g.t("ad_incomplete"):g.t("ad_unavailable"))}persistSave(){const e=this.saveManager.saveLocal(this.save);S.saveCloudData(e)}}const Ki=new Wi;Ki.boot();
